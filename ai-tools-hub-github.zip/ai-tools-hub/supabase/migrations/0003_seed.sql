-- ============================================================================
-- AI TOOLS HUB — 0003 seed content
-- Idempotent: safe to re-run. Uses ON CONFLICT DO NOTHING so it never
-- overwrites anything an admin has since edited.
-- ============================================================================

insert into public.categories (name, slug, description, icon, sort_order) values
  ('AI Chatbots',        'ai-chatbots',     'Conversational assistants for questions, drafting and reasoning.', 'message-square', 1),
  ('AI Coding',          'ai-coding',       'Code completion, review, debugging and app generation.',           'code',           2),
  ('AI Image Generation','ai-image',        'Text-to-image models and generative visual tools.',                 'image',          3),
  ('AI Video',           'ai-video',        'Generate, edit and enhance video with AI.',                         'video',          4),
  ('AI Audio',           'ai-audio',        'Voice synthesis, cloning, transcription and music.',                'audio-lines',    5),
  ('AI Productivity',    'ai-productivity', 'Notes, meetings, calendars and workflow acceleration.',             'zap',            6),
  ('AI Writing',         'ai-writing',      'Drafting, editing, grammar and tone adjustment.',                   'pen-line',       7),
  ('AI Research',        'ai-research',     'Search, synthesis and literature review.',                          'search',         8),
  ('AI Automation',      'ai-automation',   'Agents and no-code workflow pipelines.',                            'workflow',       9),
  ('AI Marketing',       'ai-marketing',    'Copy, SEO, ads and campaign generation.',                           'megaphone',      10),
  ('AI Design',          'ai-design',       'Layout, UI and presentation design assistance.',                    'layout',         11),
  ('AI Education',       'ai-education',    'Tutoring, study aids and course material.',                         'graduation-cap', 12)
on conflict (slug) do nothing;

-- ---------------------------------------------------------------------------
-- TOOLS
-- ---------------------------------------------------------------------------
insert into public.tools
  (slug, name, tagline, description, website_url, pricing_model, starting_price,
   tags, is_featured, is_trending, rating, rating_count, view_count, added_at)
values
  ('chatgpt', 'ChatGPT', 'General-purpose assistant for writing, research and code.',
   'OpenAI''s conversational assistant. Handles drafting, analysis, summarisation, translation and coding, with file and image understanding on paid tiers.',
   'https://chatgpt.com/', 'freemium', '$20/mo',
   array['assistant','writing','research','coding'], true, true, 4.8, 1240, 48200, now() - interval '400 days'),

  ('claude', 'Claude', 'Reasoning-first assistant built for long documents and code.',
   'Anthropic''s assistant, strong on long-context analysis, careful writing and software engineering. Projects and artifacts support iterative work.',
   'https://claude.ai/', 'freemium', '$20/mo',
   array['assistant','reasoning','coding','analysis'], true, true, 4.8, 980, 39100, now() - interval '380 days'),

  ('perplexity', 'Perplexity', 'Answer engine that cites its sources.',
   'Combines search with an LLM to answer questions and cite the pages it used. Useful for research where provenance matters.',
   'https://www.perplexity.ai/', 'freemium', '$20/mo',
   array['search','research','citations'], true, true, 4.6, 870, 33400, now() - interval '360 days'),

  ('midjourney', 'Midjourney', 'High-aesthetic image generation.',
   'Diffusion model known for distinctive, art-directed output. Discords and web interface, strong style control and remixing.',
   'https://www.midjourney.com/', 'paid', '$10/mo',
   array['image','art','design'], true, true, 4.7, 1100, 41200, now() - interval '390 days'),

  ('leonardo-ai', 'Leonardo AI', 'Image generation tuned for game and product assets.',
   'Generative image platform with fine-tuned models, canvas editing and asset pipelines aimed at production work.',
   'https://leonardo.ai/', 'freemium', '$12/mo',
   array['image','assets','design'], false, false, 4.4, 410, 14200, now() - interval '300 days'),

  ('adobe-firefly', 'Adobe Firefly', 'Commercially safe generative imaging inside Creative Cloud.',
   'Adobe''s generative model, trained on licensed content and integrated across Photoshop and Illustrator for inpainting and expansion.',
   'https://firefly.adobe.com/', 'freemium', '$10/mo',
   array['image','design','commercial'], false, false, 4.2, 380, 12800, now() - interval '340 days'),

  ('github-copilot', 'GitHub Copilot', 'Inline code completion across your editor.',
   'Autocompletes functions and tests in the editor, with a chat mode for explaining and refactoring existing code.',
   'https://github.com/features/copilot', 'paid', '$10/mo',
   array['coding','completion','developer'], true, true, 4.5, 760, 29500, now() - interval '370 days'),

  ('cursor', 'Cursor', 'Editor built around AI pair programming.',
   'A fork of VS Code with repo-wide context, multi-file edits and agentic refactors. Popular with teams doing large changes.',
   'https://cursor.com/', 'freemium', '$20/mo',
   array['coding','editor','agent'], true, true, 4.7, 690, 27600, now() - interval '280 days'),

  ('runway', 'Runway', 'AI video generation and editing suite.',
   'Text and image to video, plus motion brush, inpainting and green-screen tools used in film and advertising workflows.',
   'https://runwayml.com/', 'freemium', '$15/mo',
   array['video','editing','generation'], true, false, 4.4, 520, 19800, now() - interval '350 days'),

  ('capcut', 'CapCut', 'Consumer video editing with AI assists.',
   'Free editor with auto-captions, background removal and template-driven editing aimed at short-form video.',
   'https://www.capcut.com/', 'freemium', null,
   array['video','editing','captions'], false, false, 4.3, 610, 22100, now() - interval '330 days'),

  ('elevenlabs', 'ElevenLabs', 'Natural text-to-speech and voice cloning.',
   'High-fidelity speech synthesis across many languages, with voice cloning and a dubbing studio for video localisation.',
   'https://elevenlabs.io/', 'freemium', '$5/mo',
   array['audio','voice','tts'], true, true, 4.7, 540, 18900, now() - interval '260 days'),

  ('suno', 'Suno', 'Generate songs from a text prompt.',
   'Produces full tracks with vocals and instrumentation from a description, with style and lyric control.',
   'https://suno.com/', 'freemium', '$8/mo',
   array['music','audio','generation'], false, true, 4.5, 430, 16400, now() - interval '240 days'),

  ('grammarly', 'Grammarly', 'Grammar, clarity and tone correction.',
   'Checks spelling, grammar and tone in the browser and in documents, with rewriting suggestions and a plagiarism check.',
   'https://www.grammarly.com/', 'freemium', '$12/mo',
   array['writing','grammar','editing'], false, false, 4.4, 720, 25300, now() - interval '365 days'),

  ('jasper', 'Jasper', 'Marketing copy generation with brand voice.',
   'Campaign and long-form copy generation with brand voice profiles, templates and a team workflow layer.',
   'https://www.jasper.ai/', 'paid', '$39/mo',
   array['writing','marketing','brand'], false, false, 4.0, 290, 9800, now() - interval '320 days'),

  ('canva', 'Canva', 'Design and video editing with AI features.',
   'Template-driven design tool with Magic Studio for text-to-image, background removal and resizing across formats.',
   'https://www.canva.com/', 'freemium', '$13/mo',
   array['design','templates','video'], true, false, 4.6, 950, 30800, now() - interval '355 days'),

  ('gamma', 'Gamma', 'Generate decks and documents from a prompt.',
   'Produces presentation decks and documents with layout and theming handled automatically; exports to PDF and PowerPoint.',
   'https://gamma.app/', 'freemium', null,
   array['design','presentation','productivity'], false, true, 4.5, 380, 13600, now() - interval '180 days'),

  ('notion-ai', 'Notion AI', 'Writing and search assistance inside Notion.',
   'Summarises pages, drafts content and answers questions across your workspace using your existing Notion documents.',
   'https://www.notion.so/product/ai', 'paid', '$10/mo',
   array['productivity','writing','notes'], false, false, 4.3, 470, 17200, now() - interval '310 days'),

  ('otter-ai', 'Otter.ai', 'Meeting transcription and summaries.',
   'Joins calls, transcribes in real time and produces action items and searchable notes from meetings.',
   'https://otter.ai/', 'freemium', '$10/mo',
   array['productivity','transcription','meetings'], false, false, 4.2, 340, 11500, now() - interval '290 days'),

  ('zapier', 'Zapier', 'Connect apps and automate workflows.',
   'Connects thousands of services into automations, with AI steps for summarising, classifying and extracting data.',
   'https://zapier.com/', 'freemium', '$20/mo',
   array['automation','workflow','integration'], false, false, 4.4, 520, 20400, now() - interval '345 days'),

  ('langchain', 'LangChain', 'Framework for building LLM applications.',
   'Open-source library for chaining prompts, tools and retrieval into applications, with integrations across providers.',
   'https://www.langchain.com/', 'freemium', null,
   array['automation','developer','framework'], false, false, 4.1, 260, 8900, now() - interval '270 days'),

  ('synthesia', 'Synthesia', 'Video avatars from text.',
   'Generates presenter-led training and marketing video from a script using stock or custom digital avatars.',
   'https://www.synthesia.io/', 'paid', '$29/mo',
   array['video','avatar','training'], false, false, 4.3, 300, 10200, now() - interval '250 days'),

  ('descript', 'Descript', 'Edit audio and video as a text document.',
   'Transcribes recordings and lets you edit by deleting words, with overdub voice correction and studio sound cleanup.',
   'https://www.descript.com/', 'freemium', '$19/mo',
   array['audio','video','editing'], false, true, 4.6, 410, 14800, now() - interval '200 days'),

  ('khanmigo', 'Khanmigo', 'AI tutor for learners and teachers.',
   'Socratic tutoring built on Khan Academy content, aimed at guiding students rather than handing over answers.',
   'https://www.khanmigo.ai/', 'freemium', '$4/mo',
   array['education','tutoring','learning'], false, false, 4.4, 180, 6400, now() - interval '150 days'),

  ('consensus', 'Consensus', 'Search across published research.',
   'Answers questions using peer-reviewed papers and surfaces the underlying studies with a consensus meter.',
   'https://consensus.app/', 'freemium', null,
   array['research','academic','search'], false, false, 4.5, 210, 7200, now() - interval '120 days'),

  ('surfer', 'Surfer SEO', 'Content optimisation against search data.',
   'Analyses the pages ranking for a term and scores drafts against their structure, terms and length.',
   'https://surferseo.com/', 'paid', '$99/mo',
   array['marketing','seo','content'], false, false, 4.2, 240, 8100, now() - interval '210 days'),

  ('pika', 'Pika', 'Short-form video generation.',
   'Turns a prompt or single image into a short clip, with effect templates and lip-sync for social content.',
   'https://pika.art/', 'freemium', '$8/mo',
   array['video','generation','social'], false, false, 4.1, 190, 6900, now() - interval '95 days'),

  ('deepseek', 'DeepSeek', 'Open-weight reasoning and coding models.',
   'Open-weight model family with strong mathematical and coding benchmarks, available through an API and chat app.',
   'https://www.deepseek.com/', 'freemium', null,
   array['assistant','reasoning','open-source'], false, true, 4.5, 320, 11800, now() - interval '60 days'),

  ('mistral-le-chat', 'Mistral Le Chat', 'European assistant with open models.',
   'Chat front end for Mistral''s model family, with a focus on speed, multilingual answers and EU data handling.',
   'https://chat.mistral.ai/', 'freemium', '$15/mo',
   array['assistant','open-source','multilingual'], false, false, 4.2, 150, 5200, now() - interval '75 days'),

  ('ideogram', 'Ideogram', 'Image generation with reliable text rendering.',
   'Diffusion model that renders legible typography inside images, useful for posters, logos and mockups.',
   'https://ideogram.ai/', 'freemium', '$8/mo',
   array['image','typography','design'], false, false, 4.3, 220, 7800, now() - interval '130 days'),

  ('heygen', 'HeyGen', 'Talking-head avatars and translation.',
   'Creates presenter videos from a script, with avatar selection and lip-synced translation into other languages.',
   'https://www.heygen.com/', 'freemium', '$29/mo',
   array['video','avatar','localisation'], false, false, 4.3, 260, 9100, now() - interval '110 days'),

  ('tome', 'Tome', 'Narrative-first deck generation.',
   'Generates presentations from a brief with a focus on narrative structure and responsive layouts.',
   'https://tome.app/', 'freemium', '$16/mo',
   array['design','presentation','writing'], false, false, 4.0, 140, 4700, now() - interval '230 days'),

  ('replit', 'Replit Agent', 'Build and deploy apps from a prompt.',
   'Cloud development environment whose agent scaffolds, edits and deploys full applications inside the browser.',
   'https://replit.com/', 'freemium', '$25/mo',
   array['coding','agent','deployment'], false, true, 4.4, 300, 10900, now() - interval '85 days'),

  ('tabnine', 'Tabnine', 'Private code completion for teams.',
   'Code completion that can run on-premises or in your own cloud, aimed at teams with source-code privacy requirements.',
   'https://www.tabnine.com/', 'paid', '$12/mo',
   array['coding','completion','privacy'], false, false, 4.1, 170, 5900, now() - interval '275 days'),

  ('otio', 'Otio', 'Research workspace and reading assistant.',
   'Collects sources, summarises long documents and drafts research notes with citations kept in sync.',
   'https://otio.ai/', 'freemium', null,
   array['research','reading','notes'], false, false, 4.0, 90, 3100, now() - interval '40 days'),

  ('lovable', 'Lovable', 'Prompt-to-app front-end builder.',
   'Generates React front ends connected to a database from natural language, with a live editing loop.',
   'https://lovable.dev/', 'freemium', '$25/mo',
   array['coding','app-builder','agent'], false, true, 4.3, 240, 8600, now() - interval '50 days'),

  ('fireflies', 'Fireflies.ai', 'Meeting notes and searchable transcripts.',
   'Records and transcribes meetings across platforms, then builds summaries, action items and a searchable archive.',
   'https://fireflies.ai/', 'freemium', '$10/mo',
   array['productivity','meetings','transcription'], false, false, 4.1, 210, 7300, now() - interval '185 days'),

  ('make', 'Make', 'Visual automation across apps.',
   'Node-based automation builder for multi-step workflows, with AI steps and fine-grained error handling.',
   'https://www.make.com/', 'freemium', '$9/mo',
   array['automation','workflow','no-code'], false, false, 4.3, 280, 9400, now() - interval '195 days'),

  ('copy-ai', 'Copy.ai', 'Go-to-market copy workflows.',
   'Generates sales and marketing copy with reusable workflows for prospecting, briefs and campaign variants.',
   'https://www.copy.ai/', 'freemium', '$36/mo',
   array['marketing','writing','sales'], false, false, 4.0, 160, 5400, now() - interval '215 days'),

  ('udio', 'Udio', 'Music generation with section control.',
   'Generates songs with control over structure and instrumentation, plus extension and remix of existing clips.',
   'https://www.udio.com/', 'freemium', '$10/mo',
   array['music','audio','generation'], false, false, 4.4, 200, 7000, now() - interval '160 days'),

  ('napkin', 'Napkin AI', 'Turn text into explanatory visuals.',
   'Generates diagrams and infographics from written content, editable and exportable for decks and posts.',
   'https://www.napkin.ai/', 'freemium', null,
   array['design','diagrams','productivity'], false, true, 4.2, 130, 4600, now() - interval '35 days')
on conflict (slug) do nothing;

-- ---------------------------------------------------------------------------
-- TOOL → CATEGORY links
-- ---------------------------------------------------------------------------
insert into public.tool_categories (tool_id, category_id)
select t.id, c.id
  from (values
    ('chatgpt','ai-chatbots'), ('chatgpt','ai-writing'), ('chatgpt','ai-productivity'),
    ('claude','ai-chatbots'), ('claude','ai-coding'), ('claude','ai-writing'),
    ('perplexity','ai-research'), ('perplexity','ai-chatbots'),
    ('deepseek','ai-chatbots'), ('deepseek','ai-coding'),
    ('mistral-le-chat','ai-chatbots'), ('mistral-le-chat','ai-research'),
    ('midjourney','ai-image'), ('midjourney','ai-design'),
    ('leonardo-ai','ai-image'), ('leonardo-ai','ai-design'),
    ('adobe-firefly','ai-image'), ('adobe-firefly','ai-design'),
    ('ideogram','ai-image'), ('ideogram','ai-design'),
    ('github-copilot','ai-coding'), ('cursor','ai-coding'), ('replit','ai-coding'),
    ('tabnine','ai-coding'), ('lovable','ai-coding'),
    ('runway','ai-video'), ('capcut','ai-video'), ('synthesia','ai-video'),
    ('heygen','ai-video'), ('pika','ai-video'), ('descript','ai-video'), ('descript','ai-audio'),
    ('elevenlabs','ai-audio'), ('suno','ai-audio'), ('udio','ai-audio'),
    ('grammarly','ai-writing'), ('jasper','ai-writing'), ('jasper','ai-marketing'),
    ('copy-ai','ai-writing'), ('copy-ai','ai-marketing'), ('surfer','ai-marketing'),
    ('canva','ai-design'), ('gamma','ai-design'), ('gamma','ai-productivity'),
    ('tome','ai-design'), ('napkin','ai-design'),
    ('notion-ai','ai-productivity'), ('otter-ai','ai-productivity'),
    ('fireflies','ai-productivity'), ('zapier','ai-automation'),
    ('make','ai-automation'), ('langchain','ai-automation'),
    ('consensus','ai-research'), ('otio','ai-research'),
    ('khanmigo','ai-education')
  ) as links(tool_slug, category_slug)
  join public.tools t      on t.slug = links.tool_slug
  join public.categories c on c.slug = links.category_slug
on conflict (tool_id, category_id) do nothing;

-- ---------------------------------------------------------------------------
-- Promote the existing account to admin (re-runs safely)
-- ---------------------------------------------------------------------------
insert into public.profiles (id, email, role)
select u.id, u.email, 'admin' from auth.users u
on conflict (id) do update set role = 'admin', email = excluded.email;

insert into public.user_preferences (user_id)
select u.id from auth.users u
on conflict (user_id) do nothing;

-- backfill profiles/preferences for any users the trigger missed
insert into public.profiles (id, email)
select u.id, u.email from auth.users u
where not exists (select 1 from public.profiles p where p.id = u.id)
on conflict (id) do nothing;
