-- ============================================================================
-- AI TOOLS HUB — open-source tools, batch 1
-- Licenses verified against the GitHub license API and each repository's
-- LICENSE file. SPDX identifiers recorded as GitHub reports them.
--
-- NOT included, because these are not OSI-approved open source despite being
-- routinely described as such (each verified):
--   open-webui  Open WebUI License, BSD-3 + branding clause (NOASSERTION)
--   n8n         Sustainable Use License ("fair-code")
--   dify        Apache 2.0 + additional conditions
--   lobe-chat   LobeHub Community License, Apache 2.0 + conditions
-- ============================================================================

-- Serving engines and vector databases needed a home of their own.
insert into public.categories (name, slug, description, icon, sort_order)
values ('AI Infrastructure', 'ai-infrastructure',
        'Run, serve and search with your own models, on your own hardware.',
        'server', 13)
on conflict (slug) do nothing;

insert into public.tools
  (slug, name, tagline, description, website_url, pricing_model, tags,
   is_featured, is_trending, rating, rating_count, view_count, added_at,
   is_open_source, repo_url, license)
values

  ('ollama','Ollama','Run open-weight models locally with one command.','Downloads and serves open-weight models such as Llama, Mistral and Qwen on your own machine through a local API. Keeps prompts and data entirely local, with a simple CLI and a REST interface any client can talk to.','https://ollama.com/','freemium',array['local','self-hosted','runtime','privacy'],true,true,0,0,38000,now() - interval '30 days',true,'https://github.com/ollama/ollama','MIT'),
  ('librechat','LibreChat','Self-hosted ChatGPT-style UI for any model.','A multi-user chat interface you host yourself, supporting OpenAI, Anthropic, local Ollama models and more in one place. Adds conversation search, presets, agents and per-user auth on top of whichever providers you supply.','https://www.librechat.ai/','free',array['self-hosted','chat','multi-provider'],false,true,0,0,14500,now() - interval '30 days',true,'https://github.com/danny-avila/LibreChat','MIT'),
  ('anything-llm','AnythingLLM','Private chat over your own documents.','All-in-one desktop and self-hosted app that turns documents into a searchable knowledge base you can chat with. Runs fully local with Ollama and built-in vector storage, or against hosted models, with multi-user workspace support.','https://anythingllm.com/','freemium',array['rag','self-hosted','documents','privacy'],false,false,0,0,11200,now() - interval '90 days',true,'https://github.com/Mintplex-Labs/anything-llm','MIT'),
  ('jan','Jan','Offline-first desktop AI assistant.','A desktop chat app that runs models locally on your machine and keeps working with no internet connection. Connects to local runtimes or remote APIs, and stores your conversations on disk rather than on a server.','https://jan.ai/','free',array['desktop','local','offline','privacy'],false,false,0,0,9800,now() - interval '90 days',true,'https://github.com/menloresearch/jan','Apache-2.0'),
  ('gpt4all','GPT4All','Local model runner and desktop chat.','Desktop application for running quantised open models on ordinary laptops and desktops, with a local document mode for asking questions over your own files. No account or API key required.','https://www.nomic.ai/gpt4all','free',array['local','desktop','offline'],false,false,0,0,8700,now() - interval '90 days',true,'https://github.com/nomic-ai/gpt4all','MIT'),
  ('llama-cpp','llama.cpp','Efficient inference for open models in plain C++.','The inference engine much local AI software is built on. Runs quantised models on CPU, Apple silicon and consumer GPUs with minimal dependencies, and ships an OpenAI-compatible server mode.','https://github.com/ggml-org/llama.cpp','free',array['inference','local','engine','developer'],false,false,0,0,16400,now() - interval '90 days',true,'https://github.com/ggml-org/llama.cpp','MIT'),
  ('vllm','vLLM','High-throughput serving for open models.','Serving engine for running open models at scale, using paged attention and continuous batching to get far more throughput per GPU than naive inference. Speaks an OpenAI-compatible API so existing clients work unchanged.','https://www.vllm.ai/','free',array['serving','gpu','infrastructure','developer'],false,false,0,0,9200,now() - interval '90 days',true,'https://github.com/vllm-project/vllm','Apache-2.0'),
  ('localai','LocalAI','Drop-in OpenAI replacement you host yourself.','Self-hosted API that mimics the OpenAI endpoints for chat, embeddings, images and speech, backed by local models. Lets you swap a hosted provider for your own hardware without rewriting application code.','https://localai.io/','free',array['self-hosted','api','local','privacy'],false,false,0,0,7600,now() - interval '90 days',true,'https://github.com/mudler/LocalAI','MIT'),
  ('stable-diffusion-webui','Stable Diffusion WebUI','The original desktop image-generation interface.','Community web interface that made Stable Diffusion accessible, with txt2img, img2img, inpainting, upscaling and a large ecosystem of extensions. Still the most flexible front end for local image models.','https://github.com/AUTOMATIC1111/stable-diffusion-webui','free',array['image','local','self-hosted','extensions'],false,true,0,0,29400,now() - interval '30 days',true,'https://github.com/AUTOMATIC1111/stable-diffusion-webui','AGPL-3.0'),
  ('comfyui','ComfyUI','Node-based visual editor for generative media.','Graph-based interface for building image and video generation pipelines from connected nodes. Gives precise control over sampling, conditioning and post-processing, and is the workflow format many new generative releases ship with.','https://www.comfy.org/','free',array['image','video','workflow','local'],false,true,0,0,31200,now() - interval '30 days',true,'https://github.com/comfyanonymous/ComfyUI','GPL-3.0'),
  ('invokeai','InvokeAI','Professional self-hosted image generation studio.','Self-hosted suite aimed at production work, with a unified canvas for inpainting and outpainting, model management and a workflow editor. Runs locally and keeps assets on your own machine.','https://invoke-ai.github.io/InvokeAI/','free',array['image','self-hosted','canvas','design'],false,false,0,0,6800,now() - interval '90 days',true,'https://github.com/invoke-ai/InvokeAI','Apache-2.0'),
  ('fooocus','Fooocus','Simple local image generation, no settings required.','Opinionated Stable Diffusion front end that hides the parameter maze and produces good results from a prompt alone. Small download, modest VRAM requirements, aimed at people who want images rather than knobs.','https://github.com/lllyasviel/Fooocus','free',array['image','local','simple'],false,false,0,0,7400,now() - interval '90 days',true,'https://github.com/lllyasviel/Fooocus','GPL-3.0'),
  ('whisper','OpenAI Whisper','Speech recognition that runs anywhere.','Open speech-to-text model covering dozens of languages, usable on CPU or GPU. Widely used as the baseline for transcription and the engine behind many other tools.','https://github.com/openai/whisper','free',array['transcription','speech','local','model'],true,true,0,0,26300,now() - interval '30 days',true,'https://github.com/openai/whisper','MIT'),
  ('whisper-cpp','whisper.cpp','Whisper transcription on consumer hardware.','C/C++ port of Whisper optimised to run efficiently on laptops, phones and even a Raspberry Pi, with no Python dependency. Includes a simple server mode for real-time transcription.','https://github.com/ggml-org/whisper.cpp','free',array['transcription','local','performance','developer'],false,false,0,0,9100,now() - interval '90 days',true,'https://github.com/ggml-org/whisper.cpp','MIT'),
  ('coqui-tts','Coqui TTS','Open text-to-speech and voice cloning.','Speech synthesis toolkit with many voices and languages, plus voice cloning from a short sample. Community fork that continues after the original company shut down.','https://github.com/idiap/coqui-ai-TTS','free',array['tts','voice','self-hosted','cloning'],false,false,0,0,5200,now() - interval '90 days',true,'https://github.com/idiap/coqui-ai-TTS','MPL-2.0'),
  ('piper','Piper','Fast, small TTS that runs on a Raspberry Pi.','Lightweight neural text-to-speech aimed at real-time use on low-power devices, with downloadable voices in many languages. A common choice for home assistants and offline narration.','https://github.com/OHF-Voice/piper1-gpl','free',array['tts','local','lightweight','offline'],false,false,0,0,4100,now() - interval '90 days',true,'https://github.com/OHF-Voice/piper1-gpl','MIT'),
  ('kokoro','Kokoro','Small, high-quality open TTS model.','Compact text-to-speech model that produces natural-sounding speech at a fraction of the size of larger systems, small enough to run on a CPU in real time.','https://huggingface.co/hexgrad/Kokoro-82M','free',array['tts','local','lightweight','model'],false,false,0,0,6300,now() - interval '90 days',true,'https://github.com/hexgrad/kokoro','Apache-2.0'),
  ('openvoice','OpenVoice','Instant voice cloning from a short sample.','Voice cloning and style-transfer toolkit that reproduces a target voice from a few seconds of audio, with control over tone, emotion and accent while preserving the speaker''s timbre.','https://github.com/myshell-ai/OpenVoice','free',array['voice','cloning','self-hosted'],false,false,0,0,5600,now() - interval '90 days',true,'https://github.com/myshell-ai/OpenVoice','MIT'),
  ('continue','Continue','Open-source Copilot for your IDE.','IDE extension for autocomplete, chat and inline edits that works with any model provider, including local ones. Fully configurable, and keeps your code on your machine if you point it at a local model.','https://www.continue.dev/','freemium',array['coding','ide','self-hosted','autocomplete'],true,false,0,0,18700,now() - interval '90 days',true,'https://github.com/continuedev/continue','Apache-2.0'),
  ('aider','Aider','Pair-programme in your terminal.','Command-line coding assistant that edits files in your local git repository and commits changes as it goes. Works with most model providers and keeps you in the terminal rather than switching apps.','https://aider.chat/','free',array['coding','cli','git','developer'],false,true,0,0,15900,now() - interval '30 days',true,'https://github.com/Aider-AI/aider','Apache-2.0'),
  ('zed','Zed','GPU-accelerated editor with built-in AI.','A fast collaborative code editor written in Rust, with an agent panel and inline assistant that can run against local models. The editor source is open; the hosted AI tier is optional.','https://zed.dev/','freemium',array['coding','editor','performance','local'],true,true,0,0,22400,now() - interval '30 days',true,'https://github.com/zed-industries/zed','GPL-3.0'),
  ('void','Void','Open-source Cursor alternative.','Fork of VS Code rebuilt around AI editing, with inline edits, an agent mode and support for local models so code never leaves your machine. Designed as a drop-in replacement for proprietary AI editors.','https://voideditor.com/','free',array['coding','editor','local','privacy'],false,false,0,0,6100,now() - interval '90 days',true,'https://github.com/voideditor/void','Apache-2.0'),
  ('openhands','OpenHands','Autonomous coding agent you can self-host.','Agent that takes a task description and works in a sandboxed environment to write code, run tests and open pull requests. Formerly OpenDevin, with a local Docker setup and an optional cloud.','https://www.all-hands.dev/','freemium',array['coding','agent','autonomous','self-hosted'],false,true,0,0,12700,now() - interval '30 days',true,'https://github.com/All-Hands-AI/OpenHands','MIT'),
  ('llamaindex','LlamaIndex','Data framework for LLM applications.','Library for connecting language models to your own data, with document loaders, indexing, retrieval and query engines. The building blocks behind many production RAG systems.','https://www.llamaindex.ai/','freemium',array['rag','framework','developer','retrieval'],false,false,0,0,18300,now() - interval '90 days',true,'https://github.com/run-llama/llama_index','MIT'),
  ('langflow','Langflow','Visual builder for LLM workflows.','Drag-and-drop editor for assembling agents and RAG pipelines from components, then exposing them as an API. Runs locally or self-hosted and exports to Python when you outgrow the canvas.','https://www.langflow.org/','freemium',array['automation','workflow','visual','developer'],false,true,0,0,13800,now() - interval '30 days',true,'https://github.com/langflow-ai/langflow','MIT'),
  ('ragflow','RAGFlow','Deep document understanding and retrieval.','Self-hosted RAG engine that parses complex documents such as PDFs with tables and diagrams, then answers questions with traceable citations. Built for teams who need to trust the answer.','https://ragflow.io/','freemium',array['rag','documents','self-hosted','citations'],false,false,0,0,7200,now() - interval '90 days',true,'https://github.com/infiniflow/ragflow','Apache-2.0'),
  ('perplexica','Perplexica','Open-source AI search engine.','Self-hosted answer engine that searches the web and cites its sources, using either local models or hosted APIs. A privacy-respecting alternative to hosted research assistants.','https://github.com/ItzCrazyKns/Perplexica','free',array['search','research','self-hosted','citations'],false,true,0,0,8900,now() - interval '30 days',true,'https://github.com/ItzCrazyKns/Perplexica','MIT'),
  ('khoj','Khoj','Chat with your notes and documents.','Self-hostable assistant that indexes your notes, PDFs and email, then answers questions across them and on the live web. Has desktop and web clients and works with local or hosted models.','https://khoj.dev/','freemium',array['research','notes','self-hosted','privacy'],false,false,0,0,4300,now() - interval '90 days',true,'https://github.com/khoj-ai/khoj','AGPL-3.0'),
  ('open-sora','Open-Sora','Open video generation model.','Openly licensed video generation model and training code, reproducing much of the quality of closed systems for short clips. Aimed at researchers and teams who need to run the model themselves.','https://github.com/hpcaitech/Open-Sora','free',array['video','generation','model','research'],false,false,0,0,4800,now() - interval '90 days',true,'https://github.com/hpcaitech/Open-Sora','Apache-2.0'),
  ('penpot','Penpot','Open-source design and prototyping platform.','Design tool built for the web that handles UI, prototyping and design systems, with a file format based on open standards. Self-hostable, and used by teams who want to own their design files rather than rent access to them.','https://penpot.app/','freemium',array['design','prototyping','self-hosted','collaboration'],true,false,0,0,10600,now() - interval '90 days',true,'https://github.com/penpot/penpot','MPL-2.0'),
  ('excalidraw','Excalidraw','Hand-drawn style whiteboard and diagrams.','Collaborative virtual whiteboard for sketching diagrams that look hand-drawn. Works offline, is end-to-end encrypted in collaboration mode, and is embedded in countless other products.','https://excalidraw.com/','freemium',array['diagrams','whiteboard','collaboration','design'],false,false,0,0,15400,now() - interval '90 days',true,'https://github.com/excalidraw/excalidraw','MIT'),
  ('appflowy','AppFlowy','Open-source workspace for notes and projects.','Self-hostable alternative to Notion that combines documents, databases, kanban boards and calendars, with local-first storage and optional AI features. Available as desktop and mobile apps.','https://appflowy.com/','freemium',array['productivity','notes','self-hosted','local-first'],false,false,0,0,11900,now() - interval '90 days',true,'https://github.com/AppFlowy-IO/AppFlowy','AGPL-3.0'),
  ('logseq','Logseq','Local-first outliner and knowledge base.','Note-taking tool built around outliner blocks and backlinks, storing everything in plain Markdown files you own. Works offline and has no proprietary database lock-in.','https://logseq.com/','free',array['notes','local-first','markdown','privacy'],false,false,0,0,13100,now() - interval '90 days',true,'https://github.com/logseq/logseq','AGPL-3.0'),
  ('chroma','Chroma','Embedding database for AI applications.','Vector database for storing and querying embeddings, designed to be embedded in an application with almost no setup. The quickest way to add semantic search to a prototype.','https://www.trychroma.com/','freemium',array['database','embeddings','developer','rag'],false,false,0,0,8200,now() - interval '90 days',true,'https://github.com/chroma-core/chroma','Apache-2.0'),
  ('qdrant','Qdrant','Vector search engine built in Rust.','Production-grade vector database with filtering, hybrid search and payload support, designed for high-throughput similarity search. Ships as a single binary or container.','https://qdrant.tech/','freemium',array['database','search','developer','infrastructure'],false,false,0,0,9600,now() - interval '90 days',true,'https://github.com/qdrant/qdrant','Apache-2.0')
on conflict (slug) do update set
  is_open_source = excluded.is_open_source,
  repo_url       = excluded.repo_url,
  license        = excluded.license,
  description    = excluded.description,
  tagline        = excluded.tagline;

insert into public.tool_categories (tool_id, category_id)
select t.id, c.id
  from (values

  ('ollama','ai-infrastructure'),
  ('ollama','ai-chatbots'),
  ('librechat','ai-chatbots'),
  ('anything-llm','ai-research'),
  ('anything-llm','ai-chatbots'),
  ('jan','ai-chatbots'),
  ('jan','ai-productivity'),
  ('gpt4all','ai-chatbots'),
  ('gpt4all','ai-infrastructure'),
  ('llama-cpp','ai-infrastructure'),
  ('vllm','ai-infrastructure'),
  ('localai','ai-infrastructure'),
  ('stable-diffusion-webui','ai-image'),
  ('comfyui','ai-image'),
  ('comfyui','ai-video'),
  ('invokeai','ai-image'),
  ('invokeai','ai-design'),
  ('fooocus','ai-image'),
  ('whisper','ai-audio'),
  ('whisper-cpp','ai-audio'),
  ('whisper-cpp','ai-infrastructure'),
  ('coqui-tts','ai-audio'),
  ('piper','ai-audio'),
  ('kokoro','ai-audio'),
  ('openvoice','ai-audio'),
  ('continue','ai-coding'),
  ('aider','ai-coding'),
  ('zed','ai-coding'),
  ('void','ai-coding'),
  ('openhands','ai-coding'),
  ('openhands','ai-automation'),
  ('llamaindex','ai-automation'),
  ('llamaindex','ai-infrastructure'),
  ('langflow','ai-automation'),
  ('ragflow','ai-research'),
  ('ragflow','ai-automation'),
  ('perplexica','ai-research'),
  ('khoj','ai-research'),
  ('khoj','ai-productivity'),
  ('open-sora','ai-video'),
  ('penpot','ai-design'),
  ('excalidraw','ai-design'),
  ('excalidraw','ai-productivity'),
  ('appflowy','ai-productivity'),
  ('logseq','ai-productivity'),
  ('chroma','ai-infrastructure'),
  ('qdrant','ai-infrastructure')
  ) as x(tool_slug, category_slug)
  join public.tools t      on t.slug = x.tool_slug
  join public.categories c on c.slug = x.category_slug
on conflict (tool_id, category_id) do nothing;
