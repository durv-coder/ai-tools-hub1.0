-- ============================================================================
-- AI TOOLS HUB — 0008 data corrections
--
-- Everything here was verified against a live source before being applied.
-- No fabricated values are introduced; several are removed.
-- ============================================================================

-- ---------------------------------------------------------------------------
-- 1. Canonical repository URLs.
--
-- Eight repositories have moved. GitHub redirects, so these links still work in
-- a browser, but the stored URL is not canonical and will break if the old path
-- is ever reclaimed. Each target below was confirmed by requesting the old URL
-- and reading the location GitHub redirects to.
-- ---------------------------------------------------------------------------
update public.tools as t
set repo_url = v.url
from (values
  ('jan',        'https://github.com/janhq/jan'),
  ('perplexica', 'https://github.com/ItzCrazyKns/Vane'),
  ('dub',        'https://github.com/dubinc/dub.link'),
  ('comfyui',    'https://github.com/Comfy-Org/ComfyUI'),
  ('librechat',  'https://github.com/LibreChat-AI/LibreChat'),
  ('openedx',    'https://github.com/openedx/openedx-platform'),
  ('openhands',  'https://github.com/OpenHands/OpenHands'),
  ('vale',       'https://github.com/vale-cli/vale')
) as v(slug, url)
where t.slug = v.slug;

-- ---------------------------------------------------------------------------
-- 2. Perplexica was renamed to Vane.
--
-- The repository `ItzCrazyKns/Perplexica` now redirects to `ItzCrazyKns/Vane`
-- and describes itself as "Vane is an AI-powered answering engine". The slug is
-- left alone on purpose: it is the public URL (/tools/perplexica) and changing
-- it would break existing links for no benefit. The display name, however, was
-- simply wrong.
-- ---------------------------------------------------------------------------
update public.tools set
  name        = 'Vane',
  tagline     = 'Open-source AI answering engine.',
  description = 'A self-hosted answering engine that searches the web and cites its sources, '
                || 'so the reasoning can be checked rather than taken on trust. Runs against '
                || 'local models or a hosted provider. Formerly released as Perplexica; the '
                || 'repository and product were renamed to Vane.',
  website_url = 'https://github.com/ItzCrazyKns/Vane',
  repo_url    = 'https://github.com/ItzCrazyKns/Vane'
where slug = 'perplexica';

-- ---------------------------------------------------------------------------
-- 3. Void's repository was archived on 2 June 2026.
--
-- The project is still downloadable and the licence (Apache-2.0) still applies,
-- so `is_open_source` stays true — but a reader deserves to know the source is
-- now a read-only archive, not a maintained codebase.
-- ---------------------------------------------------------------------------
update public.tools set
  description = 'An AI code editor built as a fork of VS Code, with inline edits, '
                || 'tab completion and an agent mode, running against any model you '
                || 'supply. Note: the public repository was archived on 2 June 2026 and '
                || 'is now read-only, so it is no longer actively developed in the open.'
where slug = 'void';

-- ---------------------------------------------------------------------------
-- 4. Tome is gone.
--
-- tome.app returns HTTP 404 (a Vercel DEPLOYMENT_NOT_FOUND page), so the tool
-- cannot be used or purchased. Rather than delete the row and lose its history,
-- it is moved to `archived`, which hides it from every public query.
-- ---------------------------------------------------------------------------
update public.tools
set status = 'archived'
where slug = 'tome';

-- ---------------------------------------------------------------------------
-- 5. Remove fabricated view counts.
--
-- These numbers came from a hard-coded table in the seed script and were never
-- measured. 19 tools still sat at the literal default of 2000. Showing "48,207
-- views" that was invented is the same problem the ratings had, so the counts
-- are preserved for reference and reset to zero. From here on the only thing
-- that moves view_count is `register_tool_view()`, which increments on a real
-- page load.
-- ---------------------------------------------------------------------------
create table if not exists public.tools_view_backup as
select slug, view_count, now() as backed_up_at
from public.tools where view_count > 0;

update public.tools set view_count = 0 where view_count > 0;

-- ---------------------------------------------------------------------------
-- Verification
-- ---------------------------------------------------------------------------
select
  (select count(*) from public.tools where status = 'archived')            as archived_tools,
  (select count(*) from public.tools where view_count > 0)                 as nonzero_views,
  (select count(*) from public.tools where repo_url like '%Perplexica%')   as stale_perplexica,
  (select count(*) from public.tools_view_backup)                          as view_backup_rows;
