-- 0009_view_rate_limit.sql
--
-- The view counter used to be an open increment: ten scripted POSTs to
-- /api/view added ten views, which mattered because the "trending" rail sorts by
-- view_count. This migration records the fix that was applied directly to the
-- live database, so a rebuilt project gets the same protection.
--
-- Idempotent: safe to run against a database that already has these objects.

begin;

-- One row per (tool, client, hour). The primary key is the rate limiter: a second
-- view from the same client in the same hour collides and increments nothing.
create table if not exists public.tool_view_hits (
  tool_id      uuid        not null references public.tools(id) on delete cascade,
  client_key   text        not null,
  hour_bucket  timestamptz not null,
  created_at   timestamptz not null default now(),
  primary key (tool_id, client_key, hour_bucket)
);

-- RLS on with no policies: the table is an implementation detail. Only the
-- SECURITY DEFINER function below may touch it. Without this, anon could delete
-- its own hit row and vote again.
alter table public.tool_view_hits enable row level security;

-- The original single-argument version had no rate limiting at all. Dropping it
-- removes the bypass path, because PostgREST resolves by argument count.
drop function if exists public.register_tool_view(uuid);

create or replace function public.register_tool_view(
  p_tool_id    uuid,
  p_client_key text default 'unknown'
)
returns boolean
language plpgsql
security definer
set search_path = public
as $$
declare
  inserted integer;
  bucket   timestamptz := date_trunc('hour', now());
begin
  insert into public.tool_view_hits (tool_id, client_key, hour_bucket)
  values (p_tool_id, left(coalesce(p_client_key, 'unknown'), 64), bucket)
  on conflict (tool_id, client_key, hour_bucket) do nothing;

  get diagnostics inserted = row_count;

  -- Only count the view when the bucket row is new.
  if inserted > 0 then
    update public.tools
       set view_count = view_count + 1
     where id = p_tool_id
       and status = 'published';
    return true;
  end if;

  return false;
end;
$$;

-- Callable by anonymous visitors: the route runs without a session.
revoke all on function public.register_tool_view(uuid, text) from public;
grant execute on function public.register_tool_view(uuid, text) to anon, authenticated;

commit;
