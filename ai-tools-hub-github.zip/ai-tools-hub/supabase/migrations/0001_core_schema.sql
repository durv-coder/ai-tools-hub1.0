-- ============================================================================
-- AI TOOLS HUB — 0001 core schema
-- Non-destructive. Adds tables, extends the existing favorites table,
-- and leaves themes / theme_categories untouched.
-- ============================================================================

create extension if not exists pg_trgm;

-- ---------------------------------------------------------------------------
-- CATEGORIES
-- ---------------------------------------------------------------------------
create table if not exists public.categories (
  id          bigint generated always as identity primary key,
  name        text        not null unique,
  slug        text        not null unique,
  description text,
  icon        text        not null default 'sparkles',
  sort_order  integer     not null default 0,
  created_at  timestamptz not null default now(),
  constraint categories_slug_format check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$')
);

-- ---------------------------------------------------------------------------
-- PROFILES  (1:1 with auth.users, auto-created by trigger)
-- ---------------------------------------------------------------------------
create table if not exists public.profiles (
  id         uuid primary key references auth.users(id) on delete cascade,
  email      text,
  full_name  text,
  username   text unique,
  avatar_url text,
  bio        text,
  role       text not null default 'user',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint profiles_role_values check (role in ('user', 'admin')),
  constraint profiles_full_name_len check (full_name is null or char_length(full_name) between 1 and 80),
  constraint profiles_bio_len check (bio is null or char_length(bio) <= 500),
  constraint profiles_username_format check (
    username is null or username ~ '^[a-zA-Z0-9_]{3,30}$'
  )
);

-- ---------------------------------------------------------------------------
-- TOOLS
-- ---------------------------------------------------------------------------
create table if not exists public.tools (
  id           uuid primary key default gen_random_uuid(),
  slug         text not null unique,
  name         text not null,
  tagline      text not null,
  description  text,
  website_url  text not null,
  logo_url     text,
  pricing_model text not null default 'freemium',
  starting_price text,
  tags         text[] not null default '{}',
  is_featured  boolean not null default false,
  is_trending  boolean not null default false,
  status       text not null default 'published',
  rating       numeric(2,1) not null default 0,
  rating_count integer not null default 0,
  favorite_count integer not null default 0,
  view_count   integer not null default 0,
  added_at     timestamptz not null default now(),
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now(),
  constraint tools_pricing_values   check (pricing_model in ('free', 'freemium', 'paid')),
  constraint tools_status_values    check (status in ('published', 'draft', 'archived')),
  constraint tools_rating_range     check (rating >= 0 and rating <= 5),
  constraint tools_name_len         check (char_length(name) between 1 and 60),
  constraint tools_tagline_len      check (char_length(tagline) between 1 and 120),
  constraint tools_slug_format      check (slug ~ '^[a-z0-9]+(-[a-z0-9]+)*$'),
  constraint tools_url_scheme       check (website_url ~ '^https?://'),
  constraint tools_tags_limit       check (array_length(tags, 1) is null or array_length(tags, 1) <= 12)
);

-- many-to-many: a tool can sit in several categories
create table if not exists public.tool_categories (
  tool_id     uuid   not null references public.tools(id)      on delete cascade,
  category_id bigint not null references public.categories(id) on delete cascade,
  primary key (tool_id, category_id)
);

-- ---------------------------------------------------------------------------
-- FAVORITES — extend the existing table, preserving it and its policies
-- ---------------------------------------------------------------------------
alter table public.favorites
  add column if not exists tool_id uuid references public.tools(id) on delete cascade;

-- keep legacy tool_name (nullable, unused going forward) so nothing is destroyed
alter table public.favorites
  alter column tool_name drop not null;

update public.favorites f
   set tool_id = t.id
  from public.tools t
 where f.tool_id is null
   and lower(trim(f.tool_name)) = lower(t.name);

create unique index if not exists favorites_user_tool_key
  on public.favorites (user_id, tool_id)
  where tool_id is not null;

create index if not exists favorites_user_idx on public.favorites (user_id);

-- ---------------------------------------------------------------------------
-- RECENTLY VIEWED
-- ---------------------------------------------------------------------------
create table if not exists public.recently_viewed (
  id        bigint generated always as identity primary key,
  user_id   uuid not null references auth.users(id) on delete cascade,
  tool_id   uuid not null references public.tools(id) on delete cascade,
  viewed_at timestamptz not null default now(),
  unique (user_id, tool_id)
);

create index if not exists recently_viewed_user_time_idx
  on public.recently_viewed (user_id, viewed_at desc);

-- ---------------------------------------------------------------------------
-- REVIEWS
-- ---------------------------------------------------------------------------
create table if not exists public.reviews (
  id         uuid primary key default gen_random_uuid(),
  tool_id    uuid not null references public.tools(id) on delete cascade,
  user_id    uuid not null references auth.users(id) on delete cascade,
  rating     smallint not null,
  title      text,
  body       text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (tool_id, user_id),
  constraint reviews_rating_range check (rating between 1 and 5),
  constraint reviews_title_len    check (title is null or char_length(title) <= 120),
  constraint reviews_body_len     check (body  is null or char_length(body)  <= 2000)
);

create index if not exists reviews_tool_idx on public.reviews (tool_id, created_at desc);
create index if not exists reviews_user_idx on public.reviews (user_id);

-- ---------------------------------------------------------------------------
-- USER PREFERENCES
-- ---------------------------------------------------------------------------
create table if not exists public.user_preferences (
  user_id            uuid primary key references auth.users(id) on delete cascade,
  theme              text not null default 'system',
  default_sort       text not null default 'popular',
  email_digest       boolean not null default true,
  favorite_categories bigint[] not null default '{}',
  updated_at         timestamptz not null default now(),
  constraint prefs_theme_values check (theme in ('light', 'dark', 'system')),
  constraint prefs_sort_values  check (default_sort in ('popular', 'rating', 'newest', 'alpha'))
);

-- ---------------------------------------------------------------------------
-- NEWSLETTER
-- ---------------------------------------------------------------------------
create table if not exists public.newsletter_subscribers (
  id         bigint generated always as identity primary key,
  email      text not null unique,
  created_at timestamptz not null default now(),
  constraint newsletter_email_format check (email ~* '^[^@\s]+@[^@\s]+\.[^@\s]+$')
);

-- ---------------------------------------------------------------------------
-- INDEXES
-- ---------------------------------------------------------------------------
create index if not exists tools_status_added_idx   on public.tools (status, added_at desc);
create index if not exists tools_status_rating_idx  on public.tools (status, rating desc, rating_count desc);
create index if not exists tools_status_views_idx   on public.tools (status, view_count desc);
create index if not exists tools_status_name_idx    on public.tools (status, name);
create index if not exists tools_featured_idx       on public.tools (is_featured) where status = 'published';
create index if not exists tools_trending_idx       on public.tools (is_trending) where status = 'published';
create index if not exists tools_pricing_idx        on public.tools (pricing_model) where status = 'published';
create index if not exists tools_tags_gin_idx       on public.tools using gin (tags);
create index if not exists tools_name_trgm_idx      on public.tools using gin (name gin_trgm_ops);

-- full text search over the fields people actually search
create index if not exists tools_fts_idx on public.tools using gin (
  to_tsvector(
    'english',
    coalesce(name, '') || ' ' ||
    coalesce(tagline, '') || ' ' ||
    coalesce(description, '') || ' ' ||
    coalesce(array_to_string(tags, ' '), '')
  )
);

create index if not exists categories_sort_idx on public.categories (sort_order);
create index if not exists tool_categories_category_idx on public.tool_categories (category_id);

-- ---------------------------------------------------------------------------
-- HELPERS
-- ---------------------------------------------------------------------------
create or replace function public.touch_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

-- role check used by every admin RLS policy. SECURITY DEFINER so the lookup
-- is not itself subject to the profiles RLS policy (which would recurse).
create or replace function public.is_admin()
returns boolean
language sql
stable
security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.profiles
     where id = auth.uid() and role = 'admin'
  );
$$;

revoke execute on function public.is_admin() from public;
grant  execute on function public.is_admin() to anon, authenticated;

-- ---------------------------------------------------------------------------
-- TRIGGERS: updated_at
-- ---------------------------------------------------------------------------
drop trigger if exists profiles_touch on public.profiles;
create trigger profiles_touch before update on public.profiles
  for each row execute function public.touch_updated_at();

drop trigger if exists tools_touch on public.tools;
create trigger tools_touch before update on public.tools
  for each row execute function public.touch_updated_at();

drop trigger if exists reviews_touch on public.reviews;
create trigger reviews_touch before update on public.reviews
  for each row execute function public.touch_updated_at();

-- ---------------------------------------------------------------------------
-- TRIGGERS: profile + preferences on signup
-- ---------------------------------------------------------------------------
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  insert into public.profiles (id, email, full_name)
  values (
    new.id,
    new.email,
    nullif(trim(coalesce(new.raw_user_meta_data ->> 'full_name', '')), '')
  )
  on conflict (id) do nothing;

  insert into public.user_preferences (user_id)
  values (new.id)
  on conflict (user_id) do nothing;

  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------------------------------------------------------------------------
-- TRIGGER: prevent privilege escalation via profile update
-- ---------------------------------------------------------------------------
create or replace function public.guard_profile_role()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  if new.role is distinct from old.role and not public.is_admin() then
    new.role = old.role;
  end if;
  return new;
end;
$$;

drop trigger if exists profiles_guard_role on public.profiles;
create trigger profiles_guard_role before update on public.profiles
  for each row execute function public.guard_profile_role();

-- ---------------------------------------------------------------------------
-- TRIGGERS: keep aggregate counters honest
-- ---------------------------------------------------------------------------
create or replace function public.sync_tool_rating()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  target uuid := coalesce(new.tool_id, old.tool_id);
begin
  update public.tools t
     set rating       = coalesce((select round(avg(r.rating)::numeric, 1) from public.reviews r where r.tool_id = target), 0),
         rating_count = (select count(*) from public.reviews r where r.tool_id = target)
   where t.id = target;
  return null;
end;
$$;

drop trigger if exists reviews_sync_rating on public.reviews;
create trigger reviews_sync_rating
  after insert or update or delete on public.reviews
  for each row execute function public.sync_tool_rating();

create or replace function public.sync_favorite_count()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
declare
  target uuid := coalesce(new.tool_id, old.tool_id);
begin
  if target is not null then
    update public.tools t
       set favorite_count = (select count(*) from public.favorites f where f.tool_id = target)
     where t.id = target;
  end if;
  return null;
end;
$$;

drop trigger if exists favorites_sync_count on public.favorites;
create trigger favorites_sync_count
  after insert or delete on public.favorites
  for each row execute function public.sync_favorite_count();

-- ---------------------------------------------------------------------------
-- RPC: record a tool view (called from the tool detail page)
-- ---------------------------------------------------------------------------
create or replace function public.register_tool_view(p_tool_id uuid)
returns void
language plpgsql
security definer
set search_path = ''
as $$
begin
  update public.tools set view_count = view_count + 1 where id = p_tool_id;

  if auth.uid() is not null then
    insert into public.recently_viewed (user_id, tool_id, viewed_at)
    values (auth.uid(), p_tool_id, now())
    on conflict (user_id, tool_id) do update set viewed_at = now();
  end if;
end;
$$;

revoke execute on function public.register_tool_view(uuid) from public;
grant  execute on function public.register_tool_view(uuid) to anon, authenticated;

-- keep only the 12 most recent views per user
create or replace function public.trim_recently_viewed()
returns trigger
language plpgsql
security definer
set search_path = ''
as $$
begin
  delete from public.recently_viewed
   where user_id = new.user_id
     and id not in (
       select id from public.recently_viewed
        where user_id = new.user_id
        order by viewed_at desc
        limit 24
     );
  return null;
end;
$$;

drop trigger if exists recently_viewed_trim on public.recently_viewed;
create trigger recently_viewed_trim
  after insert or update on public.recently_viewed
  for each row execute function public.trim_recently_viewed();
