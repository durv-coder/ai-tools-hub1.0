-- ============================================================================
-- AI TOOLS HUB — 0002 row level security
-- Every table is default-deny. Public read is explicitly granted only for
-- published content; every write is scoped to the owning user or an admin.
-- ============================================================================

alter table public.categories            enable row level security;
alter table public.profiles              enable row level security;
alter table public.tools                 enable row level security;
alter table public.tool_categories       enable row level security;
alter table public.reviews               enable row level security;
alter table public.recently_viewed       enable row level security;
alter table public.user_preferences      enable row level security;
alter table public.newsletter_subscribers enable row level security;
-- public.favorites already has RLS enabled from the original project

-- ---------------------------------------------------------------------------
-- CATEGORIES: everyone reads, admins write
-- ---------------------------------------------------------------------------
drop policy if exists "categories_public_read" on public.categories;
create policy "categories_public_read" on public.categories
  for select to anon, authenticated using (true);

drop policy if exists "categories_admin_insert" on public.categories;
create policy "categories_admin_insert" on public.categories
  for insert to authenticated with check (public.is_admin());

drop policy if exists "categories_admin_update" on public.categories;
create policy "categories_admin_update" on public.categories
  for update to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "categories_admin_delete" on public.categories;
create policy "categories_admin_delete" on public.categories
  for delete to authenticated using (public.is_admin());

-- ---------------------------------------------------------------------------
-- TOOLS: published rows are public, admins see and manage everything
-- ---------------------------------------------------------------------------
drop policy if exists "tools_public_read" on public.tools;
create policy "tools_public_read" on public.tools
  for select to anon, authenticated using (status = 'published');

drop policy if exists "tools_admin_read_all" on public.tools;
create policy "tools_admin_read_all" on public.tools
  for select to authenticated using (public.is_admin());

drop policy if exists "tools_admin_insert" on public.tools;
create policy "tools_admin_insert" on public.tools
  for insert to authenticated with check (public.is_admin());

drop policy if exists "tools_admin_update" on public.tools;
create policy "tools_admin_update" on public.tools
  for update to authenticated using (public.is_admin()) with check (public.is_admin());

drop policy if exists "tools_admin_delete" on public.tools;
create policy "tools_admin_delete" on public.tools
  for delete to authenticated using (public.is_admin());

-- ---------------------------------------------------------------------------
-- TOOL_CATEGORIES
-- ---------------------------------------------------------------------------
drop policy if exists "tool_categories_public_read" on public.tool_categories;
create policy "tool_categories_public_read" on public.tool_categories
  for select to anon, authenticated using (
    exists (select 1 from public.tools t where t.id = tool_id and t.status = 'published')
    or public.is_admin()
  );

drop policy if exists "tool_categories_admin_write" on public.tool_categories;
create policy "tool_categories_admin_write" on public.tool_categories
  for all to authenticated using (public.is_admin()) with check (public.is_admin());

-- ---------------------------------------------------------------------------
-- PROFILES: own row or admin; email is never exposed to other users
-- ---------------------------------------------------------------------------
drop policy if exists "profiles_select_own" on public.profiles;
create policy "profiles_select_own" on public.profiles
  for select to authenticated using (id = (select auth.uid()) or public.is_admin());

drop policy if exists "profiles_update_own" on public.profiles;
create policy "profiles_update_own" on public.profiles
  for update to authenticated
  using (id = (select auth.uid()) or public.is_admin())
  with check (id = (select auth.uid()) or public.is_admin());

drop policy if exists "profiles_admin_delete" on public.profiles;
create policy "profiles_admin_delete" on public.profiles
  for delete to authenticated using (public.is_admin());

-- inserts happen only through the SECURITY DEFINER signup trigger

-- ---------------------------------------------------------------------------
-- FAVORITES: strictly own rows (replaces the original three policies with an
-- equivalent, tool-id aware set). Nothing is lost: the rule is unchanged.
-- ---------------------------------------------------------------------------
drop policy if exists "Users can view their own favorites" on public.favorites;
drop policy if exists "Users can add their own favorites" on public.favorites;
drop policy if exists "Users can delete their own favorites" on public.favorites;

drop policy if exists "favorites_select_own" on public.favorites;
create policy "favorites_select_own" on public.favorites
  for select to authenticated using ((select auth.uid()) = user_id);

drop policy if exists "favorites_insert_own" on public.favorites;
create policy "favorites_insert_own" on public.favorites
  for insert to authenticated with check ((select auth.uid()) = user_id);

drop policy if exists "favorites_delete_own" on public.favorites;
create policy "favorites_delete_own" on public.favorites
  for delete to authenticated using ((select auth.uid()) = user_id);

-- ---------------------------------------------------------------------------
-- RECENTLY_VIEWED
-- ---------------------------------------------------------------------------
drop policy if exists "recently_viewed_select_own" on public.recently_viewed;
create policy "recently_viewed_select_own" on public.recently_viewed
  for select to authenticated using ((select auth.uid()) = user_id);

drop policy if exists "recently_viewed_manage_own" on public.recently_viewed;
create policy "recently_viewed_manage_own" on public.recently_viewed
  for all to authenticated
  using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);

-- ---------------------------------------------------------------------------
-- REVIEWS: public read, one review per user per tool, admins may moderate
-- ---------------------------------------------------------------------------
drop policy if exists "reviews_public_read" on public.reviews;
create policy "reviews_public_read" on public.reviews
  for select to anon, authenticated using (
    exists (select 1 from public.tools t where t.id = tool_id and t.status = 'published')
    or user_id = (select auth.uid())
    or public.is_admin()
  );

drop policy if exists "reviews_insert_own" on public.reviews;
create policy "reviews_insert_own" on public.reviews
  for insert to authenticated with check (
    (select auth.uid()) = user_id
    and exists (select 1 from public.tools t where t.id = tool_id and t.status = 'published')
  );

drop policy if exists "reviews_update_own" on public.reviews;
create policy "reviews_update_own" on public.reviews
  for update to authenticated
  using ((select auth.uid()) = user_id or public.is_admin())
  with check ((select auth.uid()) = user_id or public.is_admin());

drop policy if exists "reviews_delete_own" on public.reviews;
create policy "reviews_delete_own" on public.reviews
  for delete to authenticated using ((select auth.uid()) = user_id or public.is_admin());

-- ---------------------------------------------------------------------------
-- USER_PREFERENCES
-- ---------------------------------------------------------------------------
drop policy if exists "preferences_select_own" on public.user_preferences;
create policy "preferences_select_own" on public.user_preferences
  for select to authenticated using ((select auth.uid()) = user_id);

drop policy if exists "preferences_update_own" on public.user_preferences;
create policy "preferences_update_own" on public.user_preferences
  for all to authenticated
  using ((select auth.uid()) = user_id)
  with check ((select auth.uid()) = user_id);

-- ---------------------------------------------------------------------------
-- NEWSLETTER: anonymous users may subscribe, nobody may read the list
-- ---------------------------------------------------------------------------
drop policy if exists "newsletter_anon_insert" on public.newsletter_subscribers;
create policy "newsletter_anon_insert" on public.newsletter_subscribers
  for insert to anon, authenticated with check (true);

drop policy if exists "newsletter_admin_read" on public.newsletter_subscribers;
create policy "newsletter_admin_read" on public.newsletter_subscribers
  for select to authenticated using (public.is_admin());
