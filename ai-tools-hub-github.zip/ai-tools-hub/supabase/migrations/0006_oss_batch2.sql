-- ============================================================================
-- AI TOOLS HUB — open-source tools, batch 2 (fills education, marketing, writing, video, design)
-- Licenses verified against the GitHub license API and each repository's
-- LICENSE file. SPDX identifiers recorded as GitHub reports them.
--
-- NOT included, because these are not OSI-approved open source despite being
-- routinely described as such (each verified):
--   open-webui  Open WebUI License, BSD-3 + branding clause (NOASSERTION)
--   n8n         Sustainable Use License ("fair-code")
--   dify        Apache 2.0 + additional conditions
--   lobe-chat   LobeHub Community License, Apache 2.0 + conditions
-- ============================================================================


insert into public.tools
  (slug, name, tagline, description, website_url, pricing_model, tags,
   is_featured, is_trending, rating, rating_count, view_count, added_at,
   is_open_source, repo_url, license)
values

  ('anki','Anki','Spaced repetition that makes facts stick.','A flashcard system built around spaced repetition, scheduling each card just before you would have forgotten it. Used mostly for language vocabulary and exam revision; decks sync across desktop and mobile, and shared decks exist for thousands of subjects.','https://apps.ankiweb.net/','free',array['flashcards','spaced-repetition','study'],false,false,0,0,2000,now() - interval '90 days',true,'https://github.com/ankitects/anki','AGPL-3.0'),
  ('openedx','Open edX','Run full online courses at university scale.','The platform behind edX: course authoring, video lessons, graded problem sets, discussion forums and certificates, all self-hosted. Built for institutions running many learners across many courses rather than a single class.','https://openedx.org/','free',array['courses','lms','self-hosted','education'],false,false,0,0,2000,now() - interval '90 days',true,'https://github.com/openedx/edx-platform','AGPL-3.0'),
  ('moodle','Moodle','The long-standing open-source learning platform.','A learning management system used by schools and universities for assignments, quizzes, gradebooks and course delivery. Mature plugin ecosystem and integrations with student information systems; the trade-off is an older interface and real administrative overhead.','https://moodle.org/','freemium',array['lms','courses','quizzes','education'],false,false,0,0,2000,now() - interval '90 days',true,'https://github.com/moodle/moodle','GPL-3.0'),
  ('freecodecamp','freeCodeCamp','Learn to code with a free, structured curriculum.','Thousands of hours of interactive coding lessons, projects and certifications, plus a large library of tutorials. Entirely free and non-profit, with the whole curriculum and platform open source for anyone to run or fork.','https://www.freecodecamp.org/','free',array['learning','coding','curriculum','non-profit'],true,false,0,0,2000,now() - interval '90 days',true,'https://github.com/freeCodeCamp/freeCodeCamp','BSD-3-Clause'),
  ('listmonk','listmonk','Self-hosted newsletter and mailing list manager.','Sends campaigns and transactional mail to large lists through your own SMTP provider, with list management, templates, bounce handling and analytics in one binary. A practical self-hosted alternative to paid newsletter platforms.','https://listmonk.app/','free',array['newsletter','email','self-hosted','marketing'],true,false,0,0,2000,now() - interval '90 days',true,'https://github.com/knadh/listmonk','AGPL-3.0'),
  ('mautic','Mautic','Marketing automation you host yourself.','Multi-channel marketing automation covering email campaigns, landing pages, lead scoring and nurture sequences tied to contact behaviour. The closest open-source analogue to HubSpot or Marketo, with the operational weight that implies.','https://www.mautic.org/','free',array['marketing-automation','leads','email','self-hosted'],false,false,0,0,2000,now() - interval '90 days',true,'https://github.com/mautic/mautic','AGPL-3.0'),
  ('dub','Dub','Link shortener with real conversion analytics.','Short links with click analytics, conversion tracking, custom domains and team workspaces. Useful where campaign attribution matters — you can see which channel actually drove signups rather than only clicks.','https://dub.co/','freemium',array['links','analytics','attribution','marketing'],false,false,0,0,2000,now() - interval '90 days',true,'https://github.com/dubinc/dub','AGPL-3.0'),
  ('umami','Umami','Simple, privacy-first web analytics.','A lightweight analytics dashboard that reports traffic and referrers without cookies or personal data collection. Deliberately small and readable, so it stays fast and avoids the consent banners heavier analytics tools trigger.','https://umami.is/','freemium',array['analytics','privacy','self-hosted','cookieless'],false,true,0,0,2000,now() - interval '30 days',true,'https://github.com/umami-software/umami','MIT'),
  ('posthog','PostHog','Product analytics with session replay built in.','Combines event analytics, session replay, feature flags, A/B tests and surveys, so product questions can be answered without stitching several vendors together. Can be self-hosted, though the open-source edition is aimed at smaller scale deployments.','https://posthog.com/','freemium',array['analytics','session-replay','feature-flags','product'],false,false,0,0,2000,now() - interval '90 days',true,'https://github.com/PostHog/posthog','MIT'),
  ('chatwoot','Chatwoot','Shared inbox for customer conversations.','Pulls website chat, email and messaging channels into one agent inbox with canned replies, assignment and reporting. An open-source alternative to Intercom or Zendesk that can run entirely on your own infrastructure.','https://www.chatwoot.com/','freemium',array['support','inbox','chat','self-hosted'],false,false,0,0,2000,now() - interval '90 days',true,'https://github.com/chatwoot/chatwoot','MIT'),
  ('matomo','Matomo','Full analytics suite that keeps data on your server.','Web and app analytics with goals, funnels, heatmaps and segmentation, where the raw data stays on infrastructure you control. The most complete open-source answer to Google Analytics, including a documented path to import historical data.','https://matomo.org/','freemium',array['analytics','privacy','self-hosted','gdpr'],false,false,0,0,2000,now() - interval '90 days',true,'https://github.com/matomo-org/matomo','GPL-3.0'),
  ('languagetool','LanguageTool','Grammar and style checker for 30+ languages.','Checks spelling, grammar and punctuation across many languages, with style rules that catch repeated words and clumsy phrasing. Runs as a browser extension, desktop app or self-hosted server, so text need not leave your machine.','https://languagetool.org/','freemium',array['grammar','proofreading','multilingual','writing'],true,false,0,0,2000,now() - interval '90 days',true,'https://github.com/languagetool-org/languagetool','LGPL-2.1'),
  ('vale','Vale','Linter that enforces your house writing style.','A command-line prose linter that applies style rules to documentation and articles, flagging passive voice, jargon and inconsistent terminology. Configurable rule sets mean it enforces your style guide automatically in CI.','https://vale.sh/','free',array['linting','style-guide','docs','cli'],false,false,0,0,2000,now() - interval '90 days',true,'https://github.com/errata-ai/vale','MIT'),
  ('harper','Harper','Offline grammar checker built for developers.','A fast, privacy-respecting grammar and spelling checker that runs locally with no network round trip, including in code comments and commit messages. Designed for editor and CI integration rather than as a separate web app.','https://writewithharper.com/','free',array['grammar','offline','developer','editor'],false,false,0,0,2000,now() - interval '90 days',true,'https://github.com/Automattic/harper','Apache-2.0'),
  ('zettlr','Zettlr','Markdown editor for long-form academic writing.','A markdown editor aimed at researchers: citation management via Zotero or BibTeX, footnotes, and export to LaTeX or Word. Suited to essays and theses where references and structure matter as much as the prose.','https://www.zettlr.com/','free',array['markdown','citations','academic','editor'],false,false,0,0,2000,now() - interval '90 days',true,'https://github.com/Zettlr/Zettlr','GPL-3.0'),
  ('ghost','Ghost','Publishing platform for blogs and newsletters.','A modern publishing platform with a clean editor, memberships, paid subscriptions and built-in newsletter delivery. Runs on your own server, which keeps subscriber lists and revenue under your control rather than a platform''s.','https://ghost.org/','freemium',array['publishing','blog','newsletter','memberships'],false,false,0,0,2000,now() - interval '90 days',true,'https://github.com/TryGhost/Ghost','MIT'),
  ('novel','Novel','Notion-style AI writing editor you can self-host.','A block-based editor with inline autocomplete and slash commands, built on the Tiptap editor. Usable as a writing surface or embedded in your own product; bringing your own model key keeps generation costs and data in your hands.','https://novel.sh/','free',array['editor','notion-style','ai-completion','self-hosted'],false,false,0,0,2000,now() - interval '90 days',true,'https://github.com/steven-tey/novel','Apache-2.0'),
  ('moneyprinterturbo','MoneyPrinterTurbo','Generate a narrated short video from a prompt.','Takes a subject and produces a short vertical video: writes the script, sources stock footage, adds voiceover and subtitles. Runs locally against your chosen model provider, so no footage or script is sent to a hosted service.','https://github.com/harry0703/MoneyPrinterTurbo','free',array['video-generation','shorts','voiceover','automation'],false,true,0,0,2000,now() - interval '30 days',true,'https://github.com/harry0703/MoneyPrinterTurbo','MIT'),
  ('opencut','OpenCut','Browser-based video editor, no upload needed.','A timeline video editor that runs in the browser, so project media never leaves the machine. Covers trimming, layering and captions — the everyday editing tasks that otherwise push people to paid cloud editors.','https://opencut.app/','free',array['video-editing','timeline','browser','privacy'],false,true,0,0,2000,now() - interval '30 days',true,'https://github.com/OpenCut-app/OpenCut','MIT'),
  ('diffusers','Diffusers','The standard library for diffusion image models.','Hugging Face''s library for running and training diffusion models: text-to-image, image-to-image, inpainting and video pipelines with a shared interface. The practical way to script image generation rather than click through a UI.','https://huggingface.co/docs/diffusers','free',array['diffusion','image-generation','library','python'],false,true,0,0,2000,now() - interval '30 days',true,'https://github.com/huggingface/diffusers','Apache-2.0'),
  ('blender','Blender','Full 3D pipeline, plus AI-assisted plugins.','Complete 3D suite for modelling, rigging, animation, simulation and rendering. Relevant here because its Python API makes it the usual host for AI mesh generation, motion capture and frame-interpolation add-ons.','https://www.blender.org/','free',array['3d','animation','rendering','open-source'],true,false,0,0,2000,now() - interval '90 days',true,'https://github.com/blender/blender','GPL-3.0'),
  ('zotero','Zotero','Collect, cite and share research sources.','Reference manager that captures sources from the browser, keeps PDFs, and generates citations in thousands of styles for Word, LibreOffice and LaTeX. Group libraries let a team share a reading list.','https://www.zotero.org/','freemium',array['citations','references','research','pdf'],false,false,0,0,2000,now() - interval '90 days',true,'https://github.com/zotero/zotero','AGPL-3.0'),
  ('paperless-ngx','Paperless-ngx','Turn paper documents into a searchable archive.','Scans, OCRs and files documents with automatic tagging and full-text search, replacing the filing cabinet and the folder full of PDFs. Runs on modest hardware and can feed a retrieval pipeline for document question answering.','https://docs.paperless-ngx.com/','free',array['ocr','documents','archive','self-hosted'],false,false,0,0,2000,now() - interval '90 days',true,'https://github.com/paperless-ngx/paperless-ngx','GPL-3.0'),
  ('plane','Plane','Issue tracking and project planning, self-hosted.','Issue tracking with cycles, modules, roadmaps and views, positioned as an open-source alternative to Jira or Linear. Self-hosting keeps project data on your own infrastructure.','https://plane.so/','freemium',array['issues','project-management','roadmap','self-hosted'],false,true,0,0,2000,now() - interval '30 days',true,'https://github.com/makeplane/plane','AGPL-3.0'),
  ('windmill','Windmill','Turn scripts into workflows and internal UIs.','Write a script in Python, TypeScript or Go and Windmill turns it into a scheduled job, webhook endpoint or internal tool with a generated interface. Handy for gluing AI calls into repeatable pipelines with retries and logs.','https://www.windmill.dev/','freemium',array['workflows','automation','scripts','internal-tools'],false,true,0,0,2000,now() - interval '30 days',true,'https://github.com/windmill-labs/windmill','AGPL-3.0'),
  ('activepieces','Activepieces','Open-source Zapier alternative.','A no-code automation builder with hundreds of connectors, branching and scheduled flows. Easier for non-developers than a scripting tool, and can be self-hosted so credentials stay in your own environment.','https://www.activepieces.com/','freemium',array['automation','no-code','connectors','workflows'],false,false,0,0,2000,now() - interval '90 days',true,'https://github.com/activepieces/activepieces','MIT'),
  ('huginn','Huginn','Agents that monitor the web and notify you.','A long-running system of agents that watch RSS feeds, websites and APIs, then filter, combine and act on what they find. Suited to monitoring and alerting rather than one-off tasks.','https://github.com/huginn/huginn','free',array['monitoring','agents','rss','self-hosted'],false,false,0,0,2000,now() - interval '90 days',true,'https://github.com/huginn/huginn','MIT'),
  ('cline','Cline','Coding agent that works inside your editor.','An agentic coding assistant for VS Code that reads files, edits code, runs commands and uses the browser to verify its own work, asking for approval at each step. Bring your own model key, including local models.','https://cline.bot/','free',array['coding-agent','vscode','autonomous','byo-key'],true,true,0,0,2000,now() - interval '30 days',true,'https://github.com/cline/cline','Apache-2.0')
on conflict (slug) do update set
  is_open_source = excluded.is_open_source,
  repo_url       = excluded.repo_url,
  license        = excluded.license,
  description    = excluded.description,
  tagline        = excluded.tagline;

insert into public.tool_categories (tool_id, category_id)
select t.id, c.id
  from (values

  ('anki','ai-education'),
  ('openedx','ai-education'),
  ('moodle','ai-education'),
  ('freecodecamp','ai-education'),
  ('freecodecamp','ai-coding'),
  ('listmonk','ai-marketing'),
  ('mautic','ai-marketing'),
  ('dub','ai-marketing'),
  ('dub','ai-productivity'),
  ('umami','ai-marketing'),
  ('umami','ai-productivity'),
  ('posthog','ai-marketing'),
  ('posthog','ai-productivity'),
  ('chatwoot','ai-marketing'),
  ('chatwoot','ai-chatbots'),
  ('matomo','ai-marketing'),
  ('matomo','ai-productivity'),
  ('languagetool','ai-writing'),
  ('vale','ai-writing'),
  ('vale','ai-coding'),
  ('harper','ai-writing'),
  ('zettlr','ai-writing'),
  ('zettlr','ai-research'),
  ('ghost','ai-writing'),
  ('ghost','ai-marketing'),
  ('novel','ai-writing'),
  ('novel','ai-productivity'),
  ('moneyprinterturbo','ai-video'),
  ('opencut','ai-video'),
  ('opencut','ai-design'),
  ('diffusers','ai-image'),
  ('diffusers','ai-infrastructure'),
  ('blender','ai-design'),
  ('blender','ai-video'),
  ('zotero','ai-research'),
  ('paperless-ngx','ai-productivity'),
  ('paperless-ngx','ai-research'),
  ('plane','ai-productivity'),
  ('windmill','ai-automation'),
  ('windmill','ai-infrastructure'),
  ('activepieces','ai-automation'),
  ('huginn','ai-automation'),
  ('cline','ai-coding')
  ) as x(tool_slug, category_slug)
  join public.tools t      on t.slug = x.tool_slug
  join public.categories c on c.slug = x.category_slug
on conflict (tool_id, category_id) do nothing;
