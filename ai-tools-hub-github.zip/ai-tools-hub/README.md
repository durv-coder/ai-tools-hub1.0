# AI Tools Hub

A production AI-tool directory: Next.js 16 (App Router, React Server Components), TypeScript,
Supabase (Postgres + Auth) with row-level security on every table.

Built on your existing Supabase project (`iuvxddawxdjexzmhzozz`). The legacy `themes` and
`theme_categories` tables were left untouched; all new content lives in new tables.

---

## Running locally

```bash
npm install
cp .env.example .env.local     # then fill in the two Supabase values
npm run dev                    # http://localhost:3000
```

| Script | Purpose |
| --- | --- |
| `npm run dev` | Dev server with Turbopack |
| `npm run build` | Production build |
| `npm start` | Serve the production build |
| `npm run typecheck` | `tsc --noEmit` |
| `npm test` | Unit + live HTTP checks (Vitest, 36 tests) |

### Environment variables

Three are required and all are public by design — they ship in the client for auth calls and
are constrained by RLS. One optional variable enables automatic rebuilds.

```
NEXT_PUBLIC_SUPABASE_URL=https://<project-ref>.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=sb_publishable_...
NEXT_PUBLIC_SITE_URL=https://your-domain.com     # real domain, or robots.txt says localhost

VERCEL_DEPLOY_HOOK_URL=                          # optional, server-side only
```

**Never put a `service_role` key in `.env.local`.** Nothing in this codebase needs one; every
query runs as the signed-in user or as `anon`, so RLS always applies.

`NEXT_PUBLIC_SITE_URL` must be the deployed origin. When it was left at
`http://localhost:3000`, `/robots.txt` advertised `Host: http://localhost:3000` and every
canonical and OG URL pointed at a machine nobody else can reach.

#### Why the deploy hook exists

Tool pages set `dynamicParams = false`, which is what makes an unknown or archived slug a real
HTTP 404 instead of a 200 carrying a not-found body. I measured the alternative: with
`dynamicParams = true` a production build returned **HTTP 200 for both unknown and archived
slugs**, i.e. a soft 404 on every one of them. That trade was rejected.

The cost is that the slug list is fixed at build time, so a tool published from `/admin` has no
page until the site rebuilds. Publishing therefore fires this hook when it is configured. Without
it, the admin UI says a redeploy is needed — it does not claim the tool is live when it is not.

---

### Tests

`npm test` runs 36 checks with Vitest. No browser is required.

- `tests/types.test.ts` — pure logic: number formatting, initials, and the closed
  contracts for pricing labels and sort keys (the sort list is asserted exactly,
  because a bad `?sort=` value used to fall back silently).
- `tests/validation.test.ts` — the compare-slug filter and the view-counter
  client key, including that `?tools=a&tools=a&tools=a&tools=a&tools=b` dedupes
  to two columns rather than four, and that a raw IP never reaches the key.
- `tests/http.test.ts` — runs against a live server: real 404 status for unknown
  and archived slugs, the trending filter returning a strict subset, all six
  security headers, no service-role key in the HTML, and a sitemap that excludes
  archived tools.

Two variables matter: the suite defaults to `http://localhost:3000`, and it reads
`SITE_BASE` (not `BASE_URL`, which Vitest pre-sets to `/`) to point elsewhere:

```
npm test
SITE_BASE=https://ai-tools-hub-rouge-three.vercel.app npm test
```

## Architecture

```
src/
├── app/
│   ├── page.tsx                 Homepage (rails, stats, categories, newsletter)
│   ├── tools/page.tsx           Directory: search, filters, sort, pagination
│   ├── tools/[slug]/page.tsx    Tool detail, prerendered, JSON-LD
│   ├── categories/              Category index
│   ├── login · signup · reset-password
│   ├── account/                 Dashboard + settings (auth required)
│   ├── actions/                 Server Actions (auth, profile, prefs, favourites)
│   ├── api/                     suggestions, newsletter, view counter, signout
│   ├── sitemap.ts · robots.ts · opengraph-image.tsx
│   └── layout.tsx · error.tsx · not-found.tsx · loading.tsx
├── components/                  Design-system primitives + feature components
├── lib/
│   ├── queries.ts               All reads (server-only)
│   ├── types.ts                 Shared types + formatting
│   └── supabase/                Server client + auth-aware cookie client
├── proxy.ts                     Route protection (Next 16's middleware)
└── app/globals.css + components.css
```

**Data flow.** Server Components call `lib/queries.ts`, which uses the anon key. Reads are
cached with ISR (`revalidate`), so the homepage and every tool page are prerendered static HTML
and served from cache in single-digit milliseconds. Writes go through Server Actions with the
user's cookie session, so RLS enforces ownership rather than application code.

---

## Database

Migrations in `supabase/migrations/`, already applied:

| Table | Purpose | RLS |
| --- | --- | --- |
| `categories` | 13 categories | public read, admin write |
| `tools` | 75 tools, counters, tags, licence metadata, logos | published read, admin write |
| `tool_categories` | many-to-many | public read, admin write |
| `profiles` | 1:1 with `auth.users`, holds `role` | own row or admin |
| `favorites` | extended with `tool_id` FK | own rows only |
| `recently_viewed` | per-user history, trimmed to 24 | own rows only |
| `reviews` | 1 per user per tool | public read, own write |
| `user_preferences` | theme, sort, digest | own row only |
| `newsletter_subscribers` | email capture | insert-only for anon |

Notable database behaviour:

- `handle_new_user()` trigger auto-creates a profile **and** preferences on signup.
- `guard_profile_role()` prevents a user escalating their own `role` to `admin`.
- `sync_tool_rating()` / `sync_favorite_count()` keep aggregates correct on every write.
- `register_tool_view()` is a `SECURITY DEFINER` function that only increments a counter.
- Indexes cover every sort and filter path, plus GIN indexes for tags and full-text search,
  and a partial index `tools_open_source_idx` for the open-source filter.

### Admin access

Roles are stored in `profiles.role`. Your existing account is already `admin`. To promote
someone else:

```sql
-- The role guard silently reverts role changes when there is no session
-- (auth.uid() is null in the SQL editor), so disable it for this one statement.
alter table public.profiles disable trigger profiles_guard_role;
update public.profiles set role = 'admin'
 where id = (select id from auth.users where email = 'someone@example.com');
alter table public.profiles enable trigger profiles_guard_role;
```

Every admin write is gated by `public.is_admin()` **in RLS**, so a hand-crafted request from a
non-admin is rejected by Postgres even with a valid session token.

### Admin panel (`/admin`)

Four sections, all server-rendered and re-authorised on every request:

| Page | What it does |
| --- | --- |
| `/admin` | Counts for tools published/draft/archived, accounts, reviews, favourites and subscribers; most-viewed tools; published tools per category. |
| `/admin/tools` | Search by name or slug, filter by status, paginated. Inline status dropdown and featured/trending toggles. |
| `/admin/tools/new`, `/admin/tools/[id]` | Full create/edit form, plus a delete guarded by a typed `DELETE`. |
| `/admin/categories` | Add, rename and delete categories. Renaming is field-partial so a rename cannot blank the description or icon. |
| `/admin/subscribers` | Newsletter list with source, join date and unsubscribe state. States plainly that sending is not connected. |

Two access-control details worth knowing:

- **Every read uses the session-bound client**, not the anonymous one. `favorites` and
  `profiles` only expose rows to admins through policies calling `is_admin()`, which reads
  `auth.uid()`; an anonymous client is treated as `anon` and silently returns nothing. This
  produced an empty dashboard until it was fixed.
- **Admin reads are additive, not permissive rewrites.** `favorites_admin_select` and
  `profiles_admin_select_all` are *additional* permissive policies scoped to `is_admin()`.
  The existing own-row policies are untouched, so a normal user still sees only their own
  favourites.

Deleting a category that still holds tools is refused rather than orphaning them. Deleting a
tool cascades to its reviews, favourites and category links.

### Verifying RLS yourself

```bash
KEY="<your publishable key>"; U="https://<ref>.supabase.co"
curl "$U/rest/v1/profiles?select=email" -H "apikey: $KEY"     # → []
curl -X POST "$U/rest/v1/tools" -H "apikey: $KEY" \
  -H "Content-Type: application/json" -d '{"slug":"x"}'        # → 42501 RLS violation
```

---

## What is implemented

- **Homepage** — hero with live search, trending / editor's picks / recent / free / premium
  rails, 12-category grid with real counts, stats from live aggregates, newsletter capture.
- **Directory** — server-side search, multi-category and pricing filters, four sort modes,
  pagination, active-filter chips, URL-driven state (shareable and back-button safe),
  collapsible filters on mobile.
- **Compare** — `/compare` puts up to four tools side by side across pricing, rating, licence
  and repository, categories, tags and added date. State lives entirely in the URL
  (`?tools=a&tools=b`), so any comparison is bookmarkable and shareable; the page is
  `force-dynamic` because a static render silently ignores `searchParams` and produced an
  always-empty table. Tools are fetched with one `.in()` query rather than one request per
  column, slugs are de-duplicated before the four-slot cap, and unknown slugs are reported
  by name instead of silently dropped. On narrow screens the label column is sticky and only
  the tool columns scroll, because a 4×7 grid squeezed into 390px is unreadable.
- **Tool pages** — prerendered, related tools, structured data, view counting, outbound link
  hygiene (`noopener`, `nofollow`). Open-source entries additionally show their SPDX licence
  and a link to the source repository.
- **Open source** — 64 of the 103 tools are verified open source, with the licence recorded per
  entry. They surface as a homepage rail, a "Licence → Open source only" filter in the
  directory, a quiet mark on each card, and a licence/source row on the detail page. Every
  licence was checked against the repository's actual `LICENSE` file; projects that are
  *not* OSI-approved (Open WebUI, n8n, Dify, LobeChat, tldraw, and Exercism, which ships no
  licence file at all) were deliberately excluded and the reasoning is recorded in
  `scripts/generate_oss_seed.py`.

  Coverage was deliberately levelled up so no category is a dead end: a second batch
  (`0006_oss_batch2.sql`) added 28 repositories, taking Education, Marketing and Writing
  from zero open-source entries to 4, 8 and 6 respectively. Each entry carries a written
  purpose — what the tool is actually for and who it suits — rather than a marketing line.
  Licence and push-activity data came from the GitHub API at
  `scripts/generate_oss_seed.py`; regenerating is idempotent.

  Adding tools is two commands, and neither rewrites applied history:
  `python3 scripts/generate_oss_seed.py --batch2 <out.sql>` then
  `python3 scripts/fetch_logos.py <out.sql>`.
- **Auth** — email/password signup, login, logout, password reset, session refresh, server-side
  route protection, and messages that do not leak whether an account exists.
- **Account** — favourites, recently viewed, profile editing, password change, preferences.
  Favourites persist in Postgres when signed in; signed-out visitors get an honest
  device-local shortlist with a "sync" prompt.
- **SEO** — per-page metadata, canonicals, Open Graph + Twitter cards, generated OG image,
  dynamic sitemap (121 URLs, all 102 published tools), robots rules, JSON-LD `SoftwareApplication` with `aggregateRating`.
- **Security** — CSP and full header set, RLS everywhere, server-side validation on every write
  path, escaped PostgREST filters, safe error messages, no secrets in client bundles.
- **Accessibility** — single `h1` per page, valid heading outline, skip link, visible focus,
  labelled controls, keyboard-navigable search with `aria-expanded`/`aria-selected`,
  `prefers-reduced-motion` support, zero automated findings.

## Tool logos

68 of the 75 tools have a real logo; the other seven fall back to a letter monogram, which is
the honest outcome rather than a misleading icon.

`scripts/fetch_logos.py` downloads each icon, writes it to `public/logos/`, and generates
`supabase/migrations/0005_tool_logos.sql`. Assets are vendored into the repo on purpose: a
favicon service going down should not empty the directory.

Two quality rules are enforced in the script, both of which matter more than they look:

- **Icons shared by more than one tool are dropped.** Tools hosted on GitHub Pages all resolved
  to the same octocat, so eleven entries would have shown an identical, wrong logo. They fall
  back to monograms instead.
- **Tiny placeholder responses are rejected**, as is the fixed "no favicon" globe.

## Theming

Four warm-neutral palettes — **Warm** (default), **Slate**, **Paper**, **Sand** — each with a
full light and dark set. Mode and palette are independent choices: mode is how light or dark the
page is, palette is its colour family, and every palette works in both.

Everything is driven by CSS custom properties in `src/app/globals.css`:

- Structural tokens (radii, shadow geometry, motion, layout) are defined once in `:root` and
  never change between themes, so switching palette cannot disturb spacing or rhythm.
- Each palette is a pair of blocks: light in `:root[data-palette="…"]`, dark in
  `:root[data-palette="…"][data-theme="dark"]`.
- The `<html>` element carries `data-palette`, `data-theme` (the *resolved* light/dark) and
  `data-theme-mode` (light, dark or system).

**No flash of the wrong theme.** An inline script in `src/app/layout.tsx` runs before first
paint, reads both stored values, resolves `system` against `prefers-color-scheme`, and sets all
three attributes. Previously `system` was saved to preferences but never resolved, so it rendered
as light regardless of the OS setting; that is fixed.

**Custom background images.** A fifth option, **Image**, lets you use any photo instead of a
flat palette — upload a file or paste an `https://` URL. This is where most "photo background"
features fail, so the constraints are deliberate:

- The image is stored in `localStorage` on the device, never uploaded. No bucket, no RLS to
  audit, no untrusted file served back to other users, and it works signed-out.
- Only `https:` URLs and `data:image/{png,jpeg,webp,gif,avif};base64,` data URLs are accepted.
  `javascript:`, `file:` and remote `http:` are rejected before they reach CSS. Uploads are
  capped at 1.5 MB because base64 inflates by a third and `localStorage` caps near 5 MB; going
  over is reported to the user rather than failing silently.
- A scrim in the active palette's own `--bg` is painted over the image (`--bg-image-dim`,
  0–90%). Photographs have unpredictable luminance, so without it body text fails contrast
  wherever the image is light. Default is 60%.
- Card surfaces turn translucent with `backdrop-filter: blur()`, behind an `@supports` check so
  browsers without it fall back to a still-translucent colour.
- Muted ink is darker on this palette than on the flat ones, and text directly on the photo
  gets a subtle halo. Both exist because the same colour that reads fine on `#fbf9f6` can land
  on a mid-grey region of a photo and drop below WCAG AA.
- Measured: against a deliberately hostile test image (saturated red, bright yellow, near-white
  and near-black quadrants), background text at the default 60% dimming holds ≥5:1. The slider
  warns below 45%, where contrast can degrade.

State lives in `src/lib/use-theme.ts` — one hook shared by every surface that changes the
theme, so they cannot drift out of sync.

**Two places reach it, both public:**

1. **The header icon** opens an appearance popover with all five palettes and all three modes.
   No account needed — a colour scheme is a display preference, not a feature to gate.
2. **Account → Settings → Appearance**, the same controls with longer descriptions and the
   image tools expanded, for signed-in users who look for settings there.

The popover closes on Escape, on an outside click, or via its close button, and returns focus to
the trigger so keyboard users are not dropped at the top of the page.

Choices are stored in `localStorage` (`ath-theme`, `ath-palette`) and apply instantly on the
device. `user_preferences.theme` still exists in the database with a valid CHECK constraint and
is untouched by the preferences form, which no longer submits it — writing a default there
would have overwritten the stored value every time a user saved their sort order.

## Enabling Google sign-in

Everything on the code side is done. Three values have to be supplied by you, because they
are issued by Google and cannot be generated by this project.

**1. Create the OAuth client.** In the [Google Cloud console](https://console.cloud.google.com/apis/credentials):
create a project → *APIs & Services* → *Credentials* → *Create credentials* → *OAuth client ID*
→ type **Web application**. Add this **Authorised redirect URI** exactly — this is Supabase's
callback, not the app's:

```
https://iuvxddawxdjexzmhzozz.supabase.co/auth/v1/callback
```

**2. Paste the credentials into Supabase.** Dashboard → *Authentication* → *Sign In / Providers*
→ *Google*: enable it, paste the Client ID and Client Secret, save. Nothing goes in this
repo, and no secret is exposed to the browser.

**3. That is it.** The signup and login pages re-check the provider every 5 minutes, so the
"Sign up with Google" / "Continue with Google" buttons appear on their own. No redeploy needed.

Consent-screen scopes used are `openid email profile` — the minimum needed to create an
account. Accounts created this way get a `profiles` row and default `user_preferences` from
the existing `handle_new_user()` trigger, exactly like email signups.

## Known limitations (deliberate, not hidden)

- **Google sign-in is built but not yet enabled.** The button, server action, callback handling
  and error states are all implemented and tested. What is missing is credentials: Google
  OAuth client ID + secret, which can only come from your Google Cloud console. Until they are
  set, the button does not render at all — the page asks Supabase whether the provider is
  enabled and hides it if not, so there is never a button that leads to an error page.
  See **Enabling Google sign-in** below.
- **Email delivery is capped at 2/hour** on the Supabase free tier. Signups that require a
  confirmation email will hit `over_email_send_rate_limit`; the UI now says so explicitly
  instead of showing a generic error. Adding custom SMTP lifts this.
- **Admin dashboard is not built yet** (this was scoped as a second pass). The schema, roles
  and RLS policies it needs are already in place.
- **Newly published tools need a deploy before they have a page.** `tools/[slug]` uses
  `dynamicParams = false` so that unknown slugs return a real HTTP 404 rather than a 200 with
  "not found" content. Next resolves that slug list at build time and does **not** re-run
  `generateStaticParams` during ISR, so a tool inserted straight into the database is absent
  until the next build. The admin dashboard (pass two) will trigger a deploy on publish.
  If you would rather publish instantly, set `dynamicParams = true` in
  `src/app/tools/[slug]/page.tsx` — the trade-off is that bad URLs then return 200.
- **Reviews UI is built.** Signed-in users can post, update and delete their own review from a
  tool page; the `sync_tool_rating` trigger keeps `tools.rating` and `rating_count` correct.
  Validation is enforced in the database (1–5 range, field lengths, one review per user per tool)
  as well as in the server action. Reviews are read through the `review_feed` view rather than
  an embedded join, because `profiles` RLS only exposes a user's own row — a join silently
  returned nothing for anyone else's review. The view exposes a display name only; email and
  role never leave the profiles table.
- **Account deletion is self-service.** The settings page collects a typed `DELETE`
  confirmation and calls `public.delete_own_account()`, a `security definer` function that
  takes no arguments and therefore can only ever remove `auth.uid()`. Deleting the profile
  row alone was not enough: `favorites`, `reviews`, `recently_viewed`, `user_preferences` and
  `profiles` all cascade from `auth.users`, not from `profiles`. Verified end to end — the
  user row, profile, two favourites, one review and viewing history were all removed and the
  session was invalidated. This replaced a `mailto:` link to an address that did not exist.
- **A root `loading.tsx` was silently turning every 404 into a 200.** The
  skeleton at `app/loading.tsx` wrapped every route in a Suspense boundary, which
  makes Next stream the response; once streaming starts the status is already
  committed to 200, so `notFound()` lower in the tree could not change it.
  Measured in a production build: `/tools/tome` (archived) and an unknown slug
  both returned **HTTP 200 carrying a "404" body** — a soft 404 on every dead tool
  link. The skeleton is now scoped to `app/(home)/` and `app/tools/(list)/`, and
  both URLs return a real 404. `tests/http.test.ts` locks this down, and the file
  headers explain why the boundary must not move back up.
- **Data is corrected against live sources, not assumed.** A maintenance pass re-checked
  every outbound link and repository. Eight GitHub repositories had moved (`jan` → `janhq`,
  `comfyui` → `Comfy-Org`, `librechat` → `LibreChat-AI`, `openedx` → `openedx-platform`,
  `openhands` → `OpenHands`, `vale` → `vale-cli`, `dub` → `dub.link`), one project had been
  renamed entirely — `perplexica` is now **Vane**, and the entry was corrected while keeping
  the old slug so existing links still resolve — and one repository (`void`) was archived on
  2 June 2026, which the description now states plainly. One tool (`tome`) returned HTTP 404
  from its own domain and was moved to `archived` rather than deleted, so its history is
  kept but it is hidden from every public query. Corrections live in
  `supabase/migrations/0008_data_corrections.sql`.
- **View counts are rate-limited and no longer invented.** The seeded counts were preserved
  in `public.tools_view_backup` and reset to zero, for the same reason as the ratings. Ten
  scripted requests to `/api/view` used to add ten views, which mattered because the
  trending rail sorts by view count; the counter now records one hit per
  (tool, client, hour) in `public.tool_view_hits` and only increments when that row is new.
  Verified: ten rapid calls from one client add one, five distinct clients add five.
- **Ratings are honest by construction.** No rating is stored or displayed unless it was
  produced by a real review — the `sync_tool_rating` trigger derives `tools.rating` and
  `rating_count` from `public.reviews`, and the table currently holds none, so every tool
  reads "No ratings yet" instead of a fabricated average. Forty seeded averages inherited
  from v1 were cleared; the originals are preserved in `public.tools_rating_backup` should
  they ever be wanted as a starting point. The homepage tagline was corrected from
  "Real ratings" to "Checked pricing. Sourced licenses." for the same reason, and a tool
  with no reviews emits no `aggregateRating` in its JSON-LD.
- **Newsletter capture works; sending does not.** Subscribers are stored in
  `newsletter_subscribers` (insert-only for anon). Verified: valid address → `{"ok":true}`,
  duplicate → `{"ok":true,"already":true}`, malformed → 400. No email is sent until an ESP
  is connected (Resend, Buttondown or a Supabase Edge Function are viable). Because sending
  was never wired, an unsubscribe path exists and is tested: each subscriber receives a
  UUID `unsubscribe_token`, and `/api/newsletter/unsubscribe?token=…` marks them
  unsubscribed through `public.unsubscribe_newsletter()`. That definer function exists
  because the table grants anon INSERT only, so a direct UPDATE matched zero rows and
  reported failure as success. First click → `done`, repeat click → `already`, unknown
  token → `invalid`; the page at `/unsubscribed` explains each case.
