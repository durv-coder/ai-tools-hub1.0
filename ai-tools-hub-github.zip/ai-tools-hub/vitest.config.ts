import { defineConfig } from "vitest/config";
import path from "node:path";

export default defineConfig({
  resolve: { alias: { "@": path.resolve(__dirname, "src") } },
  test: {
    environment: "node",
    include: ["tests/**/*.test.ts"],
    // The HTTP suite talks to a running dev/prod server; give it room.
    testTimeout: 20_000,
    hookTimeout: 20_000,
  },
});
