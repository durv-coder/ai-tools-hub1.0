#!/usr/bin/env node
/**
 * Deploy this project to Vercel from the command line.
 *
 *   VERCEL_TOKEN=... node scripts/deploy-vercel.mjs
 *
 * Why a script and not `vercel --prod`: the CLI is not installed here and this
 * uses the same public API it does, so there is no dependency to trust.
 *
 * It NEVER creates a project and never touches existing deployments — it adds a
 * new production deployment to the project you already have. Environment
 * variables are read from Vercel, not from this machine, so no secret is sent.
 *
 * Get a token: https://vercel.com/account/tokens  (scope: the project's team)
 */

import { readFile, readdir } from "node:fs/promises";
import path from "node:path";

const TOKEN = process.env.VERCEL_TOKEN;
const PROJECT_ID = process.env.VERCEL_PROJECT_ID ?? "prj_8AxSk7xc9Bsomky6cPClbVqMcgmJ";
const TEAM_ID = process.env.VERCEL_TEAM_ID ?? "team_ZGpnNbuEq4ItL9NQnngqj75z";

if (!TOKEN) {
  console.error("Missing VERCEL_TOKEN. Create one at https://vercel.com/account/tokens");
  process.exit(1);
}

const ROOT = path.resolve(import.meta.dirname, "..");
const SKIP = new Set(["node_modules", ".next", ".git", ".vercel", "out", "build"]);
const SKIP_FILE = /^(\.env(\.local)?|.*\.tsbuildinfo|next-env\.d\.ts)$/;

/** Vercel wants a flat list of {file, data} with paths relative to the root. */
async function collect(dir, base = "") {
  const out = [];
  for (const entry of await readdir(dir, { withFileTypes: true })) {
    if (SKIP.has(entry.name)) continue;
    if (entry.isFile() && SKIP_FILE.test(entry.name)) continue;
    const rel = base ? `${base}/${entry.name}` : entry.name;
    const abs = path.join(dir, entry.name);
    if (entry.isDirectory()) out.push(...(await collect(abs, rel)));
    else out.push({ file: rel, data: (await readFile(abs)).toString("base64"), encoding: "base64" });
  }
  return out;
}

const files = await collect(ROOT);
console.log(`uploading ${files.length} files (no secrets — .env.local is excluded)`);

const res = await fetch(`https://api.vercel.com/v13/deployments?teamId=${TEAM_ID}`, {
  method: "POST",
  headers: { authorization: `Bearer ${TOKEN}`, "content-type": "application/json" },
  body: JSON.stringify({
    name: "ai-tools-hub",
    project: PROJECT_ID,
    target: "production",
    files,
    projectSettings: { framework: "nextjs", nodeVersion: "22.x" },
  }),
});

const body = await res.json();
if (!res.ok) {
  console.error(`deploy failed (${res.status}):`, body.error?.message ?? body);
  process.exit(1);
}
console.log(`deployment queued: ${body.url ?? body.id}`);
console.log("watch it at https://vercel.com/durveshsalve1920-7471s-projects/ai-tools-hub");
