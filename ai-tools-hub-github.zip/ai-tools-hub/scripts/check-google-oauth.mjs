#!/usr/bin/env node
/**
 * Verifies that Google sign-in is ready, end to end, from this machine.
 *
 * Run after pasting the Google credentials into the Supabase dashboard:
 *
 *   npm run check:google
 *
 * Exits 1 if anything is still missing, so it can be used in CI.
 */

import { readFileSync } from "node:fs";

function loadEnv() {
  try {
    const raw = readFileSync(new URL("../.env.local", import.meta.url), "utf8");
    for (const line of raw.split("\n")) {
      const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
      if (!m) continue;
      const value = m[2].replace(/^["']|["']$/g, "");
      if (!process.env[m[1]]) process.env[m[1]] = value;
    }
  } catch {
    console.error("Could not read .env.local — run this from the project root.");
    process.exit(1);
  }
}

loadEnv();

const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

if (!url || !key) {
  console.error("✗ NEXT_PUBLIC_SUPABASE_URL or NEXT_PUBLIC_SUPABASE_ANON_KEY is missing.");
  process.exit(1);
}

const line = (ok, text) => console.log(`  ${ok ? "✓" : "✗"} ${text}`);

console.log("\nGoogle sign-in readiness check\n");

// 1. Is the provider enabled and reachable?
let enabled = false;
try {
  const res = await fetch(`${url}/auth/v1/settings`, { headers: { apikey: key } });
  const settings = await res.json();
  enabled = settings?.external?.google === true;
  line(enabled, `Supabase reports Google provider: ${enabled ? "enabled" : "DISABLED"}`);
  line(settings?.external?.email === true, `Email provider: ${settings?.external?.email ? "enabled" : "disabled"}`);
} catch (error) {
  console.error(`  ✗ Could not reach ${url}/auth/v1/settings — ${error.message}`);
  process.exit(1);
}

// 2. Does the authorize endpoint accept the provider with our exact redirect?
if (enabled) {
  const redirectTo = "http://localhost:3000/auth/callback?next=%2Faccount";
  const res = await fetch(
    `${url}/auth/v1/authorize?provider=google&redirect_to=${encodeURIComponent(redirectTo)}`,
    { redirect: "manual", headers: { apikey: key } },
  );

  const location = res.headers.get("location") ?? "";
  const wentToGoogle = location.includes("accounts.google.com");
  line(wentToGoogle, wentToGoogle ? "Authorize endpoint redirects to Google" : `Authorize did not redirect to Google (status ${res.status})`);

  // 3. PKCE must be present, otherwise the callback cannot exchange the code.
  line(location.includes("code_challenge"), "PKCE code_challenge present in the redirect");

  // 4. Our callback must survive the round trip inside the redirect_to value.
  const roundTrip = decodeURIComponent(location).includes("/auth/callback?next=/account");
  line(roundTrip, "Callback path and `next` survive inside redirect_to");

  // 5. Sanity: the client ID Google sees should be a real one.
  const clientId = new URL(location).searchParams.get("client_id") ?? "";
  line(/\.apps\.googleusercontent\.com$/.test(clientId), `Client ID looks valid (…${clientId.slice(-30) || "missing"})`);
}

console.log("");

if (!enabled) {
  console.log("Next step:");
  console.log("  Google Cloud console → Credentials → OAuth client ID → Web application");
  console.log(`  Authorised redirect URI (exactly):  ${url}/auth/v1/callback`);
  console.log("  Then Supabase → Authentication → Providers → Google → paste ID + secret → enable.");
  console.log("  Re-run: npm run check:google\n");
  process.exit(1);
}

console.log("Google sign-in is live. The buttons render on /signup and /login.\n");
