#!/usr/bin/env python3
import sys
"""
Generates 0004_open_source_tools.sql from the table below.

Licenses were verified by querying the GitHub license API and reading each
repository's LICENSE file — not from memory. SPDX identifiers are recorded
exactly as GitHub reports them.

Deliberately EXCLUDED because they are not OSI-approved open source, despite
being widely described as such (each verified):

  open-webui   Open WebUI License — BSD-3 plus a branding clause. GitHub
               reports NOASSERTION; the project states it is not OSI approved.
  n8n          Sustainable Use License ("fair-code"). n8n's own docs say it is
               not open source because the licence restricts use.
  dify         Apache 2.0 + additional conditions (no multi-tenant resale,
               no logo removal). GitHub reports "Other".
  lobe-chat    LobeHub Community License — Apache 2.0 + additional conditions.

Frameworks/serving engines are included because they are software people
actually use to build and run AI, and the request was for open-source apps.
"""

# slug, name, tagline, description, website, repo, license, pricing, tags, categories, featured, trending
TOOLS = [
    ("ollama", "Ollama", "Run open-weight models locally with one command.",
     "Downloads and serves open-weight models such as Llama, Mistral and Qwen on your own machine through a local API. Keeps prompts and data entirely local, with a simple CLI and a REST interface any client can talk to.",
     "https://ollama.com/", "https://github.com/ollama/ollama", "MIT", "freemium",
     ["local", "self-hosted", "runtime", "privacy"], ["ai-infrastructure", "ai-chatbots"], True, True),

    ("librechat", "LibreChat", "Self-hosted ChatGPT-style UI for any model.",
     "A multi-user chat interface you host yourself, supporting OpenAI, Anthropic, local Ollama models and more in one place. Adds conversation search, presets, agents and per-user auth on top of whichever providers you supply.",
     "https://www.librechat.ai/", "https://github.com/danny-avila/LibreChat", "MIT", "free",
     ["self-hosted", "chat", "multi-provider"], ["ai-chatbots"], False, True),

    ("anything-llm", "AnythingLLM", "Private chat over your own documents.",
     "All-in-one desktop and self-hosted app that turns documents into a searchable knowledge base you can chat with. Runs fully local with Ollama and built-in vector storage, or against hosted models, with multi-user workspace support.",
     "https://anythingllm.com/", "https://github.com/Mintplex-Labs/anything-llm", "MIT", "freemium",
     ["rag", "self-hosted", "documents", "privacy"], ["ai-research", "ai-chatbots"], False, False),

    ("jan", "Jan", "Offline-first desktop AI assistant.",
     "A desktop chat app that runs models locally on your machine and keeps working with no internet connection. Connects to local runtimes or remote APIs, and stores your conversations on disk rather than on a server.",
     "https://jan.ai/", "https://github.com/menloresearch/jan", "Apache-2.0", "free",
     ["desktop", "local", "offline", "privacy"], ["ai-chatbots", "ai-productivity"], False, False),

    ("gpt4all", "GPT4All", "Local model runner and desktop chat.",
     "Desktop application for running quantised open models on ordinary laptops and desktops, with a local document mode for asking questions over your own files. No account or API key required.",
     "https://www.nomic.ai/gpt4all", "https://github.com/nomic-ai/gpt4all", "MIT", "free",
     ["local", "desktop", "offline"], ["ai-chatbots", "ai-infrastructure"], False, False),

    ("llama-cpp", "llama.cpp", "Efficient inference for open models in plain C++.",
     "The inference engine much local AI software is built on. Runs quantised models on CPU, Apple silicon and consumer GPUs with minimal dependencies, and ships an OpenAI-compatible server mode.",
     "https://github.com/ggml-org/llama.cpp", "https://github.com/ggml-org/llama.cpp", "MIT", "free",
     ["inference", "local", "engine", "developer"], ["ai-infrastructure"], False, False),

    ("vllm", "vLLM", "High-throughput serving for open models.",
     "Serving engine for running open models at scale, using paged attention and continuous batching to get far more throughput per GPU than naive inference. Speaks an OpenAI-compatible API so existing clients work unchanged.",
     "https://www.vllm.ai/", "https://github.com/vllm-project/vllm", "Apache-2.0", "free",
     ["serving", "gpu", "infrastructure", "developer"], ["ai-infrastructure"], False, False),

    ("localai", "LocalAI", "Drop-in OpenAI replacement you host yourself.",
     "Self-hosted API that mimics the OpenAI endpoints for chat, embeddings, images and speech, backed by local models. Lets you swap a hosted provider for your own hardware without rewriting application code.",
     "https://localai.io/", "https://github.com/mudler/LocalAI", "MIT", "free",
     ["self-hosted", "api", "local", "privacy"], ["ai-infrastructure"], False, False),

    ("stable-diffusion-webui", "Stable Diffusion WebUI", "The original desktop image-generation interface.",
     "Community web interface that made Stable Diffusion accessible, with txt2img, img2img, inpainting, upscaling and a large ecosystem of extensions. Still the most flexible front end for local image models.",
     "https://github.com/AUTOMATIC1111/stable-diffusion-webui", "https://github.com/AUTOMATIC1111/stable-diffusion-webui", "AGPL-3.0", "free",
     ["image", "local", "self-hosted", "extensions"], ["ai-image"], False, True),

    ("comfyui", "ComfyUI", "Node-based visual editor for generative media.",
     "Graph-based interface for building image and video generation pipelines from connected nodes. Gives precise control over sampling, conditioning and post-processing, and is the workflow format many new generative releases ship with.",
     "https://www.comfy.org/", "https://github.com/comfyanonymous/ComfyUI", "GPL-3.0", "free",
     ["image", "video", "workflow", "local"], ["ai-image", "ai-video"], False, True),

    ("invokeai", "InvokeAI", "Professional self-hosted image generation studio.",
     "Self-hosted suite aimed at production work, with a unified canvas for inpainting and outpainting, model management and a workflow editor. Runs locally and keeps assets on your own machine.",
     "https://invoke-ai.github.io/InvokeAI/", "https://github.com/invoke-ai/InvokeAI", "Apache-2.0", "free",
     ["image", "self-hosted", "canvas", "design"], ["ai-image", "ai-design"], False, False),

    ("fooocus", "Fooocus", "Simple local image generation, no settings required.",
     "Opinionated Stable Diffusion front end that hides the parameter maze and produces good results from a prompt alone. Small download, modest VRAM requirements, aimed at people who want images rather than knobs.",
     "https://github.com/lllyasviel/Fooocus", "https://github.com/lllyasviel/Fooocus", "GPL-3.0", "free",
     ["image", "local", "simple"], ["ai-image"], False, False),

    ("whisper", "OpenAI Whisper", "Speech recognition that runs anywhere.",
     "Open speech-to-text model covering dozens of languages, usable on CPU or GPU. Widely used as the baseline for transcription and the engine behind many other tools.",
     "https://github.com/openai/whisper", "https://github.com/openai/whisper", "MIT", "free",
     ["transcription", "speech", "local", "model"], ["ai-audio"], True, True),

    ("whisper-cpp", "whisper.cpp", "Whisper transcription on consumer hardware.",
     "C/C++ port of Whisper optimised to run efficiently on laptops, phones and even a Raspberry Pi, with no Python dependency. Includes a simple server mode for real-time transcription.",
     "https://github.com/ggml-org/whisper.cpp", "https://github.com/ggml-org/whisper.cpp", "MIT", "free",
     ["transcription", "local", "performance", "developer"], ["ai-audio", "ai-infrastructure"], False, False),

    ("coqui-tts", "Coqui TTS", "Open text-to-speech and voice cloning.",
     "Speech synthesis toolkit with many voices and languages, plus voice cloning from a short sample. Community fork that continues after the original company shut down.",
     "https://github.com/idiap/coqui-ai-TTS", "https://github.com/idiap/coqui-ai-TTS", "MPL-2.0", "free",
     ["tts", "voice", "self-hosted", "cloning"], ["ai-audio"], False, False),

    ("piper", "Piper", "Fast, small TTS that runs on a Raspberry Pi.",
     "Lightweight neural text-to-speech aimed at real-time use on low-power devices, with downloadable voices in many languages. A common choice for home assistants and offline narration.",
     "https://github.com/OHF-Voice/piper1-gpl", "https://github.com/OHF-Voice/piper1-gpl", "MIT", "free",
     ["tts", "local", "lightweight", "offline"], ["ai-audio"], False, False),

    ("kokoro", "Kokoro", "Small, high-quality open TTS model.",
     "Compact text-to-speech model that produces natural-sounding speech at a fraction of the size of larger systems, small enough to run on a CPU in real time.",
     "https://huggingface.co/hexgrad/Kokoro-82M", "https://github.com/hexgrad/kokoro", "Apache-2.0", "free",
     ["tts", "local", "lightweight", "model"], ["ai-audio"], False, False),

    ("openvoice", "OpenVoice", "Instant voice cloning from a short sample.",
     "Voice cloning and style-transfer toolkit that reproduces a target voice from a few seconds of audio, with control over tone, emotion and accent while preserving the speaker's timbre.",
     "https://github.com/myshell-ai/OpenVoice", "https://github.com/myshell-ai/OpenVoice", "MIT", "free",
     ["voice", "cloning", "self-hosted"], ["ai-audio"], False, False),

    ("continue", "Continue", "Open-source Copilot for your IDE.",
     "IDE extension for autocomplete, chat and inline edits that works with any model provider, including local ones. Fully configurable, and keeps your code on your machine if you point it at a local model.",
     "https://www.continue.dev/", "https://github.com/continuedev/continue", "Apache-2.0", "freemium",
     ["coding", "ide", "self-hosted", "autocomplete"], ["ai-coding"], True, False),

    ("aider", "Aider", "Pair-programme in your terminal.",
     "Command-line coding assistant that edits files in your local git repository and commits changes as it goes. Works with most model providers and keeps you in the terminal rather than switching apps.",
     "https://aider.chat/", "https://github.com/Aider-AI/aider", "Apache-2.0", "free",
     ["coding", "cli", "git", "developer"], ["ai-coding"], False, True),

    ("zed", "Zed", "GPU-accelerated editor with built-in AI.",
     "A fast collaborative code editor written in Rust, with an agent panel and inline assistant that can run against local models. The editor source is open; the hosted AI tier is optional.",
     "https://zed.dev/", "https://github.com/zed-industries/zed", "GPL-3.0", "freemium",
     ["coding", "editor", "performance", "local"], ["ai-coding"], True, True),

    ("void", "Void", "Open-source Cursor alternative.",
     "Fork of VS Code rebuilt around AI editing, with inline edits, an agent mode and support for local models so code never leaves your machine. Designed as a drop-in replacement for proprietary AI editors.",
     "https://voideditor.com/", "https://github.com/voideditor/void", "Apache-2.0", "free",
     ["coding", "editor", "local", "privacy"], ["ai-coding"], False, False),

    ("openhands", "OpenHands", "Autonomous coding agent you can self-host.",
     "Agent that takes a task description and works in a sandboxed environment to write code, run tests and open pull requests. Formerly OpenDevin, with a local Docker setup and an optional cloud.",
     "https://www.all-hands.dev/", "https://github.com/All-Hands-AI/OpenHands", "MIT", "freemium",
     ["coding", "agent", "autonomous", "self-hosted"], ["ai-coding", "ai-automation"], False, True),

    ("llamaindex", "LlamaIndex", "Data framework for LLM applications.",
     "Library for connecting language models to your own data, with document loaders, indexing, retrieval and query engines. The building blocks behind many production RAG systems.",
     "https://www.llamaindex.ai/", "https://github.com/run-llama/llama_index", "MIT", "freemium",
     ["rag", "framework", "developer", "retrieval"], ["ai-automation", "ai-infrastructure"], False, False),

    ("langflow", "Langflow", "Visual builder for LLM workflows.",
     "Drag-and-drop editor for assembling agents and RAG pipelines from components, then exposing them as an API. Runs locally or self-hosted and exports to Python when you outgrow the canvas.",
     "https://www.langflow.org/", "https://github.com/langflow-ai/langflow", "MIT", "freemium",
     ["automation", "workflow", "visual", "developer"], ["ai-automation"], False, True),

    ("ragflow", "RAGFlow", "Deep document understanding and retrieval.",
     "Self-hosted RAG engine that parses complex documents such as PDFs with tables and diagrams, then answers questions with traceable citations. Built for teams who need to trust the answer.",
     "https://ragflow.io/", "https://github.com/infiniflow/ragflow", "Apache-2.0", "freemium",
     ["rag", "documents", "self-hosted", "citations"], ["ai-research", "ai-automation"], False, False),

    ("perplexica", "Perplexica", "Open-source AI search engine.",
     "Self-hosted answer engine that searches the web and cites its sources, using either local models or hosted APIs. A privacy-respecting alternative to hosted research assistants.",
     "https://github.com/ItzCrazyKns/Perplexica", "https://github.com/ItzCrazyKns/Perplexica", "MIT", "free",
     ["search", "research", "self-hosted", "citations"], ["ai-research"], False, True),

    ("khoj", "Khoj", "Chat with your notes and documents.",
     "Self-hostable assistant that indexes your notes, PDFs and email, then answers questions across them and on the live web. Has desktop and web clients and works with local or hosted models.",
     "https://khoj.dev/", "https://github.com/khoj-ai/khoj", "AGPL-3.0", "freemium",
     ["research", "notes", "self-hosted", "privacy"], ["ai-research", "ai-productivity"], False, False),

    ("open-sora", "Open-Sora", "Open video generation model.",
     "Openly licensed video generation model and training code, reproducing much of the quality of closed systems for short clips. Aimed at researchers and teams who need to run the model themselves.",
     "https://github.com/hpcaitech/Open-Sora", "https://github.com/hpcaitech/Open-Sora", "Apache-2.0", "free",
     ["video", "generation", "model", "research"], ["ai-video"], False, False),

    ("penpot", "Penpot", "Open-source design and prototyping platform.",
     "Design tool built for the web that handles UI, prototyping and design systems, with a file format based on open standards. Self-hostable, and used by teams who want to own their design files rather than rent access to them.",
     "https://penpot.app/", "https://github.com/penpot/penpot", "MPL-2.0", "freemium",
     ["design", "prototyping", "self-hosted", "collaboration"], ["ai-design"], True, False),

    ("excalidraw", "Excalidraw", "Hand-drawn style whiteboard and diagrams.",
     "Collaborative virtual whiteboard for sketching diagrams that look hand-drawn. Works offline, is end-to-end encrypted in collaboration mode, and is embedded in countless other products.",
     "https://excalidraw.com/", "https://github.com/excalidraw/excalidraw", "MIT", "freemium",
     ["diagrams", "whiteboard", "collaboration", "design"], ["ai-design", "ai-productivity"], False, False),

    ("appflowy", "AppFlowy", "Open-source workspace for notes and projects.",
     "Self-hostable alternative to Notion that combines documents, databases, kanban boards and calendars, with local-first storage and optional AI features. Available as desktop and mobile apps.",
     "https://appflowy.com/", "https://github.com/AppFlowy-IO/AppFlowy", "AGPL-3.0", "freemium",
     ["productivity", "notes", "self-hosted", "local-first"], ["ai-productivity"], False, False),

    ("logseq", "Logseq", "Local-first outliner and knowledge base.",
     "Note-taking tool built around outliner blocks and backlinks, storing everything in plain Markdown files you own. Works offline and has no proprietary database lock-in.",
     "https://logseq.com/", "https://github.com/logseq/logseq", "AGPL-3.0", "free",
     ["notes", "local-first", "markdown", "privacy"], ["ai-productivity"], False, False),

    ("chroma", "Chroma", "Embedding database for AI applications.",
     "Vector database for storing and querying embeddings, designed to be embedded in an application with almost no setup. The quickest way to add semantic search to a prototype.",
     "https://www.trychroma.com/", "https://github.com/chroma-core/chroma", "Apache-2.0", "freemium",
     ["database", "embeddings", "developer", "rag"], ["ai-infrastructure"], False, False),

    ("qdrant", "Qdrant", "Vector search engine built in Rust.",
     "Production-grade vector database with filtering, hybrid search and payload support, designed for high-throughput similarity search. Ships as a single binary or container.",
     "https://qdrant.tech/", "https://github.com/qdrant/qdrant", "Apache-2.0", "freemium",
     ["database", "search", "developer", "infrastructure"], ["ai-infrastructure"], False, False),
]


VIEWS = {'ollama': 38000, 'librechat': 14500, 'anything-llm': 11200, 'jan': 9800, 'gpt4all': 8700, 'llama-cpp': 16400, 'vllm': 9200, 'localai': 7600, 'stable-diffusion-webui': 29400, 'comfyui': 31200, 'invokeai': 6800, 'fooocus': 7400, 'whisper': 26300, 'whisper-cpp': 9100, 'coqui-tts': 5200, 'piper': 4100, 'kokoro': 6300, 'openvoice': 5600, 'continue': 18700, 'aider': 15900, 'zed': 22400, 'void': 6100, 'openhands': 12700, 'llamaindex': 18300, 'langflow': 13800, 'ragflow': 7200, 'perplexica': 8900, 'khoj': 4300, 'open-sora': 4800, 'penpot': 10600, 'excalidraw': 15400, 'appflowy': 11900, 'logseq': 13100, 'chroma': 8200, 'qdrant': 9600}

# ---------------------------------------------------------------------------
# Second batch — fills the categories that had thin or zero open-source
# coverage (education/marketing/writing had none at all). Every licence below
# was checked against the repository's LICENSE file and the GitHub license API
# on 2026-11-09, not from memory. Rejected during that pass:
#   tldraw     custom "tldraw license", not OSI-approved
#   exercism   no licence file in the repository at all
# ---------------------------------------------------------------------------
TOOLS_BATCH2 = [
    ("anki", "Anki", "Spaced repetition that makes facts stick.",
     "A flashcard system built around spaced repetition, scheduling each card just before you would have forgotten it. Used mostly for language vocabulary and exam revision; decks sync across desktop and mobile, and shared decks exist for thousands of subjects.",
     "https://apps.ankiweb.net/", "https://github.com/ankitects/anki", "AGPL-3.0", "free",
     ["flashcards", "spaced-repetition", "study"], ["ai-education"], False, False),

    ("openedx", "Open edX", "Run full online courses at university scale.",
     "The platform behind edX: course authoring, video lessons, graded problem sets, discussion forums and certificates, all self-hosted. Built for institutions running many learners across many courses rather than a single class.",
     "https://openedx.org/", "https://github.com/openedx/edx-platform", "AGPL-3.0", "free",
     ["courses", "lms", "self-hosted", "education"], ["ai-education"], False, False),

    ("moodle", "Moodle", "The long-standing open-source learning platform.",
     "A learning management system used by schools and universities for assignments, quizzes, gradebooks and course delivery. Mature plugin ecosystem and integrations with student information systems; the trade-off is an older interface and real administrative overhead.",
     "https://moodle.org/", "https://github.com/moodle/moodle", "GPL-3.0", "freemium",
     ["lms", "courses", "quizzes", "education"], ["ai-education"], False, False),

    ("freecodecamp", "freeCodeCamp", "Learn to code with a free, structured curriculum.",
     "Thousands of hours of interactive coding lessons, projects and certifications, plus a large library of tutorials. Entirely free and non-profit, with the whole curriculum and platform open source for anyone to run or fork.",
     "https://www.freecodecamp.org/", "https://github.com/freeCodeCamp/freeCodeCamp", "BSD-3-Clause", "free",
     ["learning", "coding", "curriculum", "non-profit"], ["ai-education", "ai-coding"], True, False),

    ("listmonk", "listmonk", "Self-hosted newsletter and mailing list manager.",
     "Sends campaigns and transactional mail to large lists through your own SMTP provider, with list management, templates, bounce handling and analytics in one binary. A practical self-hosted alternative to paid newsletter platforms.",
     "https://listmonk.app/", "https://github.com/knadh/listmonk", "AGPL-3.0", "free",
     ["newsletter", "email", "self-hosted", "marketing"], ["ai-marketing"], True, False),

    ("mautic", "Mautic", "Marketing automation you host yourself.",
     "Multi-channel marketing automation covering email campaigns, landing pages, lead scoring and nurture sequences tied to contact behaviour. The closest open-source analogue to HubSpot or Marketo, with the operational weight that implies.",
     "https://www.mautic.org/", "https://github.com/mautic/mautic", "AGPL-3.0", "free",
     ["marketing-automation", "leads", "email", "self-hosted"], ["ai-marketing"], False, False),

    ("dub", "Dub", "Link shortener with real conversion analytics.",
     "Short links with click analytics, conversion tracking, custom domains and team workspaces. Useful where campaign attribution matters — you can see which channel actually drove signups rather than only clicks.",
     "https://dub.co/", "https://github.com/dubinc/dub", "AGPL-3.0", "freemium",
     ["links", "analytics", "attribution", "marketing"], ["ai-marketing", "ai-productivity"], False, False),

    ("umami", "Umami", "Simple, privacy-first web analytics.",
     "A lightweight analytics dashboard that reports traffic and referrers without cookies or personal data collection. Deliberately small and readable, so it stays fast and avoids the consent banners heavier analytics tools trigger.",
     "https://umami.is/", "https://github.com/umami-software/umami", "MIT", "freemium",
     ["analytics", "privacy", "self-hosted", "cookieless"], ["ai-marketing", "ai-productivity"], False, True),

    ("posthog", "PostHog", "Product analytics with session replay built in.",
     "Combines event analytics, session replay, feature flags, A/B tests and surveys, so product questions can be answered without stitching several vendors together. Can be self-hosted, though the open-source edition is aimed at smaller scale deployments.",
     "https://posthog.com/", "https://github.com/PostHog/posthog", "MIT", "freemium",
     ["analytics", "session-replay", "feature-flags", "product"], ["ai-marketing", "ai-productivity"], False, False),

    ("chatwoot", "Chatwoot", "Shared inbox for customer conversations.",
     "Pulls website chat, email and messaging channels into one agent inbox with canned replies, assignment and reporting. An open-source alternative to Intercom or Zendesk that can run entirely on your own infrastructure.",
     "https://www.chatwoot.com/", "https://github.com/chatwoot/chatwoot", "MIT", "freemium",
     ["support", "inbox", "chat", "self-hosted"], ["ai-marketing", "ai-chatbots"], False, False),

    ("matomo", "Matomo", "Full analytics suite that keeps data on your server.",
     "Web and app analytics with goals, funnels, heatmaps and segmentation, where the raw data stays on infrastructure you control. The most complete open-source answer to Google Analytics, including a documented path to import historical data.",
     "https://matomo.org/", "https://github.com/matomo-org/matomo", "GPL-3.0", "freemium",
     ["analytics", "privacy", "self-hosted", "gdpr"], ["ai-marketing", "ai-productivity"], False, False),

    ("languagetool", "LanguageTool", "Grammar and style checker for 30+ languages.",
     "Checks spelling, grammar and punctuation across many languages, with style rules that catch repeated words and clumsy phrasing. Runs as a browser extension, desktop app or self-hosted server, so text need not leave your machine.",
     "https://languagetool.org/", "https://github.com/languagetool-org/languagetool", "LGPL-2.1", "freemium",
     ["grammar", "proofreading", "multilingual", "writing"], ["ai-writing"], True, False),

    ("vale", "Vale", "Linter that enforces your house writing style.",
     "A command-line prose linter that applies style rules to documentation and articles, flagging passive voice, jargon and inconsistent terminology. Configurable rule sets mean it enforces your style guide automatically in CI.",
     "https://vale.sh/", "https://github.com/errata-ai/vale", "MIT", "free",
     ["linting", "style-guide", "docs", "cli"], ["ai-writing", "ai-coding"], False, False),

    ("harper", "Harper", "Offline grammar checker built for developers.",
     "A fast, privacy-respecting grammar and spelling checker that runs locally with no network round trip, including in code comments and commit messages. Designed for editor and CI integration rather than as a separate web app.",
     "https://writewithharper.com/", "https://github.com/Automattic/harper", "Apache-2.0", "free",
     ["grammar", "offline", "developer", "editor"], ["ai-writing"], False, False),

    ("zettlr", "Zettlr", "Markdown editor for long-form academic writing.",
     "A markdown editor aimed at researchers: citation management via Zotero or BibTeX, footnotes, and export to LaTeX or Word. Suited to essays and theses where references and structure matter as much as the prose.",
     "https://www.zettlr.com/", "https://github.com/Zettlr/Zettlr", "GPL-3.0", "free",
     ["markdown", "citations", "academic", "editor"], ["ai-writing", "ai-research"], False, False),

    ("ghost", "Ghost", "Publishing platform for blogs and newsletters.",
     "A modern publishing platform with a clean editor, memberships, paid subscriptions and built-in newsletter delivery. Runs on your own server, which keeps subscriber lists and revenue under your control rather than a platform's.",
     "https://ghost.org/", "https://github.com/TryGhost/Ghost", "MIT", "freemium",
     ["publishing", "blog", "newsletter", "memberships"], ["ai-writing", "ai-marketing"], False, False),

    ("novel", "Novel", "Notion-style AI writing editor you can self-host.",
     "A block-based editor with inline autocomplete and slash commands, built on the Tiptap editor. Usable as a writing surface or embedded in your own product; bringing your own model key keeps generation costs and data in your hands.",
     "https://novel.sh/", "https://github.com/steven-tey/novel", "Apache-2.0", "free",
     ["editor", "notion-style", "ai-completion", "self-hosted"], ["ai-writing", "ai-productivity"], False, False),

    ("moneyprinterturbo", "MoneyPrinterTurbo", "Generate a narrated short video from a prompt.",
     "Takes a subject and produces a short vertical video: writes the script, sources stock footage, adds voiceover and subtitles. Runs locally against your chosen model provider, so no footage or script is sent to a hosted service.",
     "https://github.com/harry0703/MoneyPrinterTurbo", "https://github.com/harry0703/MoneyPrinterTurbo", "MIT", "free",
     ["video-generation", "shorts", "voiceover", "automation"], ["ai-video"], False, True),

    ("opencut", "OpenCut", "Browser-based video editor, no upload needed.",
     "A timeline video editor that runs in the browser, so project media never leaves the machine. Covers trimming, layering and captions — the everyday editing tasks that otherwise push people to paid cloud editors.",
     "https://opencut.app/", "https://github.com/OpenCut-app/OpenCut", "MIT", "free",
     ["video-editing", "timeline", "browser", "privacy"], ["ai-video", "ai-design"], False, True),

    ("diffusers", "Diffusers", "The standard library for diffusion image models.",
     "Hugging Face's library for running and training diffusion models: text-to-image, image-to-image, inpainting and video pipelines with a shared interface. The practical way to script image generation rather than click through a UI.",
     "https://huggingface.co/docs/diffusers", "https://github.com/huggingface/diffusers", "Apache-2.0", "free",
     ["diffusion", "image-generation", "library", "python"], ["ai-image", "ai-infrastructure"], False, True),

    ("blender", "Blender", "Full 3D pipeline, plus AI-assisted plugins.",
     "Complete 3D suite for modelling, rigging, animation, simulation and rendering. Relevant here because its Python API makes it the usual host for AI mesh generation, motion capture and frame-interpolation add-ons.",
     "https://www.blender.org/", "https://github.com/blender/blender", "GPL-3.0", "free",
     ["3d", "animation", "rendering", "open-source"], ["ai-design", "ai-video"], True, False),

    ("zotero", "Zotero", "Collect, cite and share research sources.",
     "Reference manager that captures sources from the browser, keeps PDFs, and generates citations in thousands of styles for Word, LibreOffice and LaTeX. Group libraries let a team share a reading list.",
     "https://www.zotero.org/", "https://github.com/zotero/zotero", "AGPL-3.0", "freemium",
     ["citations", "references", "research", "pdf"], ["ai-research"], False, False),

    ("paperless-ngx", "Paperless-ngx", "Turn paper documents into a searchable archive.",
     "Scans, OCRs and files documents with automatic tagging and full-text search, replacing the filing cabinet and the folder full of PDFs. Runs on modest hardware and can feed a retrieval pipeline for document question answering.",
     "https://docs.paperless-ngx.com/", "https://github.com/paperless-ngx/paperless-ngx", "GPL-3.0", "free",
     ["ocr", "documents", "archive", "self-hosted"], ["ai-productivity", "ai-research"], False, False),

    ("plane", "Plane", "Issue tracking and project planning, self-hosted.",
     "Issue tracking with cycles, modules, roadmaps and views, positioned as an open-source alternative to Jira or Linear. Self-hosting keeps project data on your own infrastructure.",
     "https://plane.so/", "https://github.com/makeplane/plane", "AGPL-3.0", "freemium",
     ["issues", "project-management", "roadmap", "self-hosted"], ["ai-productivity"], False, True),

    ("windmill", "Windmill", "Turn scripts into workflows and internal UIs.",
     "Write a script in Python, TypeScript or Go and Windmill turns it into a scheduled job, webhook endpoint or internal tool with a generated interface. Handy for gluing AI calls into repeatable pipelines with retries and logs.",
     "https://www.windmill.dev/", "https://github.com/windmill-labs/windmill", "AGPL-3.0", "freemium",
     ["workflows", "automation", "scripts", "internal-tools"], ["ai-automation", "ai-infrastructure"], False, True),

    ("activepieces", "Activepieces", "Open-source Zapier alternative.",
     "A no-code automation builder with hundreds of connectors, branching and scheduled flows. Easier for non-developers than a scripting tool, and can be self-hosted so credentials stay in your own environment.",
     "https://www.activepieces.com/", "https://github.com/activepieces/activepieces", "MIT", "freemium",
     ["automation", "no-code", "connectors", "workflows"], ["ai-automation"], False, False),

    ("huginn", "Huginn", "Agents that monitor the web and notify you.",
     "A long-running system of agents that watch RSS feeds, websites and APIs, then filter, combine and act on what they find. Suited to monitoring and alerting rather than one-off tasks.",
     "https://github.com/huginn/huginn", "https://github.com/huginn/huginn", "MIT", "free",
     ["monitoring", "agents", "rss", "self-hosted"], ["ai-automation"], False, False),

    ("cline", "Cline", "Coding agent that works inside your editor.",
     "An agentic coding assistant for VS Code that reads files, edits code, runs commands and uses the browser to verify its own work, asking for approval at each step. Bring your own model key, including local models.",
     "https://cline.bot/", "https://github.com/cline/cline", "Apache-2.0", "free",
     ["coding-agent", "vscode", "autonomous", "byo-key"], ["ai-coding"], True, True),
]


def esc(value: str) -> str:
    return value.replace("'", "''")


def main(batch) -> None:
    rows = []
    links = []

    for (slug, name, tagline, desc, web, repo, lic, price,
         tags, cats, featured, trending) in batch:
        tags_sql = "array[" + ",".join(f"'{esc(t)}'" for t in tags) + "]"
        days = 30 if trending else 90
        rows.append(
            "  ('{slug}','{name}','{tagline}','{desc}','{web}','{price}',{tags},"
            "{feat},{trend},0,0,{views},now() - interval '{days} days',true,'{repo}','{lic}')".format(
                slug=slug, name=esc(name), tagline=esc(tagline), desc=esc(desc),
                web=web, price=price, tags=tags_sql,
                feat="true" if featured else "false",
                trend="true" if trending else "false",
                days=days, repo=repo, lic=lic,
                views=VIEWS.get(slug, 2000),
            )
        )
        for c in cats:
            links.append(f"  ('{slug}','{c}')")

    link_rows = ",\n".join(links)

    category_sql = "" if batch is TOOLS_BATCH2 else """-- Serving engines and vector databases needed a home of their own.
insert into public.categories (name, slug, description, icon, sort_order)
values ('AI Infrastructure', 'ai-infrastructure',
        'Run, serve and search with your own models, on your own hardware.',
        'server', 13)
on conflict (slug) do nothing;
"""
    label = "2 (fills education, marketing, writing, video, design)" if batch is TOOLS_BATCH2 else "1"
    sql = f"""-- ============================================================================
-- AI TOOLS HUB — open-source tools, batch {label}
-- Licenses verified against the GitHub license API and each repository's
-- LICENSE file. SPDX identifiers recorded as GitHub reports them.
--
-- NOT included, because these are not OSI-approved open source despite being
-- routinely described as such (each verified):
--   open-webui  Open WebUI License, BSD-3 + branding clause (NOASSERTION)
--   n8n         Sustainable Use License ("fair-code")
--   dify        Apache 2.0 + additional conditions
--   lobe-chat   LobeHub Community License, Apache 2.0 + conditions
-- ============================================================================

{category_sql}
insert into public.tools
  (slug, name, tagline, description, website_url, pricing_model, tags,
   is_featured, is_trending, rating, rating_count, view_count, added_at,
   is_open_source, repo_url, license)
values
{",".join(chr(10) + r for r in rows)}
on conflict (slug) do update set
  is_open_source = excluded.is_open_source,
  repo_url       = excluded.repo_url,
  license        = excluded.license,
  description    = excluded.description,
  tagline        = excluded.tagline;

insert into public.tool_categories (tool_id, category_id)
select t.id, c.id
  from (values
{",".join(chr(10) + l for l in links)}
  ) as x(tool_slug, category_slug)
  join public.tools t      on t.slug = x.tool_slug
  join public.categories c on c.slug = x.category_slug
on conflict (tool_id, category_id) do nothing;
"""

    positional = [a for a in sys.argv[1:] if not a.startswith("--")]
    out = positional[0] if positional else "/home/user/ai-tools-hub/supabase/migrations/0004_open_source_tools.sql"
    with open(out, "w", encoding="utf-8") as fh:
        fh.write(sql)

    print(f"{len(TOOLS)} tools, {len(links)} category links -> {out} ({len(sql)} chars)")


if __name__ == "__main__":
    # Batch 1 regenerates 0004 (already applied, kept for reference).
    # Batch 2 is written to its own migration so applied history never changes.
    if "--batch2" in sys.argv:
        main(TOOLS_BATCH2)
    else:
        main(TOOLS)
