#!/usr/bin/env node
/**
 * Proves a deployment is actually the current build, not a stale one.
 *
 *   node scripts/verify-deploy.mjs https://ai-tools-hub-rouge-three.vercel.app
 *
 * Checks the things that were previously wrong on the live site: a missing
 * /compare route, old hero copy, localhost leaking into robots.txt, and soft
 * 404s on archived tools.
 */
const BASE = (process.argv[2] ?? "http://localhost:3000").replace(/\/$/, "");

const checks = [
  { name: "homepage renders", path: "/", expect: 200, contains: "Tools Hub" },
  { name: "compare page exists", path: "/compare", expect: 200 },
  { name: "directory renders", path: "/tools", expect: 200, contains: "Browse AI tools" },
  { name: "categories render", path: "/categories", expect: 200 },
  { name: "login renders", path: "/login", expect: 200 },
  { name: "a tool page renders", path: "/tools/cursor", expect: 200, contains: "Cursor" },
  { name: "archived tool is a real 404", path: "/tools/tome", expect: 404 },
  { name: "unknown slug is a real 404", path: "/tools/nope-not-real", expect: 404 },
  { name: "robots.txt has no localhost", path: "/robots.txt", expect: 200, absent: "localhost" },
  { name: "sitemap is served", path: "/sitemap.xml", expect: 200, contains: "<urlset" },
];

let failed = 0;
for (const c of checks) {
  try {
    const res = await fetch(BASE + c.path, { redirect: "manual" });
    const body = c.contains || c.absent ? await res.text() : "";
    const problems = [];
    if (res.status !== c.expect) problems.push(`status ${res.status}, expected ${c.expect}`);
    if (c.contains && !body.includes(c.contains)) problems.push(`missing "${c.contains}"`);
    if (c.absent && body.includes(c.absent)) problems.push(`contains "${c.absent}"`);
    if (problems.length) {
      failed += 1;
      console.log(`  FAIL  ${c.name} — ${problems.join("; ")}`);
    } else {
      console.log(`  ok    ${c.name}`);
    }
  } catch (err) {
    failed += 1;
    console.log(`  FAIL  ${c.name} — ${err.message}`);
  }
}

console.log(failed === 0 ? "\nAll checks passed." : `\n${failed} check(s) failed.`);
process.exit(failed === 0 ? 0 : 1);
