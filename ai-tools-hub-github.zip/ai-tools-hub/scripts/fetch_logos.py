#!/usr/bin/env python3
"""
Fetches a real logo for every published tool and writes an SQL migration that
sets tools.logo_url.

Source: Google's favicon service (s2/favicons) at 128px. Chosen over Clearbit
because it needs no key, resolves reliably, and returns a transparent PNG.
Logos are downloaded, validated as real images, and stored in the repo under
public/logos/ so the app never depends on a third-party host at runtime — a
favicon service going down should not empty the directory.
"""

import hashlib
import json
import os
import re
import sys
import urllib.request
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUT = ROOT / "public" / "logos"
# Output path is overridable so later batches never rewrite an applied migration.
_pos = [a for a in sys.argv[1:] if not a.startswith("--")]
SQL = Path(_pos[0]) if _pos else ROOT / "supabase" / "migrations" / "0005_tool_logos.sql"
ENV = ROOT / ".env.local"


def load_env():
    values = {}
    for line in ENV.read_text().splitlines():
        m = re.match(r"^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$", line)
        if m:
            values[m.group(1)] = m.group(2).strip().strip('"').strip("'")
    return values


def fetch_tools(env):
    url = f"{env['NEXT_PUBLIC_SUPABASE_URL']}/rest/v1/tools"
    url += "?select=slug,name,website_url&status=eq.published&order=slug"
    req = urllib.request.Request(
        url,
        headers={
            "apikey": env["NEXT_PUBLIC_SUPABASE_ANON_KEY"],
            "Authorization": f"Bearer {env['NEXT_PUBLIC_SUPABASE_ANON_KEY']}",
        },
    )
    with urllib.request.urlopen(req, timeout=30) as response:
        return json.load(response)


# Some tools are hosted on GitHub Pages (or their site has no favicon), so the
# favicon service returns GitHub's octocat for all of them. Eleven identical
# icons is worse than a letter monogram, so those prefer the project's own
# domain where one exists.
DOMAIN_OVERRIDES = {
    "whisper": "openai.com",
    "whisper-cpp": "ggml.ai",
    "llama-cpp": "ggml.ai",
    "openvoice": "myshell.ai",
    "coqui-tts": "coqui.com",
    "open-sora": "hpcaitech.com",
    "perplexica": "perplexica.vercel.app",
    "invokeai": "invoke.ai",
    "elevenlabs": "elevenlabs.io",
    "stable-diffusion-webui": "stability.ai",
    "fooocus": "fooocus.ai",
    # Batch 2 — the project's own site returns no favicon, so point at the
    # canonical GitHub org, which always has one.
    "opencut": "github.com",
    "diffusers": "huggingface.co",
    "moneyprinterturbo": "github.com",
    "huginn": "github.com",
}

# kelvin: a logo shared by two tools is worse than a monogram, so this list is
# kept explicit and small.
NO_LOGO = {"kokoro", "coqui-tts", "elevenlabs", "llama-cpp", "whisper-cpp",
           "perplexica", "opencut", "huginn", "moneyprinterturbo", "github-copilot"}

# Google's fixed "no icon" globe. Anything matching it is treated as missing.
GENERIC_GLOBE = {2_1: True}


def download(website, slug):
    domain = DOMAIN_OVERRIDES.get(slug) or re.sub(r"^https?://", "", website).split("/")[0]
    if not domain:
        return None, None
    src = f"https://www.google.com/s2/favicons?domain={domain}&sz=128"
    req = urllib.request.Request(src, headers={"User-Agent": "Mozilla/5.0"})
    try:
        with urllib.request.urlopen(req, timeout=20) as response:
            data = response.read()
    except Exception as error:  # noqa: BLE001 - report and skip
        print(f"    ! {domain}: {error}", file=sys.stderr)
        return None, domain

    # Reject the tiny generic placeholders the service returns when it has
    # nothing real: they are identical across tools, which is worse than the
    # letter monogram fallback.
    if len(data) < 400:
        return None, domain

    return data, domain


def main():
    env = load_env()
    tools = fetch_tools(env)
    print(f"Fetching logos for {len(tools)} tools\n")

    OUT.mkdir(parents=True, exist_ok=True)
    rows = []
    missing = []

    for tool in tools:
        if tool["slug"] in NO_LOGO:
            missing.append((tool["slug"], "explicit monogram fallback"))
            continue
        data, domain = download(tool["website_url"], tool["slug"])
        if not data:
            missing.append((tool["slug"], domain))
            continue

        digest = hashlib.sha1(data).hexdigest()[:12]
        ext = "png"
        filename = f"{tool['slug']}.{ext}"
        (OUT / filename).write_bytes(data)
        rows.append((tool["slug"], f"/logos/{filename}", len(data)))
        print(f"  ok  {tool['slug']:<28} {len(data):>6}B  {digest}")

    # Any image shared by more than one tool is a generic service placeholder
    # (GitHub's octocat, a host's default). Drop every copy so those tools fall
    # back to their monogram rather than showing a misleading shared icon.
    by_hash = {}
    for slug, url, _ in rows:
        by_hash.setdefault(hashlib.sha1((OUT / f"{slug}.png").read_bytes()).hexdigest(), []).append(slug)

    shared = {s for group in by_hash.values() if len(group) > 1 for s in group}
    if shared:
        print(f"\n  dropping {len(shared)} duplicate icons (generic placeholders):")
        for slug in sorted(shared):
            print(f"    - {slug}")
            (OUT / f"{slug}.png").unlink(missing_ok=True)
            missing.append((slug, "duplicate placeholder"))
        rows = [r for r in rows if r[0] not in shared]

    print(f"\n{len(rows)} logos saved, {len(missing)} missing")
    for slug, domain in missing:
        print(f"  missing: {slug} ({domain})")

    cleared = sorted(NO_LOGO)
    values = ",\n".join(
        f"('{slug}', '{url}')" for slug, url, _ in rows
    )
    SQL.write_text(
        "-- Generated by scripts/fetch_logos.py — do not edit by hand.\n"
        "-- Sets logo_url for every tool with a downloadable icon, served from\n"
        "-- /public/logos so the app does not depend on a third-party host.\n"
        "-- Tools without an icon keep their letter monogram fallback.\n\n"
        "update public.tools as t\n"
        "set logo_url = v.url\n"
        "from (values\n"
        f"{values}\n"
        ") as v(slug, url)\n"
        "where t.slug = v.slug;\n\n"
        "select count(*) as tools_with_logo from public.tools where logo_url is not null;\n"
    )
    print(f"\nWrote {SQL}")


if __name__ == "__main__":
    main()
