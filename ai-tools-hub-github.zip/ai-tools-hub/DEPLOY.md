# Deploying AI Tools Hub

**Status: deployed and verified on 2026-11-09.** The live site is current.
`node scripts/verify-deploy.mjs https://ai-tools-hub-rouge-three.vercel.app` reports
**All checks passed** (10/10), and a sampled crawl of 19 live URLs returned no failures.

Two independent parts remain:

1. **GitHub** — stores the code and lets Vercel deploy on every push. *Not connected yet.*
2. **Vercel** — serving the current build. *Done.*

Because no repo is connected, deploys are manual for now. That matters for one specific reason:
**Vercel refuses to create a deploy hook unless a repository is connected**, so automatic
rebuilds on publish are unavailable until step 1 is done. The admin UI says so plainly instead of
pretending a new tool is live.

---

## Step 1 — Create the GitHub repo and push

The repository is already committed here (branch `main`, 192 files, clean tree). From the
`ai-tools-hub` folder, run:

```bash
# 1. Create an empty repo on GitHub (no README, no .gitignore — this project has both).
#    Via the web: github.com/new  →  name it `ai-tools-hub`  →  Private  →  Create.
#
#    Or with the GitHub CLI:
gh repo create ai-tools-hub --private --source=. --remote=origin --push
```

If you created it on the web instead, wire up the remote and push:

```bash
git remote add origin https://github.com/<your-username>/ai-tools-hub.git
git push -u origin main
```

**Check before you push** that no secret is going up. `.env.local` is gitignored, but it is worth
seeing it yourself:

```bash
git ls-files | grep -i env      # expect: only .env.example
git grep -nE "sb_publishable_|service_role" -- . ':!.env.example'
```

The second command should print nothing. `.env.example` contains placeholders only.

> The publishable Supabase key is *designed* to ship in the browser — every table is protected by
> row-level security. What must never be committed is a `service_role` key, and none exists in
> this project.

---

## Step 2 — Connect Vercel to the repo

1. Vercel → your **ai-tools-hub** project → **Settings → Git**
2. **Connect Git Repository** → pick `ai-tools-hub`
3. Framework preset: **Next.js** (auto-detected). Leave build/install commands default.
4. Node version: **22.x** (the repo pins 22 in `.nvmrc` and `package.json`).

Once connected, every push to `main` deploys automatically. That also removes the need to think
about stale builds — the problem that produced the 3-day-old site.

### Environment variables

Already set on the project (I added these earlier):

| Variable | Value |
|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | `https://iuvxddawxdjexzmhzozz.supabase.co` |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | the publishable key |
| `NEXT_PUBLIC_SITE_URL` | `https://ai-tools-hub-rouge-three.vercel.app` |

Optional, and worth adding:

| Variable | Why |
|---|---|
| `VERCEL_DEPLOY_HOOK_URL` | Lets `/admin` rebuild the site when you publish a tool. Create it under **Settings → Git → Deploy Hooks** (branch `main`). Server-side only — never prefix it with `NEXT_PUBLIC_`. |

---

## Step 3 — Deploy without Git (if you'd rather not connect a repo)

```bash
VERCEL_TOKEN=your_token node scripts/deploy-vercel.mjs
```

This calls the Vercel API directly, so no CLI is needed. It adds a production deployment to the
existing project and never creates a project or touches existing deployments.

---

## Step 4 — Prove it actually deployed

Do not assume a green check means the site is current. Run:

```bash
node scripts/verify-deploy.mjs https://ai-tools-hub-rouge-three.vercel.app
```

Expected:

```
  ok    homepage renders
  ok    compare page exists
  ok    directory renders
  ok    categories render
  ok    login renders
  ok    a tool page renders
  ok    archived tool is a real 404
  ok    unknown slug is a real 404
  ok    robots.txt has no localhost
  ok    sitemap is served

All checks passed.
```

Today it prints **7 check(s) failed** — that is the stale build.

---

## Why publishing a tool needs a rebuild

Tool pages set `dynamicParams = false`. That is deliberate: it is what makes an unknown or
archived slug return a real HTTP 404 instead of a 200 carrying a "404" body. I measured the
alternative — with `dynamicParams = true` a production build returned **HTTP 200 for both unknown
and archived slugs**, i.e. a soft 404 on every dead tool link. Not worth it.

The cost: the slug list is fixed at build time, so a tool published from `/admin` has no page
until the site rebuilds. With `VERCEL_DEPLOY_HOOK_URL` set, saving a published tool triggers that
rebuild. Without it, the admin UI says a redeploy is needed rather than claiming success.
