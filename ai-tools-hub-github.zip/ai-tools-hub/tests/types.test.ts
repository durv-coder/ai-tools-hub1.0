import { describe, expect, it } from "vitest";
import { PRICING_LABEL, SORT_OPTIONS, formatCount, initials } from "@/lib/types";

describe("formatCount", () => {
  it("drops the decimal for values under 1000", () => {
    expect(formatCount(0)).toBe("0");
    expect(formatCount(7)).toBe("7");
    expect(formatCount(999)).toBe("999");
  });

  it("abbreviates thousands and millions", () => {
    expect(formatCount(1000)).toBe("1k");
    expect(formatCount(1200)).toBe("1.2k");
    expect(formatCount(1_000_000)).toBe("1M");
  });

  it("does not print trailing .0", () => {
    expect(formatCount(2000)).toBe("2k");
    expect(formatCount(3_000_000)).toBe("3M");
  });
});

describe("initials", () => {
  it("takes the first letter of up to two words", () => {
    expect(initials("GitHub Copilot")).toBe("GC");
    expect(initials("Zotero")).toBe("Z");
  });

  it("survives awkward input instead of throwing", () => {
    expect(initials("  spaced  out  ")).toBe("SO");
    expect(initials("")).toBe("");
  });
});

describe("pricing and sort contracts", () => {
  it("labels every pricing model the schema allows", () => {
    // PricingModel is a closed union of exactly these three; the DB check
    // constraint rejects anything else, so a missing label would render "undefined".
    expect(Object.keys(PRICING_LABEL).sort()).toEqual(["free", "freemium", "paid"]);
    for (const label of Object.values(PRICING_LABEL)) {
      expect(label).toBeTruthy();
    }
  });

  it("offers the four sorts the directory page parses", () => {
    // tools/page.tsx only accepts these keys; anything else silently falls
    // back to "popular", which is how the old "trending" sort link broke.
    expect(SORT_OPTIONS.map((s) => s.key)).toEqual(["popular", "rating", "newest", "alpha"]);
  });

  it("has no duplicate sort keys", () => {
    const keys = SORT_OPTIONS.map((s) => s.key);
    expect(new Set(keys).size).toBe(keys.length);
  });
});
