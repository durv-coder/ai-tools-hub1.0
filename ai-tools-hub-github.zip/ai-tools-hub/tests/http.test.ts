import { describe, expect, it } from "vitest";

/**
 * Live HTTP checks against a running server.
 *
 * These are the regressions that actually bit during development, expressed as
 * assertions so they cannot come back silently:
 *
 *  - archived tools must be a hard 404, not a 200 soft-404
 *  - unknown slugs must be a hard 404
 *  - /tools?trending=1 must be a real filter, not a link that falls back to
 *    "popular" and silently shows everything
 *  - security headers must stay on every response
 *  - no page may expose a service-role key or an env secret
 *
 * Run with the dev server up:  npm test
 * Against a deployment:        SITE_BASE=https://example.com npm test
 */
// Note: Vite/Vitest pre-sets process.env.BASE_URL to "/", so a variable of
// that name silently produces "//tools". Use a name nothing else claims.
const BASE = process.env.SITE_BASE ?? "http://localhost:3000";
const SITE = BASE.replace(/\/$/, "");

async function get(path: string) {
  const res = await fetch(`${SITE}${path}`, { redirect: "manual" });
  const body = await res.text();
  return { status: res.status, body, headers: res.headers };
}

describe("public routes", () => {
  const routes = ["/", "/tools", "/categories", "/compare", "/about", "/login", "/signup"];

  it.each(routes)("%s returns 200 with real content", async (route) => {
    const { status, body } = await get(route);
    expect(status).toBe(200);
    // A 200 with an empty body is a failure mode we hit before: assert meat.
    expect(body.length).toBeGreaterThan(2000);
    expect(body).toContain("Tools Hub");
  });
});

describe("tool detail routing", () => {
  it("renders a published tool", async () => {
    const { status, body } = await get("/tools/cursor");
    expect(status).toBe(200);
    expect(body).toContain("Cursor");
  });

  it("404s an unknown slug with a real 404 status", async () => {
    const { status } = await get("/tools/definitely-not-a-real-tool");
    expect(status).toBe(404);
  });

  it("404s an archived tool instead of serving a stale page", async () => {
    // tome.app returns DEPLOYMENT_NOT_FOUND; the row is status='archived'.
    // Assert on the detail page's own markup rather than the word "Tome",
    // which can legitimately appear in a generic error document.
    const { status, body } = await get("/tools/tome");
    expect(status).toBe(404);
    expect(body).not.toContain("detail-title");
    expect(body).not.toContain("Similar tools");
  });
});

describe("directory filters do real work", () => {
  it("trending filter returns a strict subset", async () => {
    const all = await get("/tools");
    const trending = await get("/tools?trending=1");
    expect(trending.status).toBe(200);

    // Next inserts HTML comments between interpolated values in server output
    // ("Showing <!-- -->12<!-- --> of ..."), so strip them before matching.
    const count = (html: string) => {
      const clean = html.replace(/<!-- -->/g, "");
      const m = clean.match(/Showing\s+(\d+)\s+of\s+(\d+)\s+tools/);
      return m ? { shown: Number(m[1]), total: Number(m[2]) } : null;
    };

    const t = count(trending.body);
    const a = count(all.body);
    expect(t).not.toBeNull();
    expect(a).not.toBeNull();
    // If the filter silently fell back to "popular", these totals would match.
    expect(t!.total).toBeLessThan(a!.total);
  });

  it("a nonsense search returns a zero-result state, not everything", async () => {
    const { body } = await get("/tools?q=zzzzqqqqxxxx");
    const m = body.match(/Showing\s+(\d+)\s+of\s+(\d+)\s+tools/);
    if (m) expect(Number(m[1])).toBe(0);
  });
});

describe("security headers", () => {
  const required = [
    "content-security-policy",
    "x-content-type-options",
    "x-frame-options",
    "referrer-policy",
    "strict-transport-security",
    "permissions-policy",
  ];

  it("are present on a page response", async () => {
    const { headers } = await get("/");
    for (const h of required) {
      expect(headers.get(h), `missing header: ${h}`).toBeTruthy();
    }
  });

  it("disallow framing", async () => {
    const { headers } = await get("/");
    expect(headers.get("x-frame-options")?.toUpperCase()).toContain("SAMEORIGIN");
  });

  it("send nosniff", async () => {
    const { headers } = await get("/");
    expect(headers.get("x-content-type-options")).toBe("nosniff");
  });
});

describe("no secrets in rendered HTML", () => {
  it("never ships a service-role key or private env var", async () => {
    const { body } = await get("/");
    expect(body).not.toMatch(/SUPABASE_SERVICE_ROLE/);
    expect(body).not.toMatch(/service_role/);
    expect(body).not.toMatch(/eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9\.[A-Za-z0-9_-]{20,}/);
  });
});

describe("SEO surface", () => {
  it("sitemap is valid and lists tool pages", async () => {
    const { status, body } = await get("/sitemap.xml");
    expect(status).toBe(200);
    expect(body).toContain("<urlset");
    expect(body).toContain("/tools/");
  });

  it("excludes archived tools from the sitemap", async () => {
    const { body } = await get("/sitemap.xml");
    expect(body).not.toContain("/tools/tome");
  });

  it("robots points at the sitemap on an absolute host", async () => {
    const { status, body } = await get("/robots.txt");
    expect(status).toBe(200);
    expect(body).toMatch(/Sitemap:\s+https?:\/\//);
    expect(body).not.toContain("localhost");
  });
});
