import { describe, expect, it } from "vitest";

/**
 * Guards for the request handlers, tested at the level they can actually be
 * tested without a browser: the exact regexes and limits the routes enforce.
 *
 * These are duplicated from the route handlers on purpose. If someone loosens a
 * validation rule in one place and not the other, this suite fails and points
 * at the drift instead of quietly widening the attack surface.
 */

const SLUG_RE = /^[a-z0-9-]{1,60}$/;
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/** Mirrors src/lib/queries.ts getToolsBySlugs: dedupe BEFORE the cap, else
 *  `?tools=a&tools=a&tools=a&tools=a&tools=b` returns 4 columns not 2. */
function normaliseSlugs(raw: string[]): string[] {
  const seen = new Set<string>();
  for (const s of raw) {
    if (!SLUG_RE.test(s)) continue;
    seen.add(s);
  }
  return [...seen].slice(0, 4);
}

describe("compare slug handling", () => {
  it("accepts ordinary slugs", () => {
    expect(normaliseSlugs(["jan", "openhands"])).toEqual(["jan", "openhands"]);
  });

  it("rejects traversal and injection attempts", () => {
    expect(normaliseSlugs(["../etc/passwd", "a b", "UPPER", "a'.or.1=1"])).toEqual([]);
  });

  it("keeps no more than four tools", () => {
    const five = ["a", "b", "c", "d", "e"];
    expect(normaliseSlugs(five)).toHaveLength(4);
  });

  it("dedupes before capping, so repeats cannot crowd out real tools", () => {
    const repeated = ["a", "a", "a", "a", "b"];
    expect(normaliseSlugs(repeated)).toEqual(["a", "b"]);
  });

  it("rejects slugs over the length limit", () => {
    expect(normaliseSlugs(["a".repeat(61)])).toEqual([]);
    expect(normaliseSlugs(["a".repeat(60)])).toHaveLength(1);
  });
});

describe("view counter client key", () => {
  /** Mirrors src/app/api/view/route.ts clientKey(): a hash, never the raw IP. */
  function clientKey(ip: string | null, ua: string | null): string {
    const stamp = `${ip ?? "unknown"}|${ua ?? "unknown"}`;
    let h = 0;
    for (let i = 0; i < stamp.length; i += 1) {
      h = (h * 31 + stamp.charCodeAt(i)) | 0;
    }
    return `k${(h >>> 0).toString(36)}`;
  }

  it("gives the same client the same key", () => {
    expect(clientKey("1.2.3.4", "Firefox")).toBe(clientKey("1.2.3.4", "Firefox"));
  });

  it("separates different clients", () => {
    expect(clientKey("1.2.3.4", "Firefox")).not.toBe(clientKey("1.2.3.5", "Firefox"));
    expect(clientKey("1.2.3.4", "Firefox")).not.toBe(clientKey("1.2.3.4", "Safari"));
  });

  it("never leaks the raw address into the key", () => {
    const key = clientKey("203.0.113.9", "Chrome");
    expect(key).not.toContain("203.0.113.9");
  });
});

describe("view request validation", () => {
  it("requires a well-formed uuid", () => {
    expect(UUID_RE.test("bc0d054b-e7f0-40a6-99c6-c530cd9c1165")).toBe(true);
    expect(UUID_RE.test("1")).toBe(false);
    expect(UUID_RE.test("bc0d054b-e7f0-40a6-99c6-c530cd9c116g")).toBe(false);
  });
});
