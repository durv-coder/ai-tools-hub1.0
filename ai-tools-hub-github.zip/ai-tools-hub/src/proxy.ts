import { NextResponse, type NextRequest } from "next/server";

/**
 * Protects private routes before render, so pages never flash protected
 * content and unauthenticated users never reach an account page.
 * (Next 16 calls this file `proxy`; it replaces `middleware`.)
 */
const PROTECTED = ["/account", "/dashboard", "/admin"];

export default async function proxy(request: NextRequest) {
  const { pathname } = request.nextUrl;

  const response = NextResponse.next({ request });

  // Cheap presence check: without a session cookie there is nothing to refresh.
  const hasSessionCookie = request.cookies
    .getAll()
    .some((c) => c.name.includes("-auth-token"));

  const needsAuth = PROTECTED.some((p) => pathname === p || pathname.startsWith(`${p}/`));

  if (needsAuth && !hasSessionCookie) {
    const url = request.nextUrl.clone();
    url.pathname = "/login";
    url.searchParams.set("next", pathname);
    return NextResponse.redirect(url);
  }

  return response;
}

export const config = {
  matcher: [
    // run on pages only; skip static assets and API routes
    "/((?!_next/static|_next/image|favicon.ico|api/|.*\\.(?:svg|png|jpg|jpeg|gif|webp|ico)$).*)",
  ],
};
