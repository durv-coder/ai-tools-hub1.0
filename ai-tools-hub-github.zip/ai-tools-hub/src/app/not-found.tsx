import Link from "next/link";
import { Search } from "@/components/icons";

export default function NotFound() {
  return (
    <div className="container" style={{ paddingBlock: "clamp(64px,10vw,120px)", textAlign: "center" }}>
      <p className="eyebrow" style={{ justifyContent: "center" }}>404</p>
      <h1 style={{ marginTop: 12, fontSize: "clamp(1.7rem,4vw,2.6rem)" }}>
        That page does not exist
      </h1>
      <p className="muted" style={{ marginTop: 12, maxWidth: "46ch", marginInline: "auto", fontSize: 15 }}>
        The link may be out of date, or the tool may have been removed from the directory.
      </p>
      <div className="row" style={{ justifyContent: "center", marginTop: 26, gap: 10 }}>
        <Link href="/tools" className="btn">
          <Search size={15} /> Browse tools
        </Link>
        <Link href="/" className="btn btn--ghost">
          Go home
        </Link>
      </div>
    </div>
  );
}
