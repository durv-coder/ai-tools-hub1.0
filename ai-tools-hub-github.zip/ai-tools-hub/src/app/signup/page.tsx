import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { GoogleSignIn, SignupForm } from "@/components/auth-forms";
import { isGoogleEnabled } from "@/lib/oauth";
import { getCurrentUser } from "@/lib/supabase/auth-server";

export const metadata: Metadata = {
  title: "Create an account",
  description: "Create a free AI Tools Hub account to save favourites and get recommendations.",
  robots: { index: false, follow: true },
};

export default async function SignupPage() {
  const [user, googleEnabled] = await Promise.all([getCurrentUser(), isGoogleEnabled()]);
  if (user) redirect("/account");

  return (
    <div className="container auth-wrap">
      <div className="auth-card">
        <span className="eyebrow">Free account</span>
        <h1 style={{ marginTop: 8 }}>Create your account</h1>
        <p className="muted" style={{ fontSize: 13.5, marginTop: 6 }}>
          Save tools to your shortlist and get suggestions based on what you browse.
        </p>

        {googleEnabled && <GoogleSignIn next="/account" label="Sign up with Google" />}

        <SignupForm />

        <p className="auth-alt">
          Already have an account? <Link href="/login">Sign in</Link>
        </p>
      </div>
    </div>
  );
}
