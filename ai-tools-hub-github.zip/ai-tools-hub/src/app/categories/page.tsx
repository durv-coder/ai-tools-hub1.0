import type { Metadata } from "next";
import Link from "next/link";
import { CategoryIcon, ArrowRight } from "@/components/icons";
import { getCategories, getCategoryCounts } from "@/lib/queries";

export const revalidate = 600;

export const metadata: Metadata = {
  title: "All AI tool categories",
  description:
    "Browse every AI tool category in the directory: chatbots, coding, image generation, video, audio, writing, research, automation and more.",
  alternates: { canonical: "/categories" },
};

export default async function CategoriesPage() {
  const [categories, counts] = await Promise.all([getCategories(), getCategoryCounts()]);

  return (
    <>
      <div className="page-header">
        <div className="container">
          <nav className="crumbs" aria-label="Breadcrumb" style={{ paddingTop: 0, marginBottom: 14 }}>
            <Link href="/">Home</Link>
            <span className="crumbs__sep" aria-hidden="true">/</span>
            <span aria-current="page">Categories</span>
          </nav>
          <h1>Categories</h1>
          <p className="muted measure" style={{ marginTop: 10, fontSize: 15 }}>
            {categories.length} categories, each with a focused set of tools rather than a
            dumping ground.
          </p>
        </div>
      </div>

      <div className="container" style={{ paddingBlock: "clamp(28px,4vw,48px)" }}>
        <div className="cat-grid">
          {categories.map((category) => (
            <Link
              key={category.id}
              href={`/tools?category=${category.slug}`}
              className="cat-card"
            >
              <span className="cat-card__icon">
                <CategoryIcon name={category.icon} />
              </span>
              <span className="cat-card__name">{category.name}</span>
              <span className="cat-card__count">
                {counts[category.slug] ?? 0} tools
              </span>
              {category.description && (
                <span className="cat-card__desc">{category.description}</span>
              )}
              <span
                className="muted"
                style={{ fontSize: 12, display: "inline-flex", alignItems: "center", gap: 4, marginTop: 2 }}
              >
                Browse <ArrowRight size={11} />
              </span>
            </Link>
          ))}
        </div>
      </div>
    </>
  );
}
