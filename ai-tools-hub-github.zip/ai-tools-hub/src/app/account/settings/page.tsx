import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { createAuthClient, getCurrentProfile, getCurrentUser } from "@/lib/supabase/auth-server";
import { DeleteAccountForm, PasswordForm, PreferencesForm, ProfileForm } from "@/components/settings-forms";
import { SignOutButton } from "@/components/sign-out-button";
import { ThemeChooser } from "@/components/theme-toggle";
import { ChevronRight } from "@/components/icons";

export const metadata: Metadata = {
  title: "Account settings",
  robots: { index: false, follow: false },
};

export const dynamic = "force-dynamic";

export default async function SettingsPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/account/settings");

  const profile = await getCurrentProfile();
  const supabase = await createAuthClient();

  const { data: preferences } = await supabase
    .from("user_preferences")
    .select("theme, default_sort, email_digest")
    .eq("user_id", user.id)
    .maybeSingle();

  return (
    <div className="container" style={{ paddingBlock: "clamp(28px,4vw,48px)", maxWidth: 820 }}>
      <nav className="crumbs" aria-label="Breadcrumb" style={{ paddingTop: 0, marginBottom: 18 }}>
        <Link href="/account">Account</Link>
        <span className="crumbs__sep" aria-hidden="true">/</span>
        <span aria-current="page">Settings</span>
      </nav>

      <div className="row-between" style={{ marginBottom: 30 }}>
        <div>
          <h1 style={{ fontSize: "clamp(1.5rem,3vw,1.9rem)" }}>Account settings</h1>
          <p className="muted" style={{ fontSize: 14, marginTop: 6 }}>
            Manage your profile, password and preferences.
          </p>
        </div>
        <SignOutButton />
      </div>

      <div className="stack-lg">
        <section className="card" style={{ padding: "clamp(20px,3vw,28px)" }}>
          <h2 style={{ fontSize: "1.05rem", marginBottom: 4 }}>Profile</h2>
          <p className="muted" style={{ fontSize: 13.5, marginBottom: 18 }}>
            This is what appears on your account page.
          </p>
          <ProfileForm
            fullName={profile?.full_name ?? ""}
            username={profile?.username ?? ""}
            bio={profile?.bio ?? ""}
            email={user.email ?? ""}
          />
        </section>

        <section className="card" style={{ padding: "clamp(20px,3vw,28px)" }}>
          <h2 style={{ fontSize: "1.05rem", marginBottom: 4 }}>Password</h2>
          <p className="muted" style={{ fontSize: 13.5, marginBottom: 18 }}>
            Choose something long. You will be signed out of other sessions except this one.
          </p>
          <PasswordForm />
        </section>

        <section className="card" style={{ padding: "clamp(20px,3vw,28px)" }}>
          <h2 style={{ fontSize: "1.05rem", marginBottom: 4 }}>Appearance</h2>
          <p className="muted" style={{ fontSize: 13.5, marginBottom: 18 }}>
            Applied immediately on this device and remembered here. Every palette works in
            both light and dark.
          </p>
          <ThemeChooser />
        </section>

        <section className="card" style={{ padding: "clamp(20px,3vw,28px)" }}>
          <h2 style={{ fontSize: "1.05rem", marginBottom: 4 }}>Preferences</h2>
          <p className="muted" style={{ fontSize: 13.5, marginBottom: 18 }}>
            Defaults apply the next time you open the directory.
          </p>
          <PreferencesForm
            defaultSort={preferences?.default_sort ?? "popular"}
            emailDigest={preferences?.email_digest ?? true}
          />
        </section>

        <section className="card" style={{ padding: "clamp(20px,3vw,28px)" }}>
          <h2 style={{ fontSize: "1.05rem", marginBottom: 4 }}>Danger zone</h2>
          <p className="muted" style={{ fontSize: 13.5, marginBottom: 14 }}>
            Deleting your account removes your profile, saved tools and history permanently.
            This cannot be undone.
          </p>
          <DeleteAccountForm />
        </section>
      </div>
    </div>
  );
}
