import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { createAuthClient, getCurrentProfile, getCurrentUser } from "@/lib/supabase/auth-server";
import { ToolCard } from "@/components/tool-card";
import { SignOutButton } from "@/components/sign-out-button";
import { ArrowRight, Bookmark, Clock, Settings, Sparkles } from "@/components/icons";
import type { Tool } from "@/lib/types";

export const metadata: Metadata = {
  title: "Your account",
  robots: { index: false, follow: false },
};

export const dynamic = "force-dynamic";

const TOOL_COLUMNS = `
  id, slug, name, tagline, description, website_url, logo_url,
  pricing_model, starting_price, tags, is_featured, is_trending,
  rating, rating_count, favorite_count, view_count, added_at,
  tool_categories ( categories ( slug ) )
`;

type RawTool = Omit<Tool, "category_slugs"> & {
  tool_categories: { categories: { slug: string } | null }[] | null;
};

function normalise(row: RawTool): Tool {
  const { tool_categories, ...rest } = row;
  return {
    ...rest,
    rating: Number(rest.rating ?? 0),
    category_slugs: (tool_categories ?? [])
      .map((tc) => tc.categories?.slug)
      .filter((s): s is string => Boolean(s)),
  };
}

export default async function AccountPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/account");

  const profile = await getCurrentProfile();
  const supabase = await createAuthClient();

  const [favoritesResult, recentResult] = await Promise.all([
    supabase
      .from("favorites")
      .select(`created_at, tools ( ${TOOL_COLUMNS} )`)
      .eq("user_id", user.id)
      .order("created_at", { ascending: false })
      .limit(6),
    supabase
      .from("recently_viewed")
      .select(`viewed_at, tools ( ${TOOL_COLUMNS} )`)
      .eq("user_id", user.id)
      .order("viewed_at", { ascending: false })
      .limit(4),
  ]);

  const favorites = (favoritesResult.data ?? [])
    .map((row) => (row as unknown as { tools: RawTool | null }).tools)
    .filter((t): t is RawTool => Boolean(t))
    .map(normalise);

  const recent = (recentResult.data ?? [])
    .map((row) => (row as unknown as { tools: RawTool | null }).tools)
    .filter((t): t is RawTool => Boolean(t))
    .map(normalise);

  const displayName = profile?.full_name || profile?.username || user.email?.split("@")[0] || "there";

  return (
    <div className="container" style={{ paddingBlock: "clamp(28px,4vw,48px)" }}>
      <div className="row-between" style={{ marginBottom: 28 }}>
        <div>
          <span className="eyebrow">Account</span>
          <h1 style={{ fontSize: "clamp(1.6rem,3.2vw,2.1rem)", marginTop: 8 }}>
            Welcome back, {displayName}
          </h1>
          <p className="muted" style={{ fontSize: 14, marginTop: 6 }}>
            Signed in as {user.email}
            {profile?.role === "admin" && (
              <span className="price" style={{ marginLeft: 10 }}>
                Admin
              </span>
            )}
          </p>
        </div>
        <div className="row" style={{ gap: 8 }}>
          <Link href="/account/settings" className="btn btn--ghost btn--sm">
            <Settings size={14} /> Settings
          </Link>
          <SignOutButton />
        </div>
      </div>

      <div className="stats" style={{ marginBottom: 34 }}>
        <div className="stat">
          <div className="stat__value">{favorites.length}</div>
          <div className="stat__label">Saved tools</div>
        </div>
        <div className="stat">
          <div className="stat__value">{recent.length}</div>
          <div className="stat__label">Recently viewed</div>
        </div>
        <div className="stat">
          <div className="stat__value">
            {profile?.created_at
              ? new Date(profile.created_at).toLocaleDateString("en-GB", {
                  month: "short",
                  year: "numeric",
                })
              : "—"}
          </div>
          <div className="stat__label">Member since</div>
        </div>
        <div className="stat">
          <div className="stat__value">{profile?.role === "admin" ? "Admin" : "Free"}</div>
          <div className="stat__label">Plan</div>
        </div>
      </div>

      <section style={{ marginBottom: 40 }}>
        <div className="section-head">
          <div>
            <h2 style={{ fontSize: "1.25rem" }}>
              <Bookmark size={17} style={{ display: "inline", marginRight: 8, verticalAlign: -2 }} />
              Your saved tools
            </h2>
            <p>Everything you have bookmarked, newest first.</p>
          </div>
          <Link href="/tools" className="btn btn--ghost btn--sm">
            Browse more <ArrowRight size={14} />
          </Link>
        </div>

        {favorites.length === 0 ? (
          <div className="empty">
            <span className="empty__icon">
              <Bookmark size={18} />
            </span>
            <h3>No saved tools yet</h3>
            <p>
              Tap the heart on any tool to save it here. Your shortlist is private to your
              account.
            </p>
            <Link href="/tools" className="btn btn--sm" style={{ marginTop: 6 }}>
              Find tools to save
            </Link>
          </div>
        ) : (
          <div className="tool-grid">
            {favorites.map((tool) => (
              <ToolCard key={tool.id} tool={tool} />
            ))}
          </div>
        )}
      </section>

      <section style={{ marginBottom: 40 }}>
        <div className="section-head">
          <div>
            <h2 style={{ fontSize: "1.25rem" }}>
              <Clock size={17} style={{ display: "inline", marginRight: 8, verticalAlign: -2 }} />
              Recently viewed
            </h2>
            <p>Your last few visits, so you can pick the thread back up.</p>
          </div>
        </div>

        {recent.length === 0 ? (
          <div className="empty">
            <span className="empty__icon">
              <Clock size={18} />
            </span>
            <h3>Nothing viewed yet</h3>
            <p>Open a tool page and it will appear here.</p>
          </div>
        ) : (
          <div className="tool-grid">
            {recent.map((tool) => (
              <ToolCard key={tool.id} tool={tool} />
            ))}
          </div>
        )}
      </section>

      <section>
        <div className="card" style={{ padding: "clamp(20px,3vw,28px)" }}>
          <span className="eyebrow">
            <Sparkles size={13} /> Recommended next
          </span>
          <h2 style={{ fontSize: "1.1rem", marginTop: 10 }}>Try these categories</h2>
          <p className="muted" style={{ fontSize: 14, marginTop: 6, maxWidth: "56ch" }}>
            Based on what is popular in the directory right now.
          </p>
          <div className="row" style={{ marginTop: 14, gap: 8 }}>
            {[
              { label: "AI Coding", href: "/tools?category=ai-coding" },
              { label: "AI Video", href: "/tools?category=ai-video" },
              { label: "AI Research", href: "/tools?category=ai-research" },
              { label: "AI Automation", href: "/tools?category=ai-automation" },
            ].map((item) => (
              <Link key={item.href} href={item.href} className="chip">
                {item.label} <ArrowRight size={12} />
              </Link>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
