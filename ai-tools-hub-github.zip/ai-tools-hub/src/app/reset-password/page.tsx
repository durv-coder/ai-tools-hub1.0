import type { Metadata } from "next";
import Link from "next/link";
import { ResetRequestForm } from "@/components/auth-forms";

export const metadata: Metadata = {
  title: "Reset your password",
  robots: { index: false, follow: true },
};

export default function ResetPasswordPage() {
  return (
    <div className="container auth-wrap">
      <div className="auth-card">
        <span className="eyebrow">Account recovery</span>
        <h1 style={{ marginTop: 8 }}>Reset your password</h1>
        <p className="muted" style={{ fontSize: 13.5, marginTop: 6 }}>
          Enter the email on your account and we will send you a link to choose a new password.
        </p>

        <ResetRequestForm />

        <p className="auth-alt">
          Remembered it? <Link href="/login">Back to sign in</Link>
        </p>
      </div>
    </div>
  );
}
