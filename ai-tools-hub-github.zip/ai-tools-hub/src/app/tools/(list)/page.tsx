import type { Metadata } from "next";
import { ToolCard } from "@/components/tool-card";
import { DirectoryFilters, DirectoryToolbar } from "@/components/directory-filters";
import { Pagination } from "@/components/pagination";
import { SearchBox } from "@/components/search-box";
import { getCategories, getCategoryCounts, searchTools } from "@/lib/queries";
import type { PricingModel, SortKey } from "@/lib/types";

/**
 * The directory. Filters, sort and pagination all live in the URL, so every
 * state is linkable, shareable and back-button friendly — no client store.
 *
 * Must stay dynamic: it reads `searchParams`, and `force-static` alongside
 * `searchParams` silently produces an always-empty page.
 */
export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Browse AI tools",
  description:
    "Search and filter AI tools by category, pricing and popularity. Compare free and paid options across chat, coding, image, video, audio, writing and infrastructure.",
  alternates: { canonical: "/tools" },
};

type SearchParams = Record<string, string | string[] | undefined>;

const SORTS: SortKey[] = ["popular", "rating", "newest", "alpha"];
const PRICINGS: (PricingModel | "all")[] = ["all", "free", "freemium", "paid"];

function toArray(value: string | string[] | undefined): string[] {
  if (!value) return [];
  return Array.isArray(value) ? value : [value];
}

export default async function ToolsPage({
  searchParams,
}: {
  searchParams: Promise<SearchParams>;
}) {
  const sp = await searchParams;

  // Validate every input against a closed list. An unrecognised sort used to be
  // passed straight through, which made `?sort=trending` fall back to "popular"
  // and look like it worked.
  const sortParam = typeof sp.sort === "string" && SORTS.includes(sp.sort as SortKey)
    ? (sp.sort as SortKey)
    : "popular";
  const pricingParam =
    typeof sp.pricing === "string" && PRICINGS.includes(sp.pricing as PricingModel | "all")
      ? (sp.pricing as PricingModel | "all")
      : "all";
  const pageParam = Number.parseInt(String(sp.page ?? "1"), 10);
  const page = Number.isFinite(pageParam) && pageParam > 0 ? pageParam : 1;

  const categories = toArray(sp.category).filter((c) => /^[a-z0-9-]{1,60}$/.test(c));
  const q = typeof sp.q === "string" ? sp.q.slice(0, 120) : "";
  const trending = sp.trending === "1";
  const openSource = sp.openSource === "1";

  const [result, allCategories, counts] = await Promise.all([
    searchTools({
      search: q || undefined,
      categories,
      pricing: pricingParam,
      openSource,
      trending,
      sort: sortParam,
      page,
      perPage: 12,
    }).catch(() => ({ tools: [], total: 0, page: 1, perPage: 12, totalPages: 1 })),
    getCategories().catch(() => []),
    getCategoryCounts().catch(() => ({})),
  ]);

  /** Preserve the current filters in every pagination link. */
  const buildHref = (nextPage: number) => {
    const next = new URLSearchParams();
    if (q) next.set("q", q);
    for (const c of categories) next.append("category", c);
    if (pricingParam !== "all") next.set("pricing", pricingParam);
    if (sortParam !== "popular") next.set("sort", sortParam);
    if (openSource) next.set("openSource", "1");
    if (trending) next.set("trending", "1");
    if (nextPage > 1) next.set("page", String(nextPage));
    const qs = next.toString();
    return `/tools${qs ? `?${qs}` : ""}`;
  };

  return (
    <div className="container page">
      <header className="page-head">
        <p className="eyebrow">Directory</p>
        <h1 className="page-title">Browse AI tools</h1>
        <p className="page-lede">
          {trending
            ? "Notable tools worth a look this week."
            : "Every entry is hand-checked, with pricing and licence read from the source."}
        </p>
      </header>

      <div className="dir-search">
        <SearchBox initialValue={q} />
      </div>

      <div className="dir-layout">
        <aside className="dir-side" aria-label="Filters">
          <DirectoryFilters
            categories={allCategories.map((c) => ({
              id: c.id,
              slug: c.slug,
              name: c.name,
            })) as never}
            counts={counts}
            totalTools={result.total}
          />
        </aside>

        <section className="dir-main" aria-label="Results">
          <DirectoryToolbar
            total={result.total}
            showing={result.tools.length}
            categories={allCategories}
          />

          {result.tools.length === 0 ? (
            <div className="empty-state">
              <h2>No tools match those filters</h2>
              <p>
                {q
                  ? `Nothing found for “${q}”. Try a shorter phrase, or widen the filters.`
                  : "Try removing a filter or two — the directory is small and deliberately selective."}
              </p>
              <a href="/tools" className="btn btn--sm">
                Reset the directory
              </a>
            </div>
          ) : (
            <div className="tool-grid">
              {result.tools.map((tool) => (
                <ToolCard key={tool.id} tool={tool} />
              ))}
            </div>
          )}

          <Pagination page={result.page} totalPages={result.totalPages} buildHref={buildHref} />
        </section>
      </div>
    </div>
  );
}
