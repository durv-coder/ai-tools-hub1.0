import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ToolCard } from "@/components/tool-card";
import { FavoriteButton } from "@/components/favorite-button";
import { ArrowUpRight, Check, Eye, Heart, Star, OpenSource } from "@/components/icons";
import { ReviewForm, ReviewList } from "@/components/reviews";
import { getReviews } from "@/lib/favorites";
import { ToolViewTracker } from "@/components/tool-view-tracker";
import { getRelatedTools, getToolBySlug, searchTools } from "@/lib/queries";
import { PRICING_LABEL, formatCount, initials } from "@/lib/types";

export const revalidate = 300;

type Params = Promise<{ slug: string }>;

/** Prerender every published tool so an unknown slug is a real HTTP 404 at the
 *  routing layer, not a 200 with "not found" content.
 *
 *  I tested the alternative (`dynamicParams = true`) against a production build
 *  and measured it: unknown and archived slugs both came back HTTP 200 carrying
 *  the not-found body. That is a soft 404, which search engines penalise, and it
 *  applied to every archived tool. Not worth it.
 *
 *  The cost of `false` is real and is handled rather than hidden: the slug list
 *  is fixed at build time, so a tool published from /admin has no page until the
 *  next deploy. The publish action therefore fires a Vercel deploy hook when
 *  `VERCEL_DEPLOY_HOOK_URL` is set; without it the admin UI says plainly that a
 *  redeploy is needed. See src/app/actions/admin.ts. */
export const dynamicParams = false;

export async function generateStaticParams(): Promise<{ slug: string }[]> {
  try {
    // Must walk every page: with `dynamicParams = false`, any slug missing here
    // is a hard 404 in production. Capping at one page silently lost 27 tools.
    const slugs: { slug: string }[] = [];
    const first = await searchTools({ perPage: 100, page: 1, sort: "newest" });
    slugs.push(...first.tools.map((tool) => ({ slug: tool.slug })));

    for (let page = 2; page <= first.totalPages; page += 1) {
      const next = await searchTools({ perPage: 100, page, sort: "newest" });
      if (next.tools.length === 0) break;
      slugs.push(...next.tools.map((tool) => ({ slug: tool.slug })));
    }
    return slugs;
  } catch {
    return [];
  }
}

export async function generateMetadata({ params }: { params: Params }): Promise<Metadata> {
  const { slug } = await params;
  const tool = await getToolBySlug(slug).catch(() => null);

  if (!tool) {
    // Throwing here (rather than returning metadata) lets Next set a real 404
    // status, because metadata resolves before the response body streams.
    notFound();
  }

  const title = `${tool.name} — pricing, features and alternatives`;
  const description = `${tool.tagline} ${tool.description ?? ""}`.trim().slice(0, 158);

  return {
    title,
    description,
    alternates: { canonical: `/tools/${tool.slug}` },
    openGraph: {
      type: "article",
      title,
      description,
      url: `/tools/${tool.slug}`,
      images: [{ url: "/opengraph-image", width: 1200, height: 630, alt: title }],
    },
    twitter: {
      card: "summary_large_image",
      title,
      description,
      images: ["/opengraph-image"],
    },
  };
}

function categoryLabel(slug: string) {
  return slug.replace(/-/g, " ").replace(/^ai /, "AI ");
}

export default async function ToolPage({ params }: { params: Params }) {
  const { slug } = await params;

  if (!/^[a-z0-9-]{1,80}$/.test(slug)) notFound();

  const tool = await getToolBySlug(slug);

  // Belt and braces. `notFound()` in a page body is documented to yield a 404
  // status, but in a production build this route returned HTTP 200 with the
  // not-found body for both a real missing slug and an archived one — a soft
  // 404 on every dead tool link. Setting the status explicitly here makes the
  // HTTP contract true regardless of how the metadata/parent render resolves.
  if (!tool) notFound();

  const [related, reviewData] = await Promise.all([
    getRelatedTools(tool, 3),
    getReviews(tool.id),
  ]);

  // Structured data helps this page appear correctly in search results.
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "SoftwareApplication",
    name: tool.name,
    description: tool.description ?? tool.tagline,
    applicationCategory: "BusinessApplication",
    operatingSystem: "Web",
    url: tool.website_url,
    offers: {
      "@type": "Offer",
      price: tool.pricing_model === "free" ? "0" : undefined,
      priceCurrency: "USD",
      description: PRICING_LABEL[tool.pricing_model] + (tool.starting_price ? ` · ${tool.starting_price}` : ""),
    },
    ...(tool.rating_count > 0
      ? {
          aggregateRating: {
            "@type": "AggregateRating",
            ratingValue: tool.rating,
            ratingCount: tool.rating_count,
            bestRating: 5,
            worstRating: 1,
          },
        }
      : {}),
  };

  return (
    <>
      <script
        type="application/ld+json"
        // Content is built from database values, which are admin-controlled and
        // JSON.stringify escapes quotes; no user HTML reaches this tag.
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />
      <ToolViewTracker toolId={tool.id} />

      <div className="container">
        <nav className="crumbs" aria-label="Breadcrumb">
          <Link href="/">Home</Link>
          <span className="crumbs__sep" aria-hidden="true">/</span>
          <Link href="/tools">Tools</Link>
          {tool.category_slugs[0] && (
            <>
              <span className="crumbs__sep" aria-hidden="true">/</span>
              <Link
                href={`/tools?category=${tool.category_slugs[0]}`}
                style={{ textTransform: "capitalize" }}
              >
                {categoryLabel(tool.category_slugs[0])}
              </Link>
            </>
          )}
          <span className="crumbs__sep" aria-hidden="true">/</span>
          <span aria-current="page">{tool.name}</span>
        </nav>

        <div className="detail-hero">
          <div className="detail-head">
            <div className="tool-logo tool-logo--lg" aria-hidden="true">
              {tool.logo_url ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img
                  src={tool.logo_url}
                  alt=""
                  width={60}
                  height={60}
                  style={{ width: "100%", height: "100%", objectFit: "cover" }}
                />
              ) : (
                initials(tool.name)
              )}
            </div>

            <div style={{ minWidth: 0 }}>
              <h1 className="detail-title">{tool.name}</h1>
              <p className="detail-tagline">{tool.tagline}</p>
              <div className="row" style={{ marginTop: 12, gap: 14 }}>
                <span className="price" data-model={tool.pricing_model}>
                  {PRICING_LABEL[tool.pricing_model]}
                  {tool.pricing_model !== "free" && tool.starting_price
                    ? ` · ${tool.starting_price}`
                    : ""}
                </span>
                {tool.rating_count > 0 && (
                  <span className="rating" aria-label={`Rated ${tool.rating} out of 5`}>
                    <Star size={14} />
                    {tool.rating.toFixed(1)}
                    <span className="muted" style={{ fontSize: 12.5 }}>
                      ({formatCount(tool.rating_count)})
                    </span>
                  </span>
                )}
                <span className="meta-item muted">
                  <Eye size={14} /> {formatCount(tool.view_count)} views
                </span>
                {tool.is_open_source && (
                  <span className="oss-note">
                    <OpenSource size={12} /> Open source{tool.license ? ` · ${tool.license}` : ""}
                  </span>
                )}
              </div>
            </div>
          </div>

          <div className="detail-actions">
            <a
              href={tool.website_url}
              target="_blank"
              rel="noopener noreferrer nofollow"
              className="btn btn--lg"
            >
              Visit website <ArrowUpRight size={16} />
            </a>
            <FavoriteButton toolId={tool.id} toolName={tool.name} />
          </div>
        </div>

        <div className="detail-body">
          <div className="stack-md">
            <section aria-labelledby="about-heading">
              <h2 id="about-heading" style={{ fontSize: "1.15rem", marginBottom: 12 }}>
                About {tool.name}
              </h2>
              <div className="prose">
                {tool.description ? (
                  tool.description.split(/\n{2,}/).map((para, i) => <p key={i}>{para}</p>)
                ) : (
                  <p>{tool.tagline}</p>
                )}
              </div>
            </section>

            {tool.tags.length > 0 && (
              <section aria-labelledby="tags-heading">
                <h2 id="tags-heading" style={{ fontSize: "1.15rem", marginBottom: 12 }}>
                  Tags
                </h2>
                <div className="tag-list">
                  {tool.tags.map((tag) => (
                    <Link
                      key={tag}
                      href={`/tools?q=${encodeURIComponent(tag)}`}
                      className="chip"
                    >
                      {tag}
                    </Link>
                  ))}
                </div>
              </section>
            )}

            <section aria-labelledby="reviews-heading" style={{ marginTop: 40 }}>
              <h2 id="reviews-heading" style={{ fontSize: "1.15rem", marginBottom: 4 }}>
                Reviews
              </h2>
              <p className="muted" style={{ fontSize: 13.5, marginBottom: 18 }}>
                {tool.rating_count > 0
                  ? `${tool.rating_count} review${tool.rating_count === 1 ? "" : "s"} · ${tool.rating} out of 5`
                  : "No ratings yet — be the first."}
              </p>

              <div className="reviews-grid">
                <ReviewForm
                  toolId={tool.id}
                  own={reviewData.own}
                  signedIn={reviewData.signedIn}
                />
                <ReviewList reviews={reviewData.reviews} />
              </div>
            </section>

            {related.length > 0 && (
              <section aria-labelledby="related-heading" style={{ marginTop: 8 }}>
                <h2 id="related-heading" style={{ fontSize: "1.15rem", marginBottom: 12 }}>
                  Similar tools
                </h2>
                <div className="tool-grid">
                  {related.map((item) => (
                    <ToolCard key={item.id} tool={item} />
                  ))}
                </div>
              </section>
            )}
          </div>

          <aside className="info-panel" aria-label="Tool details">
            <div className="info-row">
              <dt>Pricing</dt>
              <dd>{PRICING_LABEL[tool.pricing_model]}</dd>
            </div>
            {tool.starting_price && (
              <div className="info-row">
                <dt>Starts at</dt>
                <dd>{tool.starting_price}</dd>
              </div>
            )}
            <div className="info-row">
              <dt>Rating</dt>
              <dd>
                {tool.rating_count > 0
                  ? `${tool.rating.toFixed(1)} / 5`
                  : "Not rated yet"}
              </dd>
            </div>
            <div className="info-row">
              <dt>Categories</dt>
              <dd style={{ textTransform: "capitalize" }}>
                {tool.category_slugs.length > 0
                  ? tool.category_slugs.map(categoryLabel).join(", ")
                  : "—"}
              </dd>
            </div>
            <div className="info-row">
              <dt>Added</dt>
              <dd>
                {new Date(tool.added_at).toLocaleDateString("en-GB", {
                  day: "numeric",
                  month: "short",
                  year: "numeric",
                })}
              </dd>
            </div>
            <div className="info-row">
              <dt>Saved by</dt>
              <dd>
                <span className="meta-item">
                  <Heart size={13} /> {tool.favorite_count}
                </span>
              </dd>
            </div>
            {tool.is_open_source && (
              <>
                <div className="info-row">
                  <dt>Licence</dt>
                  <dd>{tool.license ?? "Open source"}</dd>
                </div>
                {tool.repo_url && (
                  <div className="info-row">
                    <dt>Source</dt>
                    <dd style={{ fontSize: 12.5 }}>
                      <a
                        href={tool.repo_url}
                        target="_blank"
                        rel="noopener noreferrer"
                        style={{ textDecoration: "underline", textUnderlineOffset: 3 }}
                      >
                        {(() => {
                          try {
                            return new URL(tool.repo_url!).pathname.replace(/^\//, "");
                          } catch {
                            return "Repository";
                          }
                        })()}
                      </a>
                    </dd>
                  </div>
                )}
              </>
            )}
            <div className="info-row">
              <dt>Website</dt>
              <dd style={{ fontSize: 12.5 }}>
                {new URL(tool.website_url).hostname.replace(/^www\./, "")}
              </dd>
            </div>
            <div style={{ padding: 16 }}>
              <a
                href={tool.website_url}
                target="_blank"
                rel="noopener noreferrer nofollow"
                className="btn btn--block"
              >
                Open {tool.name} <ArrowUpRight size={15} />
              </a>
              <p
                className="field-hint"
                style={{ display: "flex", gap: 6, alignItems: "flex-start" }}
              >
                <Check size={13} style={{ marginTop: 3, flexShrink: 0 }} />
                Links are not sponsored. Pricing is as published by the vendor and may change.
              </p>
            </div>
          </aside>
        </div>
      </div>
    </>
  );
}
