import type { Metadata, Viewport } from "next";
import Script from "next/script";
import { Inter } from "next/font/google";
import "./globals.css";
import "./components.css";
import { SiteHeader } from "@/components/site-header";
import { FavoritesProvider } from "@/components/favorites-provider";
import { getFavoriteState } from "@/lib/favorites";
import { SiteFooter } from "@/components/site-footer";

const inter = Inter({
  subsets: ["latin"],
  display: "swap",
  variable: "--font-sans",
});

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "AI Tools Hub — discover the best AI tools",
    template: "%s · AI Tools Hub",
  },
  description:
    "A curated directory of the best AI tools for writing, coding, images, video, audio, research and automation. Compare pricing, features and ratings.",
  applicationName: "AI Tools Hub",
  keywords: [
    "AI tools",
    "AI directory",
    "best AI tools",
    "AI software",
    "generative AI",
  ],
  authors: [{ name: "AI Tools Hub" }],
  openGraph: {
    type: "website",
    siteName: "AI Tools Hub",
    title: "AI Tools Hub — discover the best AI tools",
    description:
      "A curated directory of the best AI tools for writing, coding, images, video, audio, research and automation.",
    url: siteUrl,
    images: [
      {
        url: "/opengraph-image",
        width: 1200,
        height: 630,
        alt: "AI Tools Hub — discover the best AI tools",
      },
    ],
  },
  twitter: {
    card: "summary_large_image",
    title: "AI Tools Hub — discover the best AI tools",
    description:
      "A curated directory of the best AI tools, with real pricing and ratings.",
    images: ["/opengraph-image"],
  },
  robots: {
    index: true,
    follow: true,
    googleBot: { index: true, follow: true, "max-image-preview": "large" },
  },
  alternates: { canonical: "/" },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#ffffff" },
    { media: "(prefers-color-scheme: dark)", color: "#08080a" },
  ],
};

/** Applies the saved theme before first paint so there is no flash.
 *  Inline and dependency-free on purpose — it must run before hydration. */
const themeScript = `
(function() {
  try {
    var VALID_MODES = ['light', 'dark', 'system'];
    var VALID_PALETTES = ['warm', 'slate', 'paper', 'sand', 'image'];
    var mode = localStorage.getItem('ath-theme');
    var palette = localStorage.getItem('ath-palette');
    if (VALID_MODES.indexOf(mode) === -1) mode = 'system';
    if (VALID_PALETTES.indexOf(palette) === -1) palette = 'warm';

    // 'system' has to be resolved here, before paint, or the page flashes the
    // wrong theme and then corrects itself.
    var resolved = mode === 'system'
      ? (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light')
      : mode;

    var root = document.documentElement;
    root.setAttribute('data-theme', resolved);
    root.setAttribute('data-palette', palette);
    root.setAttribute('data-theme-mode', mode);

    // Restore the background image before first paint, otherwise a saved photo
    // flashes as a flat palette and then pops in.
    var img = localStorage.getItem('ath-bg-image');
    var dim = Number(localStorage.getItem('ath-bg-dim'));
    var safe = false;
    if (img) {
      safe = img.indexOf('https:') === 0 || /^data:image\\/(png|jpeg|jpg|webp|gif|avif);base64,/i.test(img);
    }
    if (img && safe) {
      root.style.setProperty('--bg-image', 'url("' + img.replace(/"/g, '%22') + '")');
    }
    if (isFinite(dim) && dim >= 0 && dim <= 90) {
      root.style.setProperty('--bg-image-dim', String(dim));
    }
  } catch (e) {
    document.documentElement.setAttribute('data-theme', 'light');
    document.documentElement.setAttribute('data-palette', 'warm');
  }
})();
`;

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  // One server-side read of the viewer's favourites for the whole page. Cards
  // read from context instead of each firing their own request on mount.
  const favorites = await getFavoriteState();

  return (
    <html lang="en" className={inter.variable} data-scroll-behavior="smooth" suppressHydrationWarning>
      <body>
        {/* next/script hoists this into the initial HTML before hydration, so the
            theme is applied before first paint and React never renders a <script>
            element during a client render. `strategy` is fixed at module scope
            below because Next warns if it is passed a non-literal value. */}
        <Script id="theme-init" strategy="beforeInteractive">
          {themeScript}
        </Script>
        <a href="#main" className="skip-link">
          Skip to content
        </a>
        <FavoritesProvider initial={favorites}>
          <SiteHeader />
          <main id="main">{children}</main>
        </FavoritesProvider>
        <SiteFooter />
      </body>
    </html>
  );
}
