import type { MetadataRoute } from "next";
import { getCategories, searchTools } from "@/lib/queries";

const SITE = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";

export const revalidate = 3600;

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const staticRoutes: MetadataRoute.Sitemap = [
    { url: `${SITE}/`, changeFrequency: "daily", priority: 1 },
    { url: `${SITE}/tools`, changeFrequency: "daily", priority: 0.9 },
    { url: `${SITE}/categories`, changeFrequency: "weekly", priority: 0.8 },
    // /compare is useful indexed as a landing page, but individual
    // ?tools=a&tools=b permutations are not, so only the bare route is listed.
    { url: `${SITE}/compare`, changeFrequency: "weekly", priority: 0.7 },
    { url: `${SITE}/about`, changeFrequency: "monthly", priority: 0.4 },
    { url: `${SITE}/privacy`, changeFrequency: "yearly", priority: 0.2 },
  ];

  try {
    // Paginate: a single 48-row page silently omitted every tool past the 48th
    // from the sitemap, so those pages were never submitted for indexing.
    const [categories, firstPage] = await Promise.all([
      getCategories(),
      searchTools({ perPage: 48, sort: "newest", page: 1 }),
    ]);

    const allTools = [...firstPage.tools];
    for (let page = 2; page <= firstPage.totalPages; page += 1) {
      const next = await searchTools({ perPage: 48, sort: "newest", page });
      if (next.tools.length === 0) break;
      allTools.push(...next.tools);
    }

    const toolRoutes: MetadataRoute.Sitemap = allTools.map((tool) => ({
      url: `${SITE}/tools/${tool.slug}`,
      lastModified: new Date(tool.added_at),
      changeFrequency: "weekly",
      priority: 0.7,
    }));

    const categoryRoutes: MetadataRoute.Sitemap = categories.map((category) => ({
      url: `${SITE}/tools?category=${category.slug}`,
      changeFrequency: "weekly",
      priority: 0.6,
    }));

    return [...staticRoutes, ...toolRoutes, ...categoryRoutes];
  } catch {
    return staticRoutes;
  }
}
