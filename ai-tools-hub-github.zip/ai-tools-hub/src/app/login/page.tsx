import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { GoogleSignIn, LoginForm } from "@/components/auth-forms";
import { isGoogleEnabled } from "@/lib/oauth";
import { getCurrentUser } from "@/lib/supabase/auth-server";

export const metadata: Metadata = {
  title: "Sign in",
  description: "Sign in to save tools, track your history and manage your preferences.",
  robots: { index: false, follow: true },
};

export default async function LoginPage({
  searchParams,
}: {
  searchParams: Promise<{ next?: string; error?: string }>;
}) {
  const [user, googleEnabled] = await Promise.all([getCurrentUser(), isGoogleEnabled()]);
  if (user) redirect("/account");

  const params = await searchParams;
  const next = params.next && params.next.startsWith("/") ? params.next : "/account";

  return (
    <div className="container auth-wrap">
      <div className="auth-card">
        <span className="eyebrow">Welcome back</span>
        <h1 style={{ marginTop: 8 }}>Sign in</h1>
        <p className="muted" style={{ fontSize: 13.5, marginTop: 6 }}>
          Save tools, pick up where you left off, and keep your preferences synced.
        </p>

        {params.error && (
          <div className="alert" data-tone="error" role="alert" style={{ marginTop: 16 }}>
            {params.error}
          </div>
        )}

        {googleEnabled && <GoogleSignIn next={next} label="Continue with Google" />}

        <LoginForm next={next} />

        <p className="auth-alt">
          No account? <Link href="/signup">Create one</Link>
        </p>
      </div>
    </div>
  );
}
