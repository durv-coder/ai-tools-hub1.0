import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "Newsletter preferences",
  robots: { index: false, follow: false },
};

type Status = "done" | "already" | "invalid" | "error";

const COPY: Record<Status, { heading: string; body: string }> = {
  done: {
    heading: "You're unsubscribed.",
    body: "You won't receive any more newsletter email from Tools Hub. Nothing else about your account has changed.",
  },
  already: {
    heading: "You're already unsubscribed.",
    body: "This address is not on the newsletter list, so there's nothing left to do.",
  },
  invalid: {
    heading: "That link looks incomplete.",
    body: "The unsubscribe link is missing its token. Try opening the link from your email again, exactly as it appears.",
  },
  error: {
    heading: "Something went wrong.",
    body: "We couldn't process the unsubscribe request. Please try the link again in a moment.",
  },
};

export default async function UnsubscribedPage({
  searchParams,
}: {
  searchParams: Promise<{ status?: string }>;
}) {
  const params = await searchParams;
  const status = (params.status ?? "done") as Status;
  const copy = COPY[status] ?? COPY.done;

  return (
    <div className="container section" style={{ maxWidth: 620 }}>
      <p className="eyebrow">Newsletter</p>
      <h1 style={{ fontSize: "clamp(1.6rem, 4vw, 2.2rem)", marginBottom: 12 }}>
        {copy.heading}
      </h1>
      <p className="muted" style={{ fontSize: 15.5, lineHeight: 1.6, marginBottom: 24 }}>
        {copy.body}
      </p>
      <Link href="/" className="btn btn--ghost">
        Back to the directory
      </Link>
    </div>
  );
}
