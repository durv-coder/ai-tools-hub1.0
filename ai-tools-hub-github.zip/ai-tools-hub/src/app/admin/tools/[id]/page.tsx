import Link from "next/link";
import { notFound } from "next/navigation";
import { getAdminTool } from "@/lib/admin/queries";
import { getCategories } from "@/lib/queries";
import { updateTool, deleteTool } from "@/app/actions/admin";
import { DeleteToolForm, ToolForm } from "@/components/admin/tool-form";

export default async function EditToolPage({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ created?: string; deploy?: string }>;
}) {
  const { id } = await params;
  const { created, deploy } = await searchParams;

  const [tool, categories] = await Promise.all([getAdminTool(id), getCategories()]);
  if (!tool) notFound();

  return (
    <div className="stack" style={{ gap: 18 }}>
      <div>
        <Link href="/admin/tools" className="muted" style={{ fontSize: 13 }}>← All tools</Link>
        <div className="admin-title-row">
          <h2 style={{ fontSize: "1.3rem", marginTop: 6 }}>{tool.name}</h2>
          <Link href={`/tools/${tool.slug}`} className="btn btn--ghost btn--sm">View page</Link>
        </div>
        {created && (
          <p className="alert alert--success" role="status" style={{ marginTop: 10 }}>
            Tool created.{deploy ? ` ${deploy}` : " Its page appears after the next rebuild."}
          </p>
        )}
      </div>

      <ToolForm
        action={updateTool}
        tool={tool}
        categories={categories.map((c) => ({ id: c.id, name: c.name, slug: c.slug }))}
        submitLabel="Save changes"
      />

      <DeleteToolForm action={deleteTool} id={tool.id} name={tool.name} />
    </div>
  );
}
