import Link from "next/link";
import { getCategories } from "@/lib/queries";
import { createTool } from "@/app/actions/admin";
import { ToolForm } from "@/components/admin/tool-form";

export default async function NewToolPage() {
  const categories = await getCategories();

  return (
    <div className="stack" style={{ gap: 18 }}>
      <div>
        <Link href="/admin/tools" className="muted" style={{ fontSize: 13 }}>← All tools</Link>
        <h2 style={{ fontSize: "1.3rem", marginTop: 6 }}>Add a tool</h2>
        <p className="muted" style={{ fontSize: 13.5, marginTop: 4 }}>
          Saving a published tool needs a rebuild before its page exists at /tools/&lt;slug&gt;.
        </p>
      </div>
      <ToolForm
        action={createTool}
        categories={categories.map((c) => ({ id: c.id, name: c.name, slug: c.slug }))}
        submitLabel="Create tool"
      />
    </div>
  );
}
