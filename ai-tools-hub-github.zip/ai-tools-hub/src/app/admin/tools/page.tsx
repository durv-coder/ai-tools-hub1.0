import Link from "next/link";
import { getAdminTools } from "@/lib/admin/queries";
import { setToolStatus, toggleToolFlag } from "@/app/actions/admin";
import { StatusSelect } from "@/components/admin/status-select";

type SearchParams = Promise<{
  q?: string;
  status?: string;
  page?: string;
  deleted?: string;
}>;

const STATUSES = ["all", "published", "draft", "archived"] as const;

function asStatus(v: string | undefined): (typeof STATUSES)[number] {
  return STATUSES.includes(v as (typeof STATUSES)[number]) ? (v as (typeof STATUSES)[number]) : "all";
}

export default async function AdminToolsPage({ searchParams }: { searchParams: SearchParams }) {
  const params = await searchParams;
  const q = (params.q ?? "").slice(0, 80);
  const status = asStatus(params.status);
  const page = Math.max(1, Number(params.page ?? 1) || 1);

  const result = await getAdminTools({ search: q, status, page, perPage: 20 });

  const buildHref = (next: { status?: string; page?: number }) => {
    const sp = new URLSearchParams();
    if (q) sp.set("q", q);
    const s = next.status ?? status;
    if (s !== "all") sp.set("status", s);
    const p = next.page ?? page;
    if (p > 1) sp.set("page", String(p));
    const qs = sp.toString();
    return `/admin/tools${qs ? `?${qs}` : ""}`;
  };

  return (
    <div className="stack" style={{ gap: 20 }}>
      {params.deleted && (
        <p className="alert alert--success" role="status">Tool deleted.</p>
      )}

      <div className="admin-toolbar">
        <form action="/admin/tools" method="get" className="admin-search" role="search">
          <input
            type="search"
            name="q"
            defaultValue={q}
            placeholder="Search by name or slug…"
            className="input"
            aria-label="Search tools"
          />
          {status !== "all" && <input type="hidden" name="status" value={status} />}
          <button type="submit" className="btn btn--sm">Search</button>
        </form>
        <Link href="/admin/tools/new" className="btn btn--sm">New tool</Link>
      </div>

      <div className="admin-filters" role="group" aria-label="Filter by status">
        {STATUSES.map((s) => (
          <Link
            key={s}
            href={buildHref({ status: s, page: 1 })}
            className="chip"
            aria-current={status === s ? "true" : undefined}
            style={status === s ? { background: "var(--ink)", color: "var(--bg)", borderColor: "var(--ink)" } : undefined}
          >
            {s === "all" ? "All" : s[0].toUpperCase() + s.slice(1)}
          </Link>
        ))}
        <span className="muted" style={{ fontSize: 13, marginLeft: "auto" }}>
          {result.total} tool{result.total === 1 ? "" : "s"}
        </span>
      </div>

      {result.tools.length === 0 ? (
        <div className="card" style={{ padding: 28, textAlign: "center" }}>
          <p style={{ fontWeight: 600, marginBottom: 6 }}>Nothing matches that.</p>
          <p className="muted" style={{ fontSize: 14, marginBottom: 16 }}>
            Try a different search, or clear the status filter.
          </p>
          <Link href="/admin/tools" className="btn btn--ghost btn--sm">Clear filters</Link>
        </div>
      ) : (
        <div className="card admin-table-wrap">
          <table className="admin-table">
            <thead>
              <tr>
                <th scope="col">Tool</th>
                <th scope="col">Status</th>
                <th scope="col">Flags</th>
                <th scope="col" className="num">Views</th>
                <th scope="col" className="num">Rating</th>
                <th scope="col"><span className="sr-only">Actions</span></th>
              </tr>
            </thead>
            <tbody>
              {result.tools.map((tool) => (
                <tr key={tool.id}>
                  <td>
                    <div className="admin-tool-cell">
                      {tool.logo_url ? (
                        // eslint-disable-next-line @next/next/no-img-element
                        <img src={tool.logo_url} alt="" width={26} height={26} loading="lazy" />
                      ) : (
                        <span className="admin-tool-initial" aria-hidden="true">
                          {tool.name.slice(0, 1).toUpperCase()}
                        </span>
                      )}
                      <div>
                        <Link href={`/admin/tools/${tool.id}`} style={{ fontWeight: 550 }}>
                          {tool.name}
                        </Link>
                        <div className="muted" style={{ fontSize: 12 }}>/{tool.slug}</div>
                      </div>
                    </div>
                  </td>
                  <td>
                    <StatusSelect
                      action={setToolStatus}
                      id={tool.id}
                      name="status"
                      value={tool.status}
                      label={`Status for ${tool.name}`}
                    />
                  </td>
                  <td>
                    <div className="admin-inline">
                      <form action={toggleToolFlag}>
                        <input type="hidden" name="id" value={tool.id} />
                        <input type="hidden" name="flag" value="is_featured" />
                        <input type="hidden" name="next" value={String(!tool.is_featured)} />
                        <button
                          type="submit"
                          className="chip chip--toggle"
                          aria-pressed={tool.is_featured}
                          title="Toggle featured"
                        >
                          {tool.is_featured ? "★ Featured" : "☆ Featured"}
                        </button>
                      </form>
                      <form action={toggleToolFlag}>
                        <input type="hidden" name="id" value={tool.id} />
                        <input type="hidden" name="flag" value="is_trending" />
                        <input type="hidden" name="next" value={String(!tool.is_trending)} />
                        <button
                          type="submit"
                          className="chip chip--toggle"
                          aria-pressed={tool.is_trending}
                          title="Toggle trending"
                        >
                          {tool.is_trending ? "↑ Trending" : "· Trending"}
                        </button>
                      </form>
                    </div>
                  </td>
                  <td className="num">{tool.view_count.toLocaleString("en-GB")}</td>
                  <td className="num">
                    {tool.rating_count > 0
                      ? `${tool.rating.toFixed(1)} (${tool.rating_count})`
                      : <span className="muted">—</span>}
                  </td>
                  <td>
                    <Link href={`/admin/tools/${tool.id}`} className="btn btn--ghost btn--tiny">Edit</Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {result.totalPages > 1 && (
        <nav className="admin-pager" aria-label="Pagination">
          {page > 1 && (
            <Link href={buildHref({ page: page - 1 })} className="btn btn--ghost btn--sm">Previous</Link>
          )}
          <span className="muted" style={{ fontSize: 13 }}>
            Page {page} of {result.totalPages}
          </span>
          {page < result.totalPages && (
            <Link href={buildHref({ page: page + 1 })} className="btn btn--ghost btn--sm">Next</Link>
          )}
        </nav>
      )}
    </div>
  );
}
