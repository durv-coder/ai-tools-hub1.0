import { getAdminStats } from "@/lib/admin/queries";
import { createCategory, deleteCategory, updateCategory } from "@/app/actions/admin";
import { CategoryForms } from "@/components/admin/category-forms";

export default async function AdminCategoriesPage({
  searchParams,
}: {
  searchParams: Promise<{ blocked?: string; deleted?: string }>;
}) {
  const params = await searchParams;
  const stats = await getAdminStats();

  return (
    <div className="stack" style={{ gap: 20 }}>
      {params.blocked && (
        <p className="alert alert--error" role="alert">
          That category still holds {params.blocked} tool
          {params.blocked === "1" ? "" : "s"}. Move them to another category first — deleting
          now would leave them uncategorised.
        </p>
      )}
      {params.deleted && (
        <p className="alert alert--success" role="status">Category deleted.</p>
      )}

      <CategoryForms
        categories={stats.perCategory}
        createAction={createCategory}
        updateAction={updateCategory}
        deleteAction={deleteCategory}
      />
    </div>
  );
}
