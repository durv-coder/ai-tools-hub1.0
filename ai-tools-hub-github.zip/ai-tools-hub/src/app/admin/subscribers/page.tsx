import { getSubscribers } from "@/lib/admin/queries";

export default async function AdminSubscribersPage() {
  const subscribers = await getSubscribers();
  const active = subscribers.filter((s) => !s.unsubscribed_at);

  return (
    <div className="stack" style={{ gap: 20 }}>
      <div className="card" style={{ padding: "clamp(18px,2.4vw,24px)" }}>
        <h2 style={{ fontSize: "1.02rem", marginBottom: 6 }}>Newsletter subscribers</h2>
        <p className="muted" style={{ fontSize: 13.5, lineHeight: 1.6, marginBottom: 0 }}>
          {active.length} active of {subscribers.length} shown.{" "}
          <strong>Sending is not connected</strong> — these addresses are stored but no email
          goes out until an ESP key is configured.
        </p>
      </div>

      {subscribers.length === 0 ? (
        <div className="card" style={{ padding: 28, textAlign: "center" }}>
          <p style={{ fontWeight: 600, marginBottom: 6 }}>No subscribers yet.</p>
          <p className="muted" style={{ fontSize: 14 }}>
            The capture form is on the homepage footer.
          </p>
        </div>
      ) : (
        <div className="card admin-table-wrap">
          <table className="admin-table">
            <thead>
              <tr>
                <th scope="col">Email</th>
                <th scope="col">Source</th>
                <th scope="col">Joined</th>
                <th scope="col">Status</th>
              </tr>
            </thead>
            <tbody>
              {subscribers.map((s) => (
                <tr key={s.id}>
                  <td>{s.email}</td>
                  <td className="muted">{s.source}</td>
                  <td className="muted">
                    {new Date(s.created_at).toLocaleDateString("en-GB", {
                      day: "numeric",
                      month: "short",
                      year: "numeric",
                    })}
                  </td>
                  <td>
                    {s.unsubscribed_at ? (
                      <span className="muted">Unsubscribed</span>
                    ) : (
                      <span>Active</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
