import Link from "next/link";
import { getAdminStats } from "@/lib/admin/queries";

export default async function AdminOverview() {
  const s = await getAdminStats();

  const cards = [
    { label: "Tools", value: s.tools.total, note: `${s.tools.published} published · ${s.tools.draft} draft · ${s.tools.archived} archived`, href: "/admin/tools" },
    { label: "Categories", value: s.categories, note: "All visible in the directory", href: "/admin/categories" },
    { label: "Accounts", value: s.users, note: "Registered profiles", href: null },
    { label: "Reviews", value: s.reviews, note: "Drive every rating shown", href: null },
    { label: "Favourites", value: s.favorites, note: "Saved across all accounts", href: null },
    { label: "Subscribers", value: s.subscribers.active, note: `${s.subscribers.total} total · sending not connected`, href: "/admin/subscribers" },
  ];

  return (
    <div className="stack" style={{ gap: 28 }}>
      <section className="admin-grid">
        {cards.map((c) => {
          const body = (
            <>
              <div className="admin-stat__value">{c.value}</div>
              <div className="admin-stat__label">{c.label}</div>
              <div className="admin-stat__note">{c.note}</div>
            </>
          );
          return c.href ? (
            <Link key={c.label} href={c.href} className="card admin-stat">
              {body}
            </Link>
          ) : (
            <div key={c.label} className="card admin-stat">{body}</div>
          );
        })}
      </section>

      <section className="admin-two">
        <div className="card" style={{ padding: "clamp(18px,2.4vw,24px)" }}>
          <h2 style={{ fontSize: "1.02rem", marginBottom: 4 }}>Most viewed</h2>
          <p className="muted" style={{ fontSize: 13, marginBottom: 14 }}>
            Real page views recorded since launch.
          </p>
          {s.topViewed.length === 0 ? (
            <p className="muted" style={{ fontSize: 14 }}>No views recorded yet.</p>
          ) : (
            <ol className="admin-list">
              {s.topViewed.map((t) => (
                <li key={t.slug}>
                  <Link href={`/tools/${t.slug}`}>{t.name}</Link>
                  <span className="muted">{t.view_count.toLocaleString("en-GB")}</span>
                </li>
              ))}
            </ol>
          )}
        </div>

        <div className="card" style={{ padding: "clamp(18px,2.4vw,24px)" }}>
          <h2 style={{ fontSize: "1.02rem", marginBottom: 4 }}>Tools per category</h2>
          <p className="muted" style={{ fontSize: 13, marginBottom: 14 }}>
            Published tools only.
          </p>
          <ul className="admin-list">
            {s.perCategory.map((c) => (
              <li key={c.slug}>
                <Link href={`/tools?category=${c.slug}`}>{c.name}</Link>
                <span className="muted">{c.count}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      <section className="card" style={{ padding: "clamp(18px,2.4vw,24px)" }}>
        <h2 style={{ fontSize: "1.02rem", marginBottom: 6 }}>Publishing changes</h2>
        <p className="muted" style={{ fontSize: 13.5, lineHeight: 1.6 }}>
          Tool pages are prerendered, so a new or renamed tool needs a rebuild before its
          page exists — otherwise <code>/tools/&lt;slug&gt;</code> returns 404. Saving here
          refreshes the homepage, directory and category pages, but a deploy is what
          creates the page itself.
        </p>
      </section>
    </div>
  );
}
