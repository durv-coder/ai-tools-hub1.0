import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { getAdminProfile } from "@/lib/auth/admin";
import { getCurrentUser } from "@/lib/supabase/auth-server";

export const metadata: Metadata = {
  title: "Admin",
  robots: { index: false, follow: false },
};

// Admin data must never be served from a cache shared with visitors.
export const dynamic = "force-dynamic";

const NAV = [
  { href: "/admin", label: "Overview" },
  { href: "/admin/tools", label: "Tools" },
  { href: "/admin/categories", label: "Categories" },
  { href: "/admin/subscribers", label: "Subscribers" },
];

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  // Non-admins are sent away rather than shown an empty shell. RLS is the real
  // boundary; this keeps the UI honest.
  const profile = await getAdminProfile();
  if (!profile) {
    // Two different cases: signed out should be asked to sign in, signed in but
    // not an admin should land somewhere useful instead of bouncing between
    // /admin and /login.
    const user = await getCurrentUser();
    redirect(user ? "/account" : "/login?next=/admin");
  }

  return (
    <div className="container section" style={{ maxWidth: 1180 }}>
      <div className="admin-head">
        <div>
          <p className="eyebrow">Admin</p>
          <h1 style={{ fontSize: "clamp(1.5rem, 3.4vw, 2rem)", marginBottom: 4 }}>
            Tools Hub control panel
          </h1>
          <p className="muted" style={{ fontSize: 14 }}>
            Signed in as {profile.full_name || profile.email}
          </p>
        </div>
        <Link href="/" className="btn btn--ghost btn--sm">
          View site
        </Link>
      </div>

      <nav className="admin-nav" aria-label="Admin sections">
        {NAV.map((item) => (
          <Link key={item.href} href={item.href} className="admin-nav__link">
            {item.label}
          </Link>
        ))}
      </nav>

      {children}
    </div>
  );
}
