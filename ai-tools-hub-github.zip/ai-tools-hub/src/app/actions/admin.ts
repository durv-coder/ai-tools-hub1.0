"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { createAuthClient } from "@/lib/supabase/auth-server";
import { requireAdmin } from "@/lib/auth/admin";
import { getSupabase } from "@/lib/supabase/server";

export type AdminState = { error?: string; success?: string } | null;

const SLUG_RE = /^[a-z0-9]+(-[a-z0-9]+)*$/;
const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

function slugify(input: string): string {
  return input
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 60);
}

/**
 * Validates a tool form against the same rules the database enforces.
 *
 * Mirroring the CHECK constraints here is not redundant: it turns a raw
 * Postgres error into a sentence the person filling in the form can act on.
 */
function readToolForm(formData: FormData) {
  const name = String(formData.get("name") ?? "").trim();
  const slugInput = String(formData.get("slug") ?? "").trim();
  const tagline = String(formData.get("tagline") ?? "").trim();
  const description = String(formData.get("description") ?? "").trim();
  const website_url = String(formData.get("website_url") ?? "").trim();
  const logo_url = String(formData.get("logo_url") ?? "").trim();
  const pricing_model = String(formData.get("pricing_model") ?? "freemium");
  const starting_price = String(formData.get("starting_price") ?? "").trim();
  const status = String(formData.get("status") ?? "published");
  const repo_url = String(formData.get("repo_url") ?? "").trim();
  const license = String(formData.get("license") ?? "").trim();
  const is_featured = formData.get("is_featured") === "on";
  const is_trending = formData.get("is_trending") === "on";
  const is_open_source = formData.get("is_open_source") === "on";
  const tags = String(formData.get("tags") ?? "")
    .split(",")
    .map((t) => t.trim().toLowerCase())
    .filter(Boolean)
    .slice(0, 12);
  const category_ids = formData
    .getAll("category_ids")
    .map((v) => Number(v))
    .filter((n) => Number.isInteger(n) && n > 0);

  const slug = slugInput || slugify(name);

  if (name.length < 1 || name.length > 60) return { error: "Name must be 1–60 characters." } as const;
  if (tagline.length < 1 || tagline.length > 120) {
    return { error: "Tagline must be 1–120 characters." } as const;
  }
  if (!SLUG_RE.test(slug)) {
    return { error: "Slug must be lowercase letters, numbers and single hyphens." } as const;
  }
  if (!/^https?:\/\/.+/.test(website_url)) {
    return { error: "Website URL must start with http:// or https://" } as const;
  }
  if (logo_url && !/^(\/|https?:\/\/)/.test(logo_url)) {
    return { error: "Logo must be a path starting with / or a full URL." } as const;
  }
  if (repo_url && !/^https?:\/\//.test(repo_url)) {
    return { error: "Repository URL must be a full URL." } as const;
  }
  if (!["free", "freemium", "paid"].includes(pricing_model)) {
    return { error: "Choose a valid pricing model." } as const;
  }
  if (!["published", "draft", "archived"].includes(status)) {
    return { error: "Choose a valid status." } as const;
  }
  if (description.length > 4000) return { error: "Description is too long (4000 max)." } as const;

  return {
    values: {
      name,
      slug,
      tagline,
      description: description || null,
      website_url,
      logo_url: logo_url || null,
      pricing_model,
      starting_price: starting_price || null,
      status,
      repo_url: is_open_source ? repo_url || null : null,
      license: is_open_source ? license || null : null,
      is_featured,
      is_trending,
      is_open_source,
      tags,
    },
    category_ids,
  } as const;
}

/** Re-checks the role: a server action can be invoked directly by a client. */
async function adminClient() {
  await requireAdmin();
  return createAuthClient();
}

// ---------------------------------------------------------------------------
// Deploy hook
// ---------------------------------------------------------------------------

/**
 * Tool pages are prerendered with `dynamicParams = false`, so a slug that did
 * not exist at build time 404s in production even though the directory lists it.
 * Publishing is therefore a two-part operation: write the row, then rebuild.
 *
 * The rebuild is a Vercel deploy hook — a plain POST to a secret URL, no SDK and
 * no extra dependency. It is optional: without `VERCEL_DEPLOY_HOOK_URL` the site
 * keeps working and the admin UI reports that a redeploy is needed, rather than
 * pretending the new tool is live.
 *
 * Best-effort by design. A failed hook must not roll back a saved tool, so the
 * caller gets a status to display instead of an exception.
 */
type DeployResult = "triggered" | "not-configured" | "failed";

async function triggerDeploy(): Promise<DeployResult> {
  const url = process.env.VERCEL_DEPLOY_HOOK_URL;
  if (!url) return "not-configured";

  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ source: "ai-tools-hub/admin" }),
      // Never let a slow hook hold the admin request open.
      signal: AbortSignal.timeout(5000),
    });
    return res.ok ? "triggered" : "failed";
  } catch {
    return "failed";
  }
}

/** Wording shown after a save. Publishing needs a rebuild; a rename can change
 *  the slug and orphan the old page, so it is treated like a publish. */
function deployNotice(result: DeployResult, needsRebuild: boolean): string | undefined {
  if (!needsRebuild) return undefined;
  if (result === "triggered") return "Rebuild triggered — the new page will be live in about a minute.";
  if (result === "not-configured")
    return "Saved. New tool pages need a redeploy before they resolve — set VERCEL_DEPLOY_HOOK_URL to automate this.";
  return "Saved, but the rebuild could not be triggered. Redeploy manually to publish the page.";
}

function revalidateAll(slug?: string) {
  // The public site is statically prerendered, so a content change has to
  // invalidate both the lists and the affected detail page.
  revalidatePath("/");
  revalidatePath("/tools");
  revalidatePath("/categories");
  if (slug) revalidatePath(`/tools/${slug}`);
  revalidatePath("/admin");
}

export async function createTool(_prev: AdminState, formData: FormData): Promise<AdminState> {
  const parsed = readToolForm(formData);
  if ("error" in parsed) return { error: parsed.error };

  const supabase = await adminClient();

  const { data, error } = await supabase
    .from("tools")
    .insert(parsed.values)
    .select("id")
    .single();

  if (error) {
    if (error.code === "23505") return { error: "That slug is already in use." };
    return { error: `Could not create the tool: ${error.message}` };
  }

  if (parsed.category_ids.length > 0) {
    const { error: linkError } = await supabase.from("tool_categories").insert(
      parsed.category_ids.map((category_id) => ({
        tool_id: data.id as string,
        category_id,
      })),
    );
    if (linkError) return { error: `Tool saved, but categories failed: ${linkError.message}` };
  }

  revalidateAll(parsed.values.slug);

  // A brand-new published slug has no prerendered page yet.
  const deploy = await triggerDeploy();
  const notice = parsed.values.status === "published"
    ? deployNotice(deploy, true)
    : undefined;
  redirect(
    `/admin/tools/${data.id}?created=1${notice ? `&deploy=${encodeURIComponent(notice)}` : ""}`,
  );
}

export async function updateTool(
  _prev: AdminState,
  formData: FormData,
): Promise<AdminState> {
  const id = String(formData.get("id") ?? "");
  if (!UUID_RE.test(id)) return { error: "Invalid tool id." };

  const parsed = readToolForm(formData);
  if ("error" in parsed) return { error: parsed.error };

  const supabase = await adminClient();

  // Read the previous slug/status first: a rename to an unused slug, or a draft
  // going live, creates a page that the last build did not prerender.
  const { data: before } = await supabase
    .from("tools")
    .select("slug, status")
    .eq("id", id)
    .single();
  const slugChanged =
    (before?.slug as string | undefined) !== parsed.values.slug ||
    (before?.status as string | undefined) !== parsed.values.status;

  const { error } = await supabase.from("tools").update(parsed.values).eq("id", id);
  if (error) {
    if (error.code === "23505") return { error: "That slug is already in use." };
    return { error: `Could not save: ${error.message}` };
  }

  // Replace category links wholesale — simpler and atomic enough for a form
  // submit, and avoids diffing.
  const { error: clearError } = await supabase
    .from("tool_categories")
    .delete()
    .eq("tool_id", id);
  if (clearError) return { error: `Could not update categories: ${clearError.message}` };

  if (parsed.category_ids.length > 0) {
    const { error: linkError } = await supabase.from("tool_categories").insert(
      parsed.category_ids.map((category_id) => ({ tool_id: id, category_id })),
    );
    if (linkError) return { error: `Could not update categories: ${linkError.message}` };
  }

  revalidateAll(parsed.values.slug);
  revalidatePath(`/admin/tools/${id}`);

  // Creating, renaming to a new slug, or publishing a draft all need a build.
  const needsRebuild = parsed.values.status === "published" && slugChanged;
  const deploy = needsRebuild ? await triggerDeploy() : "not-configured";
  return { success: `Saved.${needsRebuild ? ` ${deployNotice(deploy, true)}` : ""}` };
}

export async function setToolStatus(formData: FormData): Promise<void> {
  const id = String(formData.get("id") ?? "");
  const status = String(formData.get("status") ?? "");
  if (!UUID_RE.test(id) || !["published", "draft", "archived"].includes(status)) return;

  const supabase = await adminClient();
  await supabase.from("tools").update({ status }).eq("id", id);
  revalidateAll();
  revalidatePath(`/admin/tools/${id}`);
}

export async function toggleToolFlag(formData: FormData): Promise<void> {
  const id = String(formData.get("id") ?? "");
  const flag = String(formData.get("flag") ?? "");
  const next = formData.get("next") === "true";
  if (!UUID_RE.test(id) || !["is_featured", "is_trending"].includes(flag)) return;

  const supabase = await adminClient();
  await supabase.from("tools").update({ [flag]: next }).eq("id", id);
  revalidateAll();
  revalidatePath(`/admin/tools/${id}`);
}

export async function deleteTool(formData: FormData): Promise<void> {
  const id = String(formData.get("id") ?? "");
  const confirm = String(formData.get("confirm") ?? "");
  if (!UUID_RE.test(id) || confirm !== "DELETE") return;

  const supabase = await adminClient();
  await supabase.from("tools").delete().eq("id", id);
  revalidateAll();
  redirect("/admin/tools?deleted=1");
}

/* ------------------------------------------------------------------ categories */

export async function createCategory(
  _prev: AdminState,
  formData: FormData,
): Promise<AdminState> {
  const name = String(formData.get("name") ?? "").trim();
  const slugInput = String(formData.get("slug") ?? "").trim();
  const description = String(formData.get("description") ?? "").trim();
  const icon = String(formData.get("icon") ?? "sparkles").trim() || "sparkles";
  const sort_order = Number(formData.get("sort_order") ?? 0) || 0;

  if (name.length < 1 || name.length > 60) return { error: "Name must be 1–60 characters." };
  const slug = slugInput || slugify(name);
  if (!SLUG_RE.test(slug)) return { error: "Slug must be lowercase letters, numbers and hyphens." };

  const supabase = await adminClient();
  const { error } = await supabase
    .from("categories")
    .insert({ name, slug, description: description || null, icon, sort_order });

  if (error) {
    if (error.code === "23505") return { error: "That name or slug already exists." };
    return { error: `Could not create the category: ${error.message}` };
  }

  revalidateAll();
  revalidatePath("/admin/categories");
  return { success: `Added ${name}.` };
}

export async function updateCategory(
  _prev: AdminState,
  formData: FormData,
): Promise<AdminState> {
  const id = Number(formData.get("id"));
  if (!Number.isInteger(id) || id <= 0) return { error: "Invalid category id." };

  const name = String(formData.get("name") ?? "").trim();
  if (name.length < 1 || name.length > 60) return { error: "Name must be 1–60 characters." };

  // Only touch fields the form actually submitted. The inline rename form sends
  // nothing but the name, so a full-object update would have blanked the
  // description, icon and sort order as a side effect of renaming.
  const patch: Record<string, unknown> = { name };
  if (formData.has("description")) {
    patch.description = String(formData.get("description") ?? "").trim() || null;
  }
  if (formData.has("icon")) {
    patch.icon = String(formData.get("icon") ?? "").trim() || "sparkles";
  }
  if (formData.has("sort_order")) {
    patch.sort_order = Number(formData.get("sort_order") ?? 0) || 0;
  }

  const supabase = await adminClient();
  // Slug is deliberately not editable: it is referenced by URLs and by
  // `tool_categories` joins, and renaming it would break existing links.
  const { error } = await supabase.from("categories").update(patch).eq("id", id);

  if (error) {
    if (error.code === "23505") return { error: "That name is already taken." };
    return { error: `Could not save: ${error.message}` };
  }

  revalidateAll();
  revalidatePath("/admin/categories");
  return { success: "Saved." };
}

/** Refuses to delete a category that still has tools, rather than orphaning them. */
export async function deleteCategory(formData: FormData): Promise<void> {
  const id = Number(formData.get("id"));
  const confirm = String(formData.get("confirm") ?? "");
  if (!Number.isInteger(id) || id <= 0 || confirm !== "DELETE") return;

  await requireAdmin();
  const supabase = getSupabase();

  const { count } = await supabase
    .from("tool_categories")
    .select("tool_id", { count: "exact", head: true })
    .eq("category_id", id);

  if ((count ?? 0) > 0) {
    // Redirect carries the reason so the page can explain the refusal.
    redirect(`/admin/categories?blocked=${count}`);
  }

  const client = await createAuthClient();
  await client.from("categories").delete().eq("id", id);
  revalidateAll();
  revalidatePath("/admin/categories");
  redirect("/admin/categories?deleted=1");
}
