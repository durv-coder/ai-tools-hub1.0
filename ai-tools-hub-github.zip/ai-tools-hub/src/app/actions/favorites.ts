"use server";

import { revalidatePath } from "next/cache";
import { createAuthClient } from "@/lib/supabase/auth-server";

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export type FavoriteResult = { ok: boolean; saved?: boolean; error?: string; requiresAuth?: boolean };

/** Reads the ids the signed-in user has saved. Used to hydrate the heart state. */
export async function getFavoriteIds(): Promise<string[]> {
  const supabase = await createAuthClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return [];

  const { data } = await supabase.from("favorites").select("tool_id").eq("user_id", user.id);

  return (data ?? [])
    .map((row) => (row as { tool_id: string | null }).tool_id)
    .filter((id): id is string => Boolean(id));
}

/** Adds or removes a favourite. RLS enforces that a user can only touch their
 *  own rows, so this cannot be used to write on someone else's behalf. */
export async function toggleFavorite(toolId: string): Promise<FavoriteResult> {
  if (!UUID_RE.test(toolId)) return { ok: false, error: "Invalid tool." };

  const supabase = await createAuthClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return { ok: false, requiresAuth: true, error: "Sign in to save tools." };

  const { data: existing } = await supabase
    .from("favorites")
    .select("id")
    .eq("user_id", user.id)
    .eq("tool_id", toolId)
    .maybeSingle();

  if (existing) {
    const { error } = await supabase
      .from("favorites")
      .delete()
      .eq("user_id", user.id)
      .eq("tool_id", toolId);

    if (error) return { ok: false, error: "Could not remove this favourite." };

    revalidatePath("/account");
    return { ok: true, saved: false };
  }

  const { error } = await supabase
    .from("favorites")
    .insert({ user_id: user.id, tool_id: toolId });

  if (error) return { ok: false, error: "Could not save this favourite." };

  revalidatePath("/account");
  return { ok: true, saved: true };
}

// ---------------------------------------------------------------------------
// Reviews
// ---------------------------------------------------------------------------

const REVIEW_RATING_MIN = 1;
const REVIEW_RATING_MAX = 5;

export type ReviewResult =
  | { ok: true; rating: number }
  | { ok: false; error: string; requiresAuth?: boolean };

/**
 * Creates or updates the signed-in user's review for a tool.
 *
 * Validation is duplicated in the database (rating range, field lengths, and a
 * unique constraint on tool_id + user_id), so this function's checks are for
 * good error messages, not for safety. `tools.rating` and `rating_count` are
 * recomputed by the `sync_tool_rating` trigger, not written here.
 */
export async function submitReview(formData: FormData): Promise<ReviewResult> {
  const toolId = String(formData.get("toolId") ?? "");
  const rating = Number(formData.get("rating"));
  const title = String(formData.get("title") ?? "").trim();
  const body = String(formData.get("body") ?? "").trim();

  if (!UUID_RE.test(toolId)) return { ok: false, error: "Invalid tool." };
  if (!Number.isInteger(rating) || rating < REVIEW_RATING_MIN || rating > REVIEW_RATING_MAX) {
    return { ok: false, error: "Choose a rating from 1 to 5 stars." };
  }
  if (title.length > 120) return { ok: false, error: "Keep the headline under 120 characters." };
  if (body.length > 2000) return { ok: false, error: "Keep your review under 2000 characters." };

  const supabase = await createAuthClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return { ok: false, error: "Sign in to leave a review.", requiresAuth: true };

  const { error } = await supabase.from("reviews").upsert(
    {
      tool_id: toolId,
      user_id: user.id,
      rating,
      title: title || null,
      body: body || null,
      updated_at: new Date().toISOString(),
    },
    { onConflict: "tool_id,user_id" },
  );

  if (error) {
    return { ok: false, error: "Could not save your review. Please try again." };
  }

  // The tool page and any card using the aggregate need to pick up the new
  // average, so revalidate rather than trusting the client's copy.
  revalidatePath("/tools");
  return { ok: true, rating };
}

/** Deletes the signed-in user's own review. RLS makes this safe by construction. */
export async function deleteReview(toolId: string): Promise<{ ok: boolean; error?: string }> {
  if (!UUID_RE.test(toolId)) return { ok: false, error: "Invalid tool." };

  const supabase = await createAuthClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return { ok: false, error: "You need to be signed in." };

  const { error } = await supabase.from("reviews").delete().eq("tool_id", toolId).eq("user_id", user.id);

  if (error) return { ok: false, error: "Could not remove your review." };
  revalidatePath("/tools");
  return { ok: true };
}
