"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { headers } from "next/headers";
import { createAuthClient } from "@/lib/supabase/auth-server";

export type ActionState = { error?: string; success?: string } | null;

const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

async function siteOrigin() {
  const headerList = await headers();
  const host = headerList.get("host") ?? "localhost:3000";
  const proto = headerList.get("x-forwarded-proto") ?? (host.startsWith("localhost") ? "http" : "https");
  return `${proto}://${host}`;
}

/** Maps Supabase auth errors onto messages that do not leak account existence. */
function friendlyAuthError(message: string): string {
  const m = message.toLowerCase();
  if (m.includes("invalid login credentials")) return "Email or password is incorrect.";
  if (m.includes("email not confirmed")) return "Confirm your email address before signing in.";
  if (m.includes("already registered") || m.includes("already been registered"))
    return "An account with that email already exists. Try signing in instead.";
  if (m.includes("over_email_send_rate_limit") || m.includes("email rate limit"))
    return "We've hit our email sending limit for now. Please try again in about an hour, or sign in if you already have an account.";
  if (m.includes("rate limit") || m.includes("too many"))
    return "Too many attempts. Please wait a minute and try again.";
  if (m.includes("password should be")) return "Password must be at least 8 characters.";
  if (m.includes("email_address_invalid") || m.includes("unable to validate email") || m.includes("invalid email"))
    return "That email address was rejected. Please use a real, reachable address.";
  if (m.includes("password should be") || m.includes("weak password"))
    return "Password is too weak. Use at least 8 characters.";
  return "Something went wrong. Please try again.";
}

/**
 * Starts the Google OAuth flow.
 *
 * The redirect target is derived from the request host, never from client input,
 * so this cannot be used as an open redirect. `next` is only ever a same-site
 * path and is re-validated in the callback route as well.
 *
 * On success this redirects the browser to Google; the action only returns a
 * value when something went wrong.
 */
export async function signInWithGoogle(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const next = String(formData.get("next") ?? "/account");
  const safeNext = next.startsWith("/") && !next.startsWith("//") ? next : "/account";

  const supabase = await createAuthClient();
  const origin = await siteOrigin();

  const { data, error } = await supabase.auth.signInWithOAuth({
    provider: "google",
    options: {
      redirectTo: `${origin}/auth/callback?next=${encodeURIComponent(safeNext)}`,
      // Ask Google for a refresh token so long-lived sessions keep working.
      queryParams: { access_type: "offline", prompt: "consent" },
    },
  });

  if (error) {
    return { error: friendlyAuthError(error.message) };
  }

  if (!data.url) {
    return { error: "Could not start Google sign-in. Please try again." };
  }

  redirect(data.url);
}

export async function signIn(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  const password = String(formData.get("password") ?? "");
  const next = String(formData.get("next") ?? "/account");

  if (!EMAIL_RE.test(email)) return { error: "Enter a valid email address." };
  if (password.length < 1) return { error: "Enter your password." };

  const supabase = await createAuthClient();
  const { error } = await supabase.auth.signInWithPassword({ email, password });

  if (error) return { error: friendlyAuthError(error.message) };

  revalidatePath("/", "layout");
  redirect(next.startsWith("/") && !next.startsWith("//") ? next : "/account");
}

export async function signUp(_prev: ActionState, formData: FormData): Promise<ActionState> {
  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  const password = String(formData.get("password") ?? "");
  const fullName = String(formData.get("fullName") ?? "").trim();

  if (!EMAIL_RE.test(email)) return { error: "Enter a valid email address." };
  if (password.length < 8) return { error: "Password must be at least 8 characters." };
  if (fullName.length > 80) return { error: "Name is too long." };

  const supabase = await createAuthClient();
  const origin = await siteOrigin();

  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: { full_name: fullName || null },
      emailRedirectTo: `${origin}/auth/callback?next=/account`,
    },
  });

  if (error) return { error: friendlyAuthError(error.message) };

  // If email confirmation is enabled, no session is returned yet.
  if (!data.session) {
    return {
      success:
        "Check your inbox — we sent a confirmation link. Click it to activate your account.",
    };
  }

  revalidatePath("/", "layout");
  redirect("/account");
}

export async function requestPasswordReset(
  _prev: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  if (!EMAIL_RE.test(email)) return { error: "Enter a valid email address." };

  const supabase = await createAuthClient();
  const origin = await siteOrigin();

  await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: `${origin}/auth/callback?next=/account/settings`,
  });

  // Always report success so this endpoint cannot be used to enumerate accounts.
  return {
    success: "If an account exists for that address, a reset link is on its way.",
  };
}

export async function updatePassword(
  _prev: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const password = String(formData.get("password") ?? "");
  const confirm = String(formData.get("confirm") ?? "");

  if (password.length < 8) return { error: "Password must be at least 8 characters." };
  if (password !== confirm) return { error: "Passwords do not match." };

  const supabase = await createAuthClient();
  const { error } = await supabase.auth.updateUser({ password });

  if (error) return { error: friendlyAuthError(error.message) };
  return { success: "Password updated." };
}

export async function signOut() {
  const supabase = await createAuthClient();
  await supabase.auth.signOut();
  revalidatePath("/", "layout");
  redirect("/");
}

export async function updateProfile(
  _prev: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const supabase = await createAuthClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return { error: "You need to be signed in." };

  const fullName = String(formData.get("fullName") ?? "").trim();
  const username = String(formData.get("username") ?? "").trim();
  const bio = String(formData.get("bio") ?? "").trim();

  if (fullName.length > 80) return { error: "Name must be 80 characters or fewer." };
  if (bio.length > 500) return { error: "Bio must be 500 characters or fewer." };
  if (username && !/^[a-zA-Z0-9_]{3,30}$/.test(username)) {
    return { error: "Username must be 3–30 characters: letters, numbers or underscores." };
  }

  // role is deliberately not writable from the client; the DB trigger also blocks it
  const { error } = await supabase
    .from("profiles")
    .update({
      full_name: fullName || null,
      username: username || null,
      bio: bio || null,
    })
    .eq("id", user.id);

  if (error) {
    if (error.code === "23505") return { error: "That username is already taken." };
    return { error: "Could not save your profile. Please try again." };
  }

  revalidatePath("/account");
  revalidatePath("/account/settings");
  return { success: "Profile updated." };
}

export async function updatePreferences(
  _prev: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const supabase = await createAuthClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return { error: "You need to be signed in." };

  // Theme is deliberately NOT handled here. It is applied instantly on the
  // device by the theme chooser, and this form no longer submits it — writing a
  // default here would silently overwrite the user's stored choice every time
  // they saved their sort order.
  const defaultSort = String(formData.get("defaultSort") ?? "popular");
  const emailDigest = formData.get("emailDigest") === "on";
  if (!["popular", "rating", "newest", "alpha"].includes(defaultSort)) {
    return { error: "Invalid sort choice." };
  }

  const { error } = await supabase
    .from("user_preferences")
    .upsert(
      {
        user_id: user.id,
        default_sort: defaultSort,
        email_digest: emailDigest,
        updated_at: new Date().toISOString(),
      },
      { onConflict: "user_id" },
    );

  if (error) return { error: "Could not save your preferences." };

  revalidatePath("/account/settings");
  return { success: "Preferences saved." };
}

/**
 * Deletes the signed-in user's account and everything tied to it.
 *
 * Runs through the user's own session rather than an admin key: the `delete
 * own account` RLS policy permits exactly one row — their own — so this cannot
 * escalate. Favourites, reviews, history and preferences cascade from
 * `profiles.id`, which is why no separate cleanup queries are needed here.
 *
 * Replaces a mailto: link to an address that never existed. Account deletion is
 * a legal obligation under GDPR Art. 17, so leaving it as an email request was
 * not acceptable.
 */
export async function deleteAccount(
  _prev: ActionState,
  formData: FormData,
): Promise<ActionState> {
  const supabase = await createAuthClient();
  const {
    data: { user },
  } = await supabase.auth.getUser();

  if (!user) return { error: "You need to be signed in." };

  // Typed confirmation, so a stray click cannot destroy an account.
  const confirmation = String(formData.get("confirm") ?? "").trim();
  if (confirmation !== "DELETE") {
    return { error: 'Type DELETE in capitals to confirm.' };
  }

  // Deleting only the profile row would leave reviews, favourites and history
  // behind, because those cascade from auth.users rather than from profiles.
  // The RPC removes the auth.users row; everything else follows by cascade.
  const { error } = await supabase.rpc("delete_own_account");
  if (error) {
    return { error: "Could not delete your account. Please try again." };
  }

  // The profile row is gone; clear the session so the browser cannot keep using it.
  await supabase.auth.signOut();
  revalidatePath("/", "layout");
  redirect("/?deleted=1");
}
