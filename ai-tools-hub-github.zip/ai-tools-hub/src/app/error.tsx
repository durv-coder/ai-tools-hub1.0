"use client";

import Link from "next/link";
import { AlertCircle } from "@/components/icons";

export default function ErrorBoundary({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <div className="container" style={{ paddingBlock: "clamp(64px,10vw,120px)", textAlign: "center" }}>
      <p className="eyebrow" style={{ justifyContent: "center" }}>
        <AlertCircle size={13} /> Something went wrong
      </p>
      <h1 style={{ marginTop: 12, fontSize: "clamp(1.7rem,4vw,2.4rem)" }}>
        We could not load that page
      </h1>
      <p className="muted" style={{ marginTop: 12, maxWidth: "48ch", marginInline: "auto", fontSize: 15 }}>
        This is on us, not you. Try again — if it keeps happening the directory may be
        temporarily unavailable.
      </p>
      {error.digest && (
        <p className="muted" style={{ fontSize: 12, marginTop: 8, fontFamily: "monospace" }}>
          Reference: {error.digest}
        </p>
      )}
      <div className="row" style={{ justifyContent: "center", marginTop: 26, gap: 10 }}>
        <button type="button" className="btn" onClick={reset}>
          Try again
        </button>
        <Link href="/" className="btn btn--ghost">
          Go home
        </Link>
      </div>
    </div>
  );
}
