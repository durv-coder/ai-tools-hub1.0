import type { Metadata } from "next";
import Link from "next/link";

export const metadata: Metadata = {
  title: "About",
  description:
    "AI Tools Hub is a curated directory of AI tools. Here is how tools are selected and how the site is funded.",
  alternates: { canonical: "/about" },
};

export default function AboutPage() {
  return (
    <div className="container" style={{ maxWidth: 760, paddingBlock: "clamp(32px,5vw,64px)" }}>
      <span className="eyebrow">About</span>
      <h1 style={{ marginTop: 10, fontSize: "clamp(1.8rem,4vw,2.4rem)" }}>
        A directory that earns its place.
      </h1>

      <div className="prose" style={{ marginTop: 22, fontSize: 15.5 }}>
        <p>
          Most AI directories are SEO farms. They list every tool that will pay for a slot,
          describe each one in the same three sentences, and rank by whoever sponsors the page.
          That makes them useless precisely when you need them.
        </p>
        <p>
          AI Tools Hub works the other way around. Every tool in the directory is here because it
          does something well enough to recommend. Pricing is stated plainly, including what the
          free tier actually gives you, and rating counts are shown so a 5.0 from three people
          does not outrank a 4.6 from nine hundred.
        </p>
      </div>

      <hr className="rule" style={{ margin: "34px 0" }} />

      <h2 style={{ fontSize: "1.2rem" }}>How tools are selected</h2>
      <div className="prose" style={{ marginTop: 12 }}>
        <p>
          A tool gets listed when it is genuinely usable for the job in its category. We care
          about output quality, how quickly you can get a useful result, and whether the free
          tier is a real product or a demo. Tools are removed when they degrade, get acquired and
          shut down, or start hiding pricing.
        </p>
      </div>

      <h2 style={{ fontSize: "1.2rem", marginTop: 30 }}>How the site is funded</h2>
      <div className="prose" style={{ marginTop: 12 }}>
        <p>
          Outbound links are not sponsored and carry <code>nofollow</code>. If that changes, the
          change will be stated on this page before it appears anywhere else.
        </p>
      </div>

      <hr className="rule" style={{ margin: "34px 0" }} />

      <h2 style={{ fontSize: "1.2rem" }}>The stack</h2>
      <p className="muted" style={{ fontSize: 14, marginTop: 10 }}>
        Next.js with React Server Components, Supabase for Postgres and authentication, and
        row-level security on every table so the database enforces access rather than the UI.
      </p>

      <div className="row" style={{ marginTop: 28, gap: 10 }}>
        <Link href="/tools" className="btn">
          Browse the directory
        </Link>
        <Link href="/categories" className="btn btn--ghost">
          See categories
        </Link>
      </div>
    </div>
  );
}
