import type { Metadata } from "next";
import Link from "next/link";
import { getToolIndex, getToolsBySlugs } from "@/lib/queries";
import type { Tool } from "@/lib/types";
import { ComparePicker } from "@/components/compare-picker";
import { Star } from "@/components/icons";

export const metadata: Metadata = {
  title: "Compare AI tools",
  description:
    "Put AI tools side by side: pricing, licence, categories, ratings and features, without the marketing.",
  alternates: { canonical: "/compare" },
};

type SearchParams = Promise<{ tools?: string | string[] }>;

// Must be dynamic: the comparison lives entirely in `searchParams`, and a
// static render ignores them, which silently produced an always-empty page.
export const dynamic = "force-dynamic";

const MAX = 4;

/** Rows are declared once so the table cannot drift out of sync with the data. */
type Row = {
  label: string;
  render: (tool: Tool) => React.ReactNode;
};

const PRICING_LABEL: Record<Tool["pricing_model"], string> = {
  free: "Free",
  freemium: "Freemium",
  paid: "Paid",
};

const ROWS: Row[] = [
  {
    label: "What it is",
    render: (t) => <span className="compare-desc">{t.tagline}</span>,
  },
  {
    label: "Pricing",
    render: (t) => (
      <div className="compare-stack">
        <span>{PRICING_LABEL[t.pricing_model]}</span>
        {t.starting_price && <span className="muted">{t.starting_price}</span>}
      </div>
    ),
  },
  {
    label: "Rating",
    render: (t) =>
      t.rating_count > 0 ? (
        <span className="compare-rating">
          <Star size={13} filled />
          {t.rating.toFixed(1)}
          <span className="muted">({t.rating_count})</span>
        </span>
      ) : (
        <span className="muted">No reviews yet</span>
      ),
  },
  {
    label: "Open source",
    render: (t) =>
      t.is_open_source ? (
        <div className="compare-stack">
          <span>Yes{t.license ? ` · ${t.license}` : ""}</span>
          {t.repo_url && (
            <a
              href={t.repo_url}
              target="_blank"
              rel="noopener noreferrer nofollow"
              className="compare-link"
            >
              Repository
            </a>
          )}
        </div>
      ) : (
        <span className="muted">No</span>
      ),
  },
  {
    label: "Categories",
    render: (t) =>
      t.category_slugs.length > 0 ? (
        <div className="compare-tags">
          {t.category_slugs.map((slug) => (
            <Link key={slug} href={`/tools?category=${slug}`} className="chip chip--sm">
              {slug.replace(/^ai-/, "").replace(/-/g, " ")}
            </Link>
          ))}
        </div>
      ) : (
        <span className="muted">—</span>
      ),
  },
  {
    label: "Tags",
    render: (t) =>
      t.tags.length > 0 ? (
        <div className="compare-tags">
          {t.tags.slice(0, 6).map((tag) => (
            <span key={tag} className="chip chip--sm">{tag}</span>
          ))}
        </div>
      ) : (
        <span className="muted">—</span>
      ),
  },
  {
    label: "Added",
    render: (t) => (
      <span className="muted">
        {new Date(t.added_at).toLocaleDateString("en-GB", {
          month: "short",
          year: "numeric",
        })}
      </span>
    ),
  },
];

export default async function ComparePage({ searchParams }: { searchParams: SearchParams }) {
  const params = await searchParams;
  const raw = params.tools;
  // De-duplicate before slicing: `?tools=a&tools=a` otherwise rendered the same
  // tool in two columns, and a repeated slug would eat one of the four slots.
  const requested = [
    ...new Set(
      (Array.isArray(raw) ? raw : raw ? [raw] : []).filter((s) =>
        /^[a-z0-9-]{1,60}$/.test(s),
      ),
    ),
  ].slice(0, MAX);

  const [tools, index] = await Promise.all([
    requested.length > 0 ? getToolsBySlugs(requested) : Promise.resolve([]),
    getToolIndex(),
  ]);

  // PostgREST does not preserve `in()` order, so re-order to the URL's order.
  const ordered = requested
    .map((slug) => tools.find((t) => t.slug === slug))
    .filter((t): t is Tool => Boolean(t));

  const missing = requested.filter((slug) => !tools.some((t) => t.slug === slug));

  return (
    <div className="container section">
      <nav className="crumbs" aria-label="Breadcrumb">
        <Link href="/">Home</Link>
        <span className="crumbs__sep" aria-hidden="true">/</span>
        <span aria-current="page">Compare</span>
      </nav>

      <h1 style={{ fontSize: "clamp(1.7rem, 4vw, 2.4rem)", marginBottom: 10 }}>
        Compare AI tools
      </h1>
      <p className="muted measure" style={{ fontSize: 15, marginBottom: 26 }}>
        Put up to {MAX} tools side by side. Pricing, licence, categories and ratings come
        straight from the directory — no sponsored placement, and no scores we invented.
      </p>

      <ComparePicker
        all={index}
        selected={ordered.map((t) => ({ slug: t.slug, name: t.name }))}
        max={MAX}
      />

      {missing.length > 0 && (
        <p className="alert alert--error" role="alert" style={{ marginTop: 18 }}>
          Couldn&apos;t find {missing.map((m) => `“${m}”`).join(", ")}. It may have been
          renamed or unpublished.
        </p>
      )}

      {ordered.length === 0 ? (
        <div className="card compare-empty" style={{ marginTop: 26 }}>
          <p style={{ fontWeight: 600, marginBottom: 6 }}>Nothing to compare yet.</p>
          <p className="muted" style={{ fontSize: 14, marginBottom: 18 }}>
            Pick two or more tools above, or start from a suggestion.
          </p>
          <div className="compare-tags" style={{ justifyContent: "center" }}>
            <Link href="/compare?tools=chatgpt&tools=claude" className="chip">
              ChatGPT vs Claude
            </Link>
            <Link href="/compare?tools=cursor&tools=github-copilot" className="chip">
              Cursor vs GitHub Copilot
            </Link>
            <Link href="/compare?tools=ollama&tools=localai" className="chip">
              Ollama vs LocalAI
            </Link>
          </div>
        </div>
      ) : (
        <div className="compare-wrap" style={{ marginTop: 26 }}>
          <table className="compare-table">
            <caption className="sr-only">
              Side-by-side comparison of {ordered.map((t) => t.name).join(", ")}
            </caption>
            <thead>
              <tr>
                <th scope="col">
                  <span className="sr-only">Attribute</span>
                </th>
                {ordered.map((tool) => (
                  <th scope="col" key={tool.slug}>
                    <div className="compare-head">
                      <div className="tool-logo" aria-hidden="true">
                        {tool.logo_url ? (
                          // eslint-disable-next-line @next/next/no-img-element
                          <img src={tool.logo_url} alt="" width={40} height={40} loading="lazy" />
                        ) : (
                          <span className="tool-logo__initial">
                            {tool.name.slice(0, 1).toUpperCase()}
                          </span>
                        )}
                      </div>
                      <Link href={`/tools/${tool.slug}`} className="compare-name">
                        {tool.name}
                      </Link>
                      <a
                        href={tool.website_url}
                        target="_blank"
                        rel="noopener noreferrer nofollow"
                        className="compare-link"
                      >
                        Visit site
                      </a>
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {ROWS.map((row) => (
                <tr key={row.label}>
                  <th scope="row">{row.label}</th>
                  {ordered.map((tool) => (
                    <td key={tool.slug}>{row.render(tool)}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
