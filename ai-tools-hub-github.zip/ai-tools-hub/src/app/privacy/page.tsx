import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Privacy",
  description: "What AI Tools Hub stores, why, and how to get it removed.",
  alternates: { canonical: "/privacy" },
};

export default function PrivacyPage() {
  return (
    <div className="container" style={{ maxWidth: 760, paddingBlock: "clamp(32px,5vw,64px)" }}>
      <span className="eyebrow">Privacy</span>
      <h1 style={{ marginTop: 10, fontSize: "clamp(1.8rem,4vw,2.4rem)" }}>Privacy policy</h1>
      <p className="muted" style={{ marginTop: 8, fontSize: 13.5 }}>
        Last updated {new Date().toLocaleDateString("en-GB", { month: "long", year: "numeric" })}
      </p>

      <div className="prose" style={{ marginTop: 24 }}>
        <p>
          <strong>What we store.</strong> If you create an account we store your email address, a
          hashed password, and whatever display name or bio you choose to add. We also store the
          tools you save and the tool pages you open, so your account page can show them.
        </p>
        <p>
          <strong>What we do not do.</strong> We do not sell your data, run third-party ad
          trackers, or share your email with anyone. Outbound links to tool websites carry a
          referrer policy that limits what those sites learn about you.
        </p>
        <p>
          <strong>Newsletter.</strong> Subscribing stores only your email address. Every email
          includes a way to stop receiving them, and unsubscribing removes the address.
        </p>
        <p>
          <strong>Cookies.</strong> We set a session cookie when you sign in. That is the only
          cookie required for the site to work. Your theme preference is stored in your
          browser&apos;s local storage, not sent to us.
        </p>
        <p>
          <strong>Your control.</strong> You can edit or clear your profile details at any time
          from account settings, and you can request deletion of your account and all associated
          data.
        </p>
        <p>
          <strong>Where data lives.</strong> Data is stored in Supabase Postgres. Access is
          governed by row-level security policies, so one account cannot read another
          account&apos;s rows even through a crafted request.
        </p>
      </div>
    </div>
  );
}
