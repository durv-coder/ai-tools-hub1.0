import { NextResponse } from "next/server";
import { createAuthClient } from "@/lib/supabase/auth-server";

/** Messages Supabase/Google may send back; kept vague on purpose. */
function callbackError(raw: string | null): string {
  // Both the `error` code and `error_description` are passed in, because Google
  // puts the machine-readable reason in one and prose in the other.
  const d = (raw ?? "").toLowerCase();
  if (d.includes("access_denied") || d.includes("denied") || d.includes("cancel"))
    return "Google sign-in was cancelled.";
  if (d.includes("unsupported provider")) return "Google sign-in is not configured yet.";
  return "Could not sign you in with Google. Please try again.";
}

export async function GET(request: Request) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get("code");
  const next = searchParams.get("next") ?? "/account";

  // only allow same-site redirects
  const safeNext = next.startsWith("/") && !next.startsWith("//") ? next : "/account";

  // The provider can bounce back with an error instead of a code, e.g. the user
  // pressed "Cancel" on the Google consent screen.
  const providerError = [searchParams.get("error"), searchParams.get("error_description")]
    .filter(Boolean)
    .join(" ");
  if (providerError) {
    return NextResponse.redirect(`${origin}/login?error=${encodeURIComponent(callbackError(providerError))}`);
  }

  if (code) {
    const supabase = await createAuthClient();
    const { error } = await supabase.auth.exchangeCodeForSession(code);
    if (!error) {
      return NextResponse.redirect(`${origin}${safeNext}`);
    }
  }

  return NextResponse.redirect(`${origin}/login?error=${encodeURIComponent("Could not sign you in.")}`);
}
