import { ImageResponse } from "next/og";

export const alt = "AI Tools Hub — discover the best AI tools";
export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

export default async function Image() {
  return new ImageResponse(
    (
      <div
        style={{
          height: "100%",
          width: "100%",
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          background: "#ffffff",
          padding: "72px",
          fontFamily: "sans-serif",
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
          <div
            style={{
              width: 56,
              height: 56,
              borderRadius: 16,
              background: "#0a0a0a",
              color: "#fff",
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
              gap: 3,
            }}
          >
            {/* Same mark as the header: three planes plus an accent dot. */}
            <div style={{ display: "flex", width: 34, height: 5, borderRadius: 3, background: "#fbf9f6" }} />
            <div style={{ display: "flex", width: 34, height: 5, borderRadius: 3, background: "#fbf9f6", opacity: 0.55 }} />
            <div style={{ display: "flex", width: 34, height: 5, borderRadius: 3, background: "#fbf9f6", opacity: 0.28 }} />
            <div style={{ display: "flex", alignItems: "center", gap: 4, marginTop: 2 }}>
              <div style={{ display: "flex", width: 21, height: 5, borderRadius: 3, background: "#fbf9f6", opacity: 0.14 }} />
              <div style={{ display: "flex", width: 5, height: 5, borderRadius: 3, background: "#fbf9f6" }} />
            </div>
          </div>
          <div style={{ fontSize: 30, fontWeight: 600, letterSpacing: -0.8, color: "#0a0a0a" }}>
            AI Tools Hub.
          </div>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
          <div
            style={{
              fontSize: 82,
              fontWeight: 700,
              letterSpacing: -3.4,
              lineHeight: 1.04,
              color: "#0a0a0a",
              maxWidth: 940,
            }}
          >
            The best AI tools, in one honest directory.
          </div>
          <div style={{ fontSize: 30, color: "#6b6b70", maxWidth: 820 }}>
            Hand-picked entries. Licences verified. No pay-to-rank.
          </div>
        </div>

        <div style={{ display: "flex", gap: 14 }}>
          {["Chatbots", "Coding", "Image", "Video", "Audio", "Automation"].map((label) => (
            <div
              key={label}
              style={{
                fontSize: 22,
                color: "#3f3f46",
                border: "1.5px solid #e7e7e9",
                borderRadius: 999,
                padding: "10px 22px",
              }}
            >
              {label}
            </div>
          ))}
        </div>
      </div>
    ),
    size,
  );
}
