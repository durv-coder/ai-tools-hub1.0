import Link from "next/link";
import { Suspense } from "react";
import { SearchBox } from "@/components/search-box";
import { ToolCard, ToolCardSkeleton } from "@/components/tool-card";
import { NewsletterForm } from "@/components/newsletter-form";
import { CategoryIcon, ArrowRight, Sparkles } from "@/components/icons";
import {
  getCategories,
  getCategoryCounts,
  getFeaturedTools,
  getFreeTools,
  getOpenSourceTools,
  getPlatformStats,
  getPremiumTools,
  getRecentTools,
  getTrendingTools,
} from "@/lib/queries";
import { formatCount } from "@/lib/types";

// Content changes when an admin edits tools; revalidate keeps it fast and fresh.
export const revalidate = 300;

function RailSkeleton({ count = 4 }: { count?: number }) {
  return (
    <div className="tool-grid">
      {Array.from({ length: count }).map((_, i) => (
        <ToolCardSkeleton key={i} />
      ))}
    </div>
  );
}

async function TrendingRail() {
  const tools = await getTrendingTools(8);
  return (
    <div className="rail">
      {tools.map((tool) => (
        <ToolCard key={tool.id} tool={tool} />
      ))}
    </div>
  );
}

async function FeaturedRail() {
  const tools = await getFeaturedTools(6);
  return (
    <div className="tool-grid">
      {tools.map((tool) => (
        <ToolCard key={tool.id} tool={tool} />
      ))}
    </div>
  );
}

async function RecentRail() {
  const tools = await getRecentTools(6);
  return (
    <div className="tool-grid">
      {tools.map((tool) => (
        <ToolCard key={tool.id} tool={tool} />
      ))}
    </div>
  );
}

async function FreeRail() {
  const tools = await getFreeTools(8);
  return (
    <div className="tool-grid">
      {tools.map((tool) => (
        <ToolCard key={tool.id} tool={tool} />
      ))}
    </div>
  );
}

async function OpenSourceRail() {
  const tools = await getOpenSourceTools(8);
  return (
    <div className="tool-grid">
      {tools.map((tool) => (
        <ToolCard key={tool.id} tool={tool} />
      ))}
    </div>
  );
}

async function PremiumRail() {
  const tools = await getPremiumTools(8);
  return (
    <div className="tool-grid">
      {tools.map((tool) => (
        <ToolCard key={tool.id} tool={tool} />
      ))}
    </div>
  );
}

async function CategoryGrid() {
  const [categories, counts] = await Promise.all([getCategories(), getCategoryCounts()]);

  return (
    <div className="cat-grid">
      {categories.map((category) => (
        <Link
          key={category.id}
          href={`/tools?category=${category.slug}`}
          className="cat-card"
        >
          <span className="cat-card__icon">
            <CategoryIcon name={category.icon} />
          </span>
          <span className="cat-card__name">{category.name}</span>
          <span className="cat-card__count">
            {counts[category.slug] ?? 0} {(counts[category.slug] ?? 0) === 1 ? "tool" : "tools"}
          </span>
          {category.description && <span className="cat-card__desc">{category.description}</span>}
        </Link>
      ))}
    </div>
  );
}

async function Stats() {
  const stats = await getPlatformStats();

  const items = [
    { value: `${stats.tools}+`, label: "AI tools listed" },
    { value: `${stats.categories}`, label: "Categories" },
    { value: `${stats.freeTools}`, label: "With a free plan" },
    { value: `${stats.openSource}`, label: "Open source" },
  ];

  return (
    <div className="stats">
      {items.map((item) => (
        <div className="stat" key={item.label}>
          <div className="stat__value">{item.value}</div>
          <div className="stat__label">{item.label}</div>
        </div>
      ))}
    </div>
  );
}

export default function HomePage() {
  return (
    <>
      {/* ------------------------------------------------------------ hero */}
      <section className="hero">
        <div className="container hero__inner">
          <span className="badge-pill">
            <span className="badge-pill__tag">New</span>
            Hand-checked entries, licences verified at the source
          </span>

          <h1>The best AI tools, in one honest directory.</h1>

          <p className="hero__lede">
            Search {`a growing catalogue`} of AI tools across writing, coding, image, video,
            audio and automation. Hand-picked entries, licences verified at the source, no pay-to-rank.
          </p>

          <SearchBox autoFocus={false} />

          <div className="hero__tags">
            <span className="muted">Popular:</span>
            {["ChatGPT", "Cursor", "Midjourney", "ElevenLabs"].map((term) => (
              <Link key={term} href={`/tools?q=${encodeURIComponent(term)}`} className="chip">
                {term}
              </Link>
            ))}
            <Link href="/tools?openSource=1" className="chip">
              Open source
            </Link>
            <Link href="/tools" className="chip">
              Browse all <ArrowRight size={13} />
            </Link>
          </div>
        </div>
      </section>

      {/* ----------------------------------------------------------- stats */}
      <section className="container" style={{ paddingBottom: "8px" }}>
        <Suspense fallback={<div className="skeleton" style={{ height: 106, borderRadius: 16 }} />}>
          <Stats />
        </Suspense>
      </section>

      {/* ------------------------------------------------------- trending */}
      <section className="section container" id="trending">
        <div className="section-head">
          <div>
            <h2>Trending now</h2>
            <p>Notable tools worth a look this week.</p>
          </div>
          <Link href="/tools?sort=popular" className="btn btn--ghost btn--sm">
            View all <ArrowRight size={14} />
          </Link>
        </div>
        <Suspense fallback={<RailSkeleton count={4} />}>
          <TrendingRail />
        </Suspense>
      </section>

      {/* ------------------------------------------------------- featured */}
      <section className="section container" style={{ paddingTop: 0 }}>
        <div className="section-head">
          <div>
            <h2>Editor&apos;s picks</h2>
            <p>Tools we recommend first, because they are reliably good at what they claim.</p>
          </div>
        </div>
        <Suspense fallback={<RailSkeleton count={6} />}>
          <FeaturedRail />
        </Suspense>
      </section>

      {/* ----------------------------------------------------- categories */}
      <section className="section container" id="categories" style={{ paddingTop: 0 }}>
        <div className="section-head">
          <div>
            <h2>Browse by category</h2>
            <p>Twelve categories, each with a focused set of tools rather than everything at once.</p>
          </div>
          <Link href="/categories" className="btn btn--ghost btn--sm">
            All categories <ArrowRight size={14} />
          </Link>
        </div>
        <Suspense fallback={<div className="skeleton" style={{ height: 240, borderRadius: 14 }} />}>
          <CategoryGrid />
        </Suspense>
      </section>

      {/* --------------------------------------------------------- recent */}
      <section className="section container" style={{ paddingTop: 0 }}>
        <div className="section-head">
          <div>
            <h2>Recently added</h2>
            <p>The newest entries in the directory.</p>
          </div>
          <Link href="/tools?sort=newest" className="btn btn--ghost btn--sm">
            See newest <ArrowRight size={14} />
          </Link>
        </div>
        <Suspense fallback={<RailSkeleton count={6} />}>
          <RecentRail />
        </Suspense>
      </section>

      {/* ----------------------------------------------------------- free */}
      <section className="section container" style={{ paddingTop: 0 }} id="free">
        <div className="section-head">
          <div>
            <h2>Free to start</h2>
            <p>Tools with a genuinely usable free tier — not a two-week trial.</p>
          </div>
          <Link href="/tools?pricing=free" className="btn btn--ghost btn--sm">
            All free tools <ArrowRight size={14} />
          </Link>
        </div>
        <Suspense fallback={<RailSkeleton count={4} />}>
          <FreeRail />
        </Suspense>
      </section>

      {/* --------------------------------------------------- open source */}
      <section className="section container" style={{ paddingTop: 0 }} id="open-source">
        <div className="section-head">
          <div>
            <h2>Open source</h2>
            <p>
              Tools you can read, fork and run yourself. Licences are recorded per entry
              and shown on each tool page.
            </p>
          </div>
          <Link href="/tools?openSource=1" className="btn btn--ghost btn--sm">
            All open source <ArrowRight size={14} />
          </Link>
        </div>
        <Suspense fallback={<RailSkeleton count={4} />}>
          <OpenSourceRail />
        </Suspense>
      </section>

      {/* -------------------------------------------------------- premium */}
      <section className="section container" style={{ paddingTop: 0 }} id="premium">
        <div className="section-head">
          <div>
            <h2>Worth paying for</h2>
            <p>Paid tools that earn their subscription, with prices stated up front.</p>
          </div>
          <Link href="/tools?pricing=paid" className="btn btn--ghost btn--sm">
            All premium tools <ArrowRight size={14} />
          </Link>
        </div>
        <Suspense fallback={<RailSkeleton count={4} />}>
          <PremiumRail />
        </Suspense>
      </section>

      {/* ---------------------------------------------------- recommended */}
      <section className="section container" style={{ paddingTop: 0 }}>
        <div
          className="card"
          style={{ display: "grid", gap: 18, padding: "clamp(24px,4vw,40px)" }}
        >
          <span className="eyebrow">
            <Sparkles size={13} /> Recommended starting points
          </span>
          <h2 style={{ fontSize: "clamp(1.3rem,2.4vw,1.75rem)" }}>
            Not sure where to begin?
          </h2>
          <p className="muted measure" style={{ fontSize: 14.5 }}>
            Pick the job you need done and we will point you at the tools that do it
            best, without the endless comparison shopping.
          </p>
          <div className="row" style={{ gap: 8 }}>
            {[
              { label: "Write and edit", href: "/tools?category=ai-writing" },
              { label: "Ship code faster", href: "/tools?category=ai-coding" },
              { label: "Generate visuals", href: "/tools?category=ai-image" },
              { label: "Automate busywork", href: "/tools?category=ai-automation" },
            ].map((item) => (
              <Link key={item.href} href={item.href} className="chip">
                {item.label} <ArrowRight size={12} />
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* ------------------------------------------------------ newsletter */}
      <section className="container" style={{ paddingBottom: "clamp(48px,7vw,88px)" }}>
        <div className="newsletter">
          <div>
            <span className="eyebrow">Newsletter</span>
            <h2 style={{ fontSize: "clamp(1.3rem,2.4vw,1.7rem)", marginTop: 8 }}>
              One useful email a week.
            </h2>
            <p className="muted" style={{ fontSize: 14.5, marginTop: 8, maxWidth: "46ch" }}>
              New tools worth knowing about, plus what we quietly removed because it
              stopped being good. No affiliate padding.
            </p>
          </div>
          <NewsletterForm />
        </div>
      </section>
    </>
  );
}
