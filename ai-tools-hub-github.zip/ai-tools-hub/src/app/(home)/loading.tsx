/**
 * Loading skeleton, scoped deliberately.
 *
 * This file must NEVER sit at `app/loading.tsx`. A loading boundary at the root
 * wraps every route in a Suspense boundary, which makes Next stream the response.
 * Once streaming starts the HTTP status is already committed to 200, so a
 * `notFound()` raised deeper in the tree can no longer produce a 404.
 *
 * Measured in a production build: with `app/loading.tsx` present, both an
 * archived tool and an unknown slug returned HTTP 200 carrying the 404 body.
 * With it removed and the skeleton scoped here instead, both return a real 404.
 * Keep this boundary off any route that can 404 — notably `tools/[slug]`.
 */
import { ToolCardSkeleton } from "@/components/tool-card";

export default function Loading() {
  return (
    <div className="container" style={{ paddingBlock: 48 }}>
      <div className="skeleton" style={{ height: 34, width: 260, marginBottom: 14 }} />
      <div className="skeleton" style={{ height: 16, width: 420, maxWidth: "80%", marginBottom: 34 }} />
      <div className="tool-grid">
        {Array.from({ length: 6 }).map((_, i) => (
          <ToolCardSkeleton key={i} />
        ))}
      </div>
    </div>
  );
}
