import { NextResponse } from "next/server";
import { getSuggestions } from "@/lib/queries";

export const revalidate = 60;

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  const q = (searchParams.get("q") ?? "").trim();

  if (q.length < 2) return NextResponse.json([]);

  try {
    const suggestions = await getSuggestions(q, 6);
    return NextResponse.json(suggestions, {
      headers: { "Cache-Control": "public, max-age=60, stale-while-revalidate=300" },
    });
  } catch {
    // Never leak internal error detail to the client.
    return NextResponse.json([], { status: 200 });
  }
}
