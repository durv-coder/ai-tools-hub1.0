import { NextResponse } from "next/server";
import { getSupabase } from "@/lib/supabase/server";

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * One-click unsubscribe via a per-subscriber token.
 *
 * Tokens rather than emails in the URL: an unsubscribe link gets pasted into
 * emails, forwarded and logged, so it must not expose someone's address or let
 * a guess unsubscribe a stranger.
 *
 * The write goes through `public.unsubscribe_newsletter()`. The table only
 * grants INSERT to anon, so a direct UPDATE from here matched zero rows and
 * silently reported failure as success — the function keeps the token check and
 * the write together without widening the table's RLS.
 *
 * Idempotent by design: a second click reports success, because a broken
 * unsubscribe link is worse than a redundant one.
 */
export async function GET(request: Request) {
  const { searchParams, origin } = new URL(request.url);
  const token = (searchParams.get("token") ?? "").trim();

  if (!UUID_RE.test(token)) {
    return NextResponse.redirect(`${origin}/unsubscribed?status=invalid`, 303);
  }

  const { data, error } = await getSupabase().rpc("unsubscribe_newsletter", {
    token,
  });

  if (error) {
    return NextResponse.redirect(`${origin}/unsubscribed?status=error`, 303);
  }

  const status = typeof data === "string" ? data : "done";
  const safe = ["done", "already", "invalid"].includes(status) ? status : "done";
  return NextResponse.redirect(`${origin}/unsubscribed?status=${safe}`, 303);
}
