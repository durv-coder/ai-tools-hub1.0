import { NextResponse } from "next/server";
import { getSupabase } from "@/lib/supabase/server";

const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Counts a tool page view.
 *
 * Rate-limited in the database, not here: `register_tool_view()` records one row
 * per (tool, client, hour) and only increments when that row is new. Ten
 * scripted requests used to add ten views, which mattered because the "Trending
 * now" rail is ordered by view count.
 *
 * The client key is a coarse fingerprint (address + user agent), not stored
 * personal data: it is hashed, kept for at most an hour's worth of rows, and
 * never displayed. No cookies are involved.
 */
function clientKey(request: Request): string {
  const forwarded = request.headers.get("x-forwarded-for") ?? "";
  const ip = forwarded.split(",")[0].trim() || "local";
  const ua = request.headers.get("user-agent") ?? "";
  // Cheap non-cryptographic mix is enough: this is a rate limiter, not auth.
  let hash = 0;
  for (let i = 0; i < ip.length + ua.length; i += 1) {
    const ch = (ip + ua).charCodeAt(i) || 7;
    hash = (hash * 31 + ch) | 0;
  }
  return `c${(hash >>> 0).toString(36)}`;
}

export async function POST(request: Request) {
  let toolId: unknown;
  try {
    const body = await request.json();
    toolId = body?.toolId;
  } catch {
    return NextResponse.json({ ok: false }, { status: 400 });
  }

  if (typeof toolId !== "string" || !UUID_RE.test(toolId)) {
    return NextResponse.json({ ok: false }, { status: 400 });
  }

  // SECURITY DEFINER function that only increments a counter; it cannot be used
  // to read or modify anything else.
  const { data, error } = await getSupabase().rpc("register_tool_view", {
    p_tool_id: toolId,
    p_client_key: clientKey(request),
  });

  if (error) return NextResponse.json({ ok: false }, { status: 200 });

  // `counted: false` means this client already viewed the tool this hour.
  return NextResponse.json({ ok: true, counted: data === true });
}
