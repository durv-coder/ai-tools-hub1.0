"use client";

import { useEffect } from "react";

/** Records a view via a server action so the increment happens in SQL and the
 *  browser never needs write access to the tools table. */
export function ToolViewTracker({ toolId }: { toolId: string }) {
  useEffect(() => {
    const key = `ath-viewed-${toolId}`;
    try {
      // avoid inflating counts when someone reloads the same page repeatedly
      const last = Number(sessionStorage.getItem(key) ?? 0);
      if (Date.now() - last < 30 * 60 * 1000) return;
      sessionStorage.setItem(key, String(Date.now()));
    } catch {
      /* storage blocked — still record the view */
    }

    fetch("/api/view", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ toolId }),
      keepalive: true,
    }).catch(() => {
      /* a failed analytics ping must never break the page */
    });
  }, [toolId]);

  return null;
}
