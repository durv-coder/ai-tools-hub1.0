"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { Menu, X } from "@/components/icons";
import { ThemePanel } from "@/components/theme-panel";
import { BrandLockup } from "@/components/brand";

const LINKS = [
  { href: "/", label: "Home" },
  { href: "/tools", label: "Browse tools" },
  { href: "/compare", label: "Compare" },
  { href: "/tools?pricing=free", label: "Free tools" },
  { href: "/about", label: "About" },
];

export function SiteHeader() {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);

  // close the drawer whenever the route changes
  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  // lock scroll behind the drawer and allow Escape to close it
  useEffect(() => {
    if (!open) return;
    const original = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") setOpen(false);
    };
    window.addEventListener("keydown", onKey);
    return () => {
      document.body.style.overflow = original;
      window.removeEventListener("keydown", onKey);
    };
  }, [open]);

  return (
    <>
      <header className="site-header">
        <div className="container site-header__inner">
          <Link href="/" className="brand" aria-label="AI Tools Hub home">
            <BrandLockup />
          </Link>

          <nav className="nav-links" aria-label="Primary">
            {LINKS.map((link) => {
              const active =
                link.href === "/"
                  ? pathname === "/"
                  : pathname.startsWith(link.href.split("?")[0]);
              return (
                <Link
                  key={link.href}
                  href={link.href}
                  className="nav-link"
                  aria-current={active ? "page" : undefined}
                >
                  {link.label}
                </Link>
              );
            })}
          </nav>

          <div className="nav-actions">
            <ThemePanel />
            <Link href="/login" className="btn btn--sm">
              Sign in
            </Link>
            <button
              type="button"
              className="icon-btn nav-toggle"
              onClick={() => setOpen((v) => !v)}
              aria-expanded={open}
              aria-controls="mobile-nav"
              aria-label={open ? "Close menu" : "Open menu"}
            >
              {open ? <X size={18} /> : <Menu size={18} />}
            </button>
          </div>
        </div>
      </header>

      <nav
        id="mobile-nav"
        className="mobile-nav"
        data-open={open}
        aria-label="Mobile"
        aria-hidden={!open}
      >
        {LINKS.map((link) => (
          <Link key={link.href} href={link.href} tabIndex={open ? 0 : -1}>
            {link.label}
          </Link>
        ))}
        <div className="mobile-nav__divider" />
        <Link href="/login" tabIndex={open ? 0 : -1}>
          Sign in
        </Link>
      </nav>
    </>
  );
}
