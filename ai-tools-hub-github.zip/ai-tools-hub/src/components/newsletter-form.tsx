"use client";

import { useId, useState } from "react";
import { ArrowRight, Check } from "@/components/icons";

type State = "idle" | "loading" | "done" | "error";

export function NewsletterForm() {
  const id = useId();
  const [email, setEmail] = useState("");
  const [state, setState] = useState<State>("idle");
  const [message, setMessage] = useState("");

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (state === "loading") return;

    const value = email.trim();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value)) {
      setState("error");
      setMessage("Enter a valid email address.");
      return;
    }

    setState("loading");
    setMessage("");

    try {
      const res = await fetch("/api/newsletter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: value }),
      });
      const data = await res.json();

      if (!res.ok) {
        setState("error");
        setMessage(data?.error ?? "Could not subscribe right now.");
        return;
      }

      setState("done");
      setMessage(data?.already ? "You are already on the list." : "You're subscribed. See you Thursday.");
      setEmail("");
    } catch {
      setState("error");
      setMessage("Network error. Please try again.");
    }
  }

  if (state === "done") {
    return (
      <div className="alert" data-tone="success" role="status">
        <Check size={16} style={{ flexShrink: 0, marginTop: 1 }} />
        <span>{message}</span>
      </div>
    );
  }

  return (
    <form className="newsletter__form" onSubmit={onSubmit} noValidate>
      <div style={{ flex: 1, minWidth: 0 }}>
        <label htmlFor={id} className="sr-only">
          Email address
        </label>
        <input
          id={id}
          type="email"
          className="input"
          placeholder="you@company.com"
          value={email}
          onChange={(e) => {
            setEmail(e.target.value);
            if (state === "error") {
              setState("idle");
              setMessage("");
            }
          }}
          aria-invalid={state === "error"}
          aria-describedby={state === "error" ? `${id}-error` : undefined}
          autoComplete="email"
          required
        />
        {state === "error" && (
          <p className="field-error" id={`${id}-error`} role="alert">
            {message}
          </p>
        )}
      </div>
      <button type="submit" className="btn" disabled={state === "loading"}>
        {state === "loading" ? "Subscribing…" : "Subscribe"}
        {state !== "loading" && <ArrowRight size={15} />}
      </button>
    </form>
  );
}
