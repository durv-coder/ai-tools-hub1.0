/**
 * The Tools Hub brand mark: three stacked planes with an accent dot.
 *
 * Two things it has to survive, which drove the shape:
 *  - 16px in a tab: rounded bars stay distinct, where a finer illustration
 *    collapses into mush.
 *  - Both themes: it draws in `currentColor`, so it inherits whatever the
 *    surrounding tile sets rather than hard-coding black or white.
 *
 * Fill opacities rather than separate colours keep it monochrome — no hue
 * enters the design system through the logo.
 */
export function BrandMark({ size = 16 }: { size?: number }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 32 32"
      fill="none"
      aria-hidden="true"
      focusable="false"
    >
      <rect x="3" y="4" width="26" height="4.6" rx="2.3" fill="currentColor" />
      <rect x="3" y="10.75" width="26" height="4.6" rx="2.3" fill="currentColor" opacity="0.55" />
      <rect x="3" y="17.5" width="26" height="4.6" rx="2.3" fill="currentColor" opacity="0.26" />
      <rect x="3" y="25.5" width="16.5" height="4.6" rx="2.3" fill="currentColor" opacity="0.13" />
      <circle cx="24.75" cy="27.8" r="2.3" fill="currentColor" />
    </svg>
  );
}

/** The full lockup: mark tile + wordmark. Used in the header and footer. */
export function BrandLockup() {
  return (
    <>
      <span className="brand__mark" aria-hidden="true">
        <BrandMark />
      </span>
      <span>
        Tools Hub<span className="brand__dot">.</span>
      </span>
    </>
  );
}
