import Link from "next/link";
import { ChevronRight } from "@/components/icons";

type Props = {
  page: number;
  totalPages: number;
  /** base path + any existing query params, without `page` */
  buildHref: (page: number) => string;
};

/** Compact page list: first, last, current ±1, with ellipses. */
function pageItems(current: number, total: number): (number | "gap")[] {
  if (total <= 7) return Array.from({ length: total }, (_, i) => i + 1);

  const items: (number | "gap")[] = [1];
  const start = Math.max(2, current - 1);
  const end = Math.min(total - 1, current + 1);

  if (start > 2) items.push("gap");
  for (let i = start; i <= end; i++) items.push(i);
  if (end < total - 1) items.push("gap");
  items.push(total);

  return items;
}

export function Pagination({ page, totalPages, buildHref }: Props) {
  if (totalPages <= 1) return null;

  const items = pageItems(page, totalPages);

  return (
    <nav className="pagination" aria-label="Pagination">
      {page > 1 ? (
        <Link href={buildHref(page - 1)} className="page-btn" rel="prev" aria-label="Previous page">
          <ChevronRight size={14} style={{ transform: "rotate(180deg)" }} />
        </Link>
      ) : (
        <span className="page-btn" aria-disabled="true" aria-label="Previous page">
          <ChevronRight size={14} style={{ transform: "rotate(180deg)" }} />
        </span>
      )}

      {items.map((item, index) =>
        item === "gap" ? (
          <span className="page-ellipsis" key={`gap-${index}`} aria-hidden="true">
            …
          </span>
        ) : (
          <Link
            key={item}
            href={buildHref(item)}
            className="page-btn"
            aria-current={item === page ? "page" : undefined}
            aria-label={`Page ${item}`}
          >
            {item}
          </Link>
        ),
      )}

      {page < totalPages ? (
        <Link href={buildHref(page + 1)} className="page-btn" rel="next" aria-label="Next page">
          <ChevronRight size={14} />
        </Link>
      ) : (
        <span className="page-btn" aria-disabled="true" aria-label="Next page">
          <ChevronRight size={14} />
        </span>
      )}
    </nav>
  );
}
