"use client";

import Link from "next/link";
import { useState, useTransition } from "react";
import { AlertCircle, Check, Star } from "@/components/icons";
import { deleteReview, submitReview } from "@/app/actions/favorites";
import type { Review } from "@/lib/favorites";

const LABELS = ["", "Poor", "Fair", "Good", "Great", "Excellent"];

function StarPicker({ value, onChange }: { value: number; onChange: (next: number) => void }) {
  const [hover, setHover] = useState(0);
  const shown = hover || value;

  return (
    <div className="stars" role="radiogroup" aria-label="Your rating">
      {[1, 2, 3, 4, 5].map((star) => (
        <button
          key={star}
          type="button"
          role="radio"
          aria-checked={value === star}
          aria-label={`${star} star${star > 1 ? "s" : ""} — ${LABELS[star]}`}
          className="stars__btn"
          data-active={star <= shown}
          onMouseEnter={() => setHover(star)}
          onMouseLeave={() => setHover(0)}
          onFocus={() => setHover(star)}
          onBlur={() => setHover(0)}
          onClick={() => onChange(star)}
        >
          <Star size={22} filled={star <= shown} />
        </button>
      ))}
      <span className="stars__label" aria-live="polite">
        {shown ? LABELS[shown] : "Select a rating"}
      </span>
    </div>
  );
}

export function ReviewForm({
  toolId,
  own,
  signedIn,
}: {
  toolId: string;
  own: Review | null;
  signedIn: boolean;
}) {
  const [rating, setRating] = useState(own?.rating ?? 0);
  const [title, setTitle] = useState(own?.title ?? "");
  const [body, setBody] = useState(own?.body ?? "");
  const [status, setStatus] = useState<{ error?: string; success?: string } | null>(null);
  const [pending, startTransition] = useTransition();

  if (!signedIn) {
    return (
      <div className="review-signin">
        <p className="muted" style={{ fontSize: 13.5 }}>
          Sign in to rate this tool. Your review is public but your email never is.
        </p>
        <Link href="/login" className="btn btn--sm">
          Sign in to review
        </Link>
      </div>
    );
  }

  function save() {
    setStatus(null);
    if (rating === 0) {
      setStatus({ error: "Choose a star rating first." });
      return;
    }

    const data = new FormData();
    data.set("toolId", toolId);
    data.set("rating", String(rating));
    data.set("title", title);
    data.set("body", body);

    startTransition(async () => {
      const result = await submitReview(data);
      if (result.ok) {
        setStatus({ success: own ? "Your review was updated." : "Thanks — your review is live." });
      } else {
        setStatus({ error: result.error });
      }
    });
  }

  function remove() {
    startTransition(async () => {
      const result = await deleteReview(toolId);
      if (result.ok) {
        setRating(0);
        setTitle("");
        setBody("");
        setStatus({ success: "Your review was removed." });
      } else {
        setStatus({ error: result.error });
      }
    });
  }

  return (
    <div className="review-form">
      <StarPicker value={rating} onChange={setRating} />

      <div className="field">
        <label htmlFor="review-title">Headline (optional)</label>
        <input
          id="review-title"
          className="input"
          maxLength={120}
          value={title}
          onChange={(event) => setTitle(event.target.value)}
          placeholder="Sum it up in a line"
        />
      </div>

      <div className="field">
        <label htmlFor="review-body">Your review (optional)</label>
        <textarea
          id="review-body"
          className="input"
          rows={4}
          maxLength={2000}
          value={body}
          onChange={(event) => setBody(event.target.value)}
          placeholder="What did you use it for, and how did it go?"
        />
        <p className="field-hint">{body.length}/2000</p>
      </div>

      {status?.error && (
        <div className="alert" data-tone="error" role="alert">
          <AlertCircle size={15} style={{ flexShrink: 0, marginTop: 2 }} />
          <span>{status.error}</span>
        </div>
      )}
      {status?.success && (
        <div className="alert" data-tone="success" role="status">
          <Check size={15} style={{ flexShrink: 0, marginTop: 2 }} />
          <span>{status.success}</span>
        </div>
      )}

      <div className="review-form__actions">
        <button type="button" className="btn btn--sm" onClick={save} disabled={pending}>
          {pending ? "Saving…" : own ? "Update review" : "Post review"}
        </button>
        {own && (
          <button type="button" className="btn btn--ghost btn--sm" onClick={remove} disabled={pending}>
            Delete
          </button>
        )}
      </div>
    </div>
  );
}

export function ReviewList({ reviews }: { reviews: Review[] }) {
  if (reviews.length === 0) {
    return (
      <p className="muted" style={{ fontSize: 13.5 }}>
        No reviews yet. Be the first to say whether it is worth someone&apos;s time.
      </p>
    );
  }

  return (
    <ul className="review-list">
      {reviews.map((review) => (
        <li key={review.id} className="review">
          <div className="review__head">
            <span className="review__author">
              {review.author}
              {review.isOwn && <span className="review__you">You</span>}
            </span>
            <span className="review__stars" aria-label={`${review.rating} out of 5`}>
              {[1, 2, 3, 4, 5].map((star) => (
                <Star key={star} size={12} filled={star <= review.rating} />
              ))}
            </span>
            <time className="review__date" dateTime={review.created_at}>
              {new Date(review.created_at).toLocaleDateString("en-GB", {
                day: "numeric",
                month: "short",
                year: "numeric",
              })}
            </time>
          </div>
          {review.title && <p className="review__title">{review.title}</p>}
          {review.body && <p className="review__body">{review.body}</p>}
        </li>
      ))}
    </ul>
  );
}
