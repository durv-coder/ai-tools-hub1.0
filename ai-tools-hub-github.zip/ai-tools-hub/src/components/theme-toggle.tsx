"use client";

import { useRef, useState } from "react";
import { AlertCircle, Monitor, Moon, Sun, Upload, X } from "@/components/icons";
import { MODE_LABEL, PALETTES, useTheme } from "@/lib/use-theme";

/**
 * Header control. Cycles light → dark → system, so all three states are
 * reachable without visiting settings. The title and aria-label name the next
 * state as well as the current one, because an icon alone is ambiguous once
 * "system" is in the rotation.
 */
export function ThemeToggle({ compact = false }: { compact?: boolean }) {
  const { mode, resolved, mounted, cycleMode } = useTheme();

  const nextLabel: Record<typeof mode, string> = {
    light: "Switch to dark theme",
    dark: "Switch to system theme",
    system: "Switch to light theme",
  };

  const label = `${nextLabel[mode]} (currently ${MODE_LABEL[mode].toLowerCase()})`;

  const icon =
    mode === "system" ? (
      <Monitor size={16} />
    ) : resolved === "dark" ? (
      <Sun size={16} />
    ) : (
      <Moon size={16} />
    );

  if (compact) {
    return (
      <button type="button" className="icon-btn" onClick={cycleMode} aria-label={label} title={label}>
        {mounted ? icon : <Moon size={16} />}
      </button>
    );
  }

  return (
    <button type="button" className="btn btn--ghost btn--sm" onClick={cycleMode} aria-label={label} title={label}>
      {mounted ? icon : <Moon size={15} />}
      <span>{mounted ? MODE_LABEL[mode] : "Theme"}</span>
    </button>
  );
}

/**
 * Settings panel. Mode and palette are separate choices: mode is how light or
 * dark the page is, palette is its colour family. Every palette works in both
 * modes, so the two cannot conflict.
 */
export function ThemeChooser() {
  const { mode, palette, image, dim, mounted, setMode, setPalette, setImage, setDim } = useTheme();

  const fileInput = useRef<HTMLInputElement>(null);
  const [urlDraft, setUrlDraft] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [note, setNote] = useState<string | null>(null);

  /**
   * Reads the chosen file as a data URL. Images above ~1.5 MB are rejected up
   * front: base64 inflates by roughly a third and localStorage caps out around
   * 5 MB, so storing a full-size photo would throw on write.
   */
  function handleFile(file: File | undefined) {
    setError(null);
    setNote(null);
    if (!file) return;

    if (!file.type.startsWith("image/")) {
      setError("That file is not an image.");
      return;
    }
    if (file.size > 1.5 * 1024 * 1024) {
      const mb = (file.size / 1024 / 1024).toFixed(1);
      setError(`That image is ${mb} MB. Please use one under 1.5 MB, or paste an image URL instead.`);
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const result = String(reader.result ?? "");
      const outcome = setImage(result);
      if (!outcome.ok) setError(outcome.error ?? "Could not use that image.");
      else setNote("Background set.");
    };
    reader.onerror = () => setError("Could not read that file.");
    reader.readAsDataURL(file);
  }

  function useUrl() {
    setError(null);
    setNote(null);
    const outcome = setImage(urlDraft);
    if (!outcome.ok) setError(outcome.error ?? "Could not use that image.");
    else setNote("Background set.");
  }

  function clearImage() {
    setError(null);
    setNote(null);
    setImage(null);
    setUrlDraft("");
    if (fileInput.current) fileInput.current.value = "";
  }

  return (
    <div className="theme-chooser">
      <fieldset className="theme-field">
        <legend>Mode</legend>
        <div className="seg" role="radiogroup" aria-label="Theme mode">
          {(["light", "dark", "system"] as const).map((option) => (
            <button
              key={option}
              type="button"
              role="radio"
              aria-checked={mounted ? mode === option : false}
              className="seg__item"
              onClick={() => setMode(option)}
            >
              {option === "light" && <Sun size={14} />}
              {option === "dark" && <Moon size={14} />}
              {option === "system" && <Monitor size={14} />}
              {MODE_LABEL[option]}
            </button>
          ))}
        </div>
      </fieldset>

      <fieldset className="theme-field">
        <legend>Palette</legend>
        <div className="palette-grid" role="radiogroup" aria-label="Palette">
          {PALETTES.map((option) => (
            <button
              key={option.id}
              type="button"
              role="radio"
              aria-checked={mounted ? palette === option.id : false}
              className="palette-card"
              onClick={() => setPalette(option.id)}
            >
              <span className="palette-card__swatch" data-swatch={option.id} aria-hidden="true">
                <span />
                <span />
                <span />
              </span>
              <span className="palette-card__text">
                <strong>{option.label}</strong>
                <small>{option.hint}</small>
              </span>
            </button>
          ))}
        </div>
      </fieldset>

      <fieldset className="theme-field">
        <legend>Background image</legend>
        <p className="theme-hint">
          Use your own photo instead of a flat palette. It stays on this device — nothing is
          uploaded. Card surfaces turn frosted so text remains readable.
        </p>

        <div className="bg-image-controls">
          <input
            ref={fileInput}
            type="file"
            accept="image/png,image/jpeg,image/webp,image/gif,image/avif"
            className="sr-only"
            id="bg-image-file"
            onChange={(event) => handleFile(event.target.files?.[0])}
          />
          <button
            type="button"
            className="btn btn--ghost btn--sm"
            onClick={() => fileInput.current?.click()}
          >
            <Upload size={14} />
            Upload image
          </button>

          <div className="bg-image-url">
            <input
              type="url"
              className="input"
              placeholder="…or paste an https:// image URL"
              value={urlDraft}
              onChange={(event) => setUrlDraft(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === "Enter") {
                  event.preventDefault();
                  useUrl();
                }
              }}
              aria-label="Background image URL"
            />
            <button type="button" className="btn btn--ghost btn--sm" onClick={useUrl} disabled={!urlDraft.trim()}>
              Use
            </button>
          </div>

          {image && (
            <button type="button" className="btn btn--ghost btn--sm bg-image-clear" onClick={clearImage}>
              <X size={13} />
              Remove
            </button>
          )}
        </div>

        {image && (
          <div className="bg-image-preview">
            <span className="bg-image-preview__thumb" style={{ backgroundImage: `url("${image}")` }} aria-hidden="true" />
            <div className="bg-image-preview__slider">
              <label htmlFor="bg-dim">
                Dimming <output htmlFor="bg-dim">{dim}%</output>
              </label>
              <input
                id="bg-dim"
                type="range"
                min={0}
                max={90}
                step={5}
                value={dim}
                onChange={(event) => setDim(Number(event.target.value))}
              />
              <p className="theme-hint" style={{ margin: 0 }} data-warn={dim < 45}>
                {dim < 45
                  ? "Below 45% dimming, text over a busy photo can fall below accessible contrast."
                  : "Higher dimming keeps text legible over busy photos."}
              </p>
            </div>
          </div>
        )}

        {error && (
          <div className="alert" data-tone="error" role="alert" style={{ marginTop: 12 }}>
            <AlertCircle size={15} style={{ flexShrink: 0, marginTop: 2 }} />
            <span>{error}</span>
          </div>
        )}
        {note && !error && (
          <p className="theme-hint" role="status" style={{ marginTop: 10, color: "var(--ok)" }}>
            {note}
          </p>
        )}
      </fieldset>
    </div>
  );
}
