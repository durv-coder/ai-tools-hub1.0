"use client";

import Link from "next/link";
import { useCallback, useEffect, useState, useTransition } from "react";
import { Heart } from "@/components/icons";
import { useFavorites } from "@/components/favorites-provider";
import { toggleFavorite } from "@/app/actions/favorites";

const LOCAL_KEY = "ath-local-favorites";

function readLocal(): string[] {
  try {
    const raw = localStorage.getItem(LOCAL_KEY);
    const parsed = raw ? JSON.parse(raw) : [];
    return Array.isArray(parsed) ? parsed.filter((v) => typeof v === "string") : [];
  } catch {
    return [];
  }
}

function writeLocal(ids: string[]) {
  try {
    localStorage.setItem(LOCAL_KEY, JSON.stringify(ids.slice(0, 200)));
  } catch {
    /* storage blocked — signed-in users still get DB persistence */
  }
}

/**
 * Signed-in users get favourites persisted in Postgres; signed-out visitors get
 * a device-local shortlist so the button is never a dead end, and the UI says so
 * rather than pretending an account exists.
 *
 * The saved state comes from `FavoritesProvider`, which is seeded by one
 * server-side read per page. This component deliberately performs no request on
 * mount — it used to, once per card, which meant dozens of overlapping POSTs for
 * a single directory page.
 */
export function FavoriteButton({ toolId, toolName }: { toolId: string; toolName: string }) {
  const { signedIn, savedIds, setSaved } = useFavorites();
  const [localSaved, setLocalSaved] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [pending, startTransition] = useTransition();

  // Signed-out state lives in localStorage, so it can only be read on the
  // client. This is a synchronous read — no network, no server action.
  useEffect(() => {
    if (!signedIn) setLocalSaved(readLocal().includes(toolId));
  }, [signedIn, toolId]);

  const saved = signedIn ? savedIds.has(toolId) : localSaved;

  const onClick = useCallback(() => {
    if (!signedIn) {
      const next = readLocal().includes(toolId)
        ? readLocal().filter((id) => id !== toolId)
        : [...readLocal(), toolId];
      writeLocal(next);
      setLocalSaved(next.includes(toolId));
      setMessage(
        next.includes(toolId)
          ? "Saved on this device. Sign in to sync across devices."
          : "Removed from this device.",
      );
      window.setTimeout(() => setMessage(null), 3500);
      return;
    }

    startTransition(async () => {
      const before = saved;
      setSaved(toolId, !before); // optimistic

      const result = await toggleFavorite(toolId);

      if (!result.ok) {
        setSaved(toolId, before); // roll back on failure
        setMessage(result.error ?? "Could not update your favourites.");
      } else {
        setSaved(toolId, Boolean(result.saved));
        setMessage(result.saved ? "Saved to your favourites." : "Removed from your favourites.");
      }
      window.setTimeout(() => setMessage(null), 3500);
    });
  }, [signedIn, saved, setSaved, toolId]);

  const label = saved ? `Remove ${toolName} from favourites` : `Save ${toolName} to favourites`;

  return (
    <span className="fav-wrap">
      <button
        type="button"
        className="fav-btn"
        aria-pressed={saved}
        aria-label={label}
        title={label}
        onClick={onClick}
        disabled={pending}
        data-pending={pending || undefined}
      >
        <Heart size={15} filled={saved} />
      </button>

      {message && (
        <span className="fav-msg" role="status">
          {message}
          {!signedIn && message.startsWith("Saved") && (
            <>
              {" "}
              <Link href="/login">Sign in</Link>
            </>
          )}
        </span>
      )}
    </span>
  );
}
