import type { SVGProps } from "react";

type P = SVGProps<SVGSVGElement> & { size?: number };

function Base({ size = 18, children, ...rest }: P & { children: React.ReactNode }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth={1.7}
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      focusable="false"
      {...rest}
    >
      {children}
    </svg>
  );
}

export const Search = (p: P) => (
  <Base {...p}>
    <circle cx="11" cy="11" r="7" />
    <path d="m20 20-3.5-3.5" />
  </Base>
);

export const Star = ({ filled = true, ...p }: P & { filled?: boolean }) => (
  <Base {...p} strokeWidth={0} fill="none">
    <path
      d="M12 3.2l2.55 5.28 5.82.78-4.25 4.06 1.05 5.76L12 16.4l-5.17 2.68 1.05-5.76L3.63 9.26l5.82-.78L12 3.2z"
      // Filled for an active rating, outlined for an empty one.
      fill={filled ? "currentColor" : "none"}
      stroke={filled ? "none" : "currentColor"}
      strokeWidth={filled ? 0 : 1.6}
      strokeLinejoin="round"
    />
  </Base>
);

export const Heart = ({ filled = false, ...p }: P & { filled?: boolean }) => (
  <Base {...p}>
    <path
      d="M12 20s-7.2-4.35-7.2-9.3A4.3 4.3 0 0 1 12 7.6a4.3 4.3 0 0 1 7.2 3.1C19.2 15.65 12 20 12 20Z"
      // A saved favourite is a solid heart; unsaved stays an outline.
      fill={filled ? "currentColor" : "none"}
    />
  </Base>
);

export const Eye = (p: P) => (
  <Base {...p}>
    <path d="M2.5 12S6 5.8 12 5.8 21.5 12 21.5 12 18 18.2 12 18.2 2.5 12 2.5 12Z" />
    <circle cx="12" cy="12" r="2.6" />
  </Base>
);

export const ArrowRight = (p: P) => (
  <Base {...p}>
    <path d="M4 12h15" />
    <path d="m13 6 6 6-6 6" />
  </Base>
);

export const ArrowUpRight = (p: P) => (
  <Base {...p}>
    <path d="M7 17 17 7" />
    <path d="M8 7h9v9" />
  </Base>
);

export const ChevronRight = (p: P) => (
  <Base {...p}>
    <path d="m9 6 6 6-6 6" />
  </Base>
);

export const ChevronDown = (p: P) => (
  <Base {...p}>
    <path d="m6 9 6 6 6-6" />
  </Base>
);

export const X = (p: P) => (
  <Base {...p}>
    <path d="M6 6 18 18M18 6 6 18" />
  </Base>
);

export const Menu = (p: P) => (
  <Base {...p}>
    <path d="M4 7h16M4 12h16M4 17h16" />
  </Base>
);

export const Sun = (p: P) => (
  <Base {...p}>
    <circle cx="12" cy="12" r="4" />
    <path d="M12 2.5v2M12 19.5v2M2.5 12h2M19.5 12h2M5.2 5.2l1.4 1.4M17.4 17.4l1.4 1.4M18.8 5.2l-1.4 1.4M6.6 17.4l-1.4 1.4" />
  </Base>
);

export const Upload = (p: P) => (
  <Base {...p}>
    <path d="M12 15.5V3.5" />
    <path d="m7.5 8 4.5-4.5L16.5 8" />
    <path d="M3.5 15v3.5a2 2 0 0 0 2 2h13a2 2 0 0 0 2-2V15" />
  </Base>
);

export const Monitor = (p: P) => (
  <Base {...p}>
    <rect x="2.5" y="4" width="19" height="12.5" rx="2" />
    <path d="M9 20.5h6M12 16.5v4" />
  </Base>
);

export const Moon = (p: P) => (
  <Base {...p}>
    <path d="M20 14.5A8.2 8.2 0 0 1 9.5 4a8.5 8.5 0 1 0 10.5 10.5Z" />
  </Base>
);

export const Sparkles = (p: P) => (
  <Base {...p}>
    <path d="M12 3.5 13.6 8l4.5 1.6-4.5 1.6L12 15.7l-1.6-4.5L5.9 9.6 10.4 8 12 3.5Z" />
    <path d="M18.5 15.5l.7 1.9 1.9.7-1.9.7-.7 1.9-.7-1.9-1.9-.7 1.9-.7.7-1.9Z" />
  </Base>
);

export const MessageSquare = (p: P) => (
  <Base {...p}>
    <path d="M20 15a2.5 2.5 0 0 1-2.5 2.5H8L4 21V6.5A2.5 2.5 0 0 1 6.5 4h11A2.5 2.5 0 0 1 20 6.5Z" />
  </Base>
);

export const Code = (p: P) => (
  <Base {...p}>
    <path d="m8.5 8-4 4 4 4M15.5 8l4 4-4 4" />
  </Base>
);

export const ImageIcon = (p: P) => (
  <Base {...p}>
    <rect x="3.5" y="4.5" width="17" height="15" rx="2.5" />
    <circle cx="9" cy="10" r="1.6" />
    <path d="m4.5 17.5 4.2-4.2a1.6 1.6 0 0 1 2.2 0l5.6 5.6" />
  </Base>
);

export const Video = (p: P) => (
  <Base {...p}>
    <rect x="3" y="6" width="12.5" height="12" rx="2.5" />
    <path d="m15.5 13 5 3V8l-5 3z" />
  </Base>
);

export const AudioLines = (p: P) => (
  <Base {...p}>
    <path d="M4 10v4M8 7v10M12 4v16M16 8v8M20 11v2" />
  </Base>
);

export const Zap = (p: P) => (
  <Base {...p}>
    <path d="M13 2 4.5 13.5H11l-1 8.5 8.5-11.5H12l1-8.5Z" />
  </Base>
);

export const PenLine = (p: P) => (
  <Base {...p}>
    <path d="M4 20h4L19 9a2.5 2.5 0 0 0-3.5-3.5L4.5 16.5 4 20Z" />
    <path d="m14.5 6.5 3 3" />
  </Base>
);

export const Workflow = (p: P) => (
  <Base {...p}>
    <rect x="3" y="3.5" width="6.5" height="6" rx="1.8" />
    <rect x="14.5" y="14.5" width="6.5" height="6" rx="1.8" />
    <path d="M9.5 6.5h4.5a2 2 0 0 1 2 2v6" />
  </Base>
);

export const Megaphone = (p: P) => (
  <Base {...p}>
    <path d="M4 10.5v3a1.5 1.5 0 0 0 1.5 1.5H8l7 4V5.5l-7 4H5.5A1.5 1.5 0 0 0 4 10.5Z" />
    <path d="M18.5 9.5a3.5 3.5 0 0 1 0 5" />
  </Base>
);

export const Layout = (p: P) => (
  <Base {...p}>
    <rect x="3.5" y="4.5" width="17" height="15" rx="2.5" />
    <path d="M3.5 9.5h17M9.5 9.5v10" />
  </Base>
);

export const GraduationCap = (p: P) => (
  <Base {...p}>
    <path d="M12 4 2.5 8.5 12 13l9.5-4.5L12 4Z" />
    <path d="M6 10.5v4.8c0 1.5 2.7 2.7 6 2.7s6-1.2 6-2.7v-4.8" />
  </Base>
);

export const Wallet = (p: P) => (
  <Base {...p}>
    <rect x="3" y="6" width="18" height="13" rx="2.5" />
    <path d="M3 10h18M16.5 14.5h1.5" />
  </Base>
);

export const Clock = (p: P) => (
  <Base {...p}>
    <circle cx="12" cy="12" r="8.5" />
    <path d="M12 7.5V12l3 2" />
  </Base>
);

export const Sliders = (p: P) => (
  <Base {...p}>
    <path d="M4 7h9M17 7h3M4 17h3M11 17h9" />
    <circle cx="15" cy="7" r="2.2" />
    <circle cx="9" cy="17" r="2.2" />
  </Base>
);

export const Bookmark = (p: P) => (
  <Base {...p}>
    <path d="M6.5 4.5h11a1 1 0 0 1 1 1v14l-6.5-4-6.5 4v-14a1 1 0 0 1 1-1Z" />
  </Base>
);

export const User = (p: P) => (
  <Base {...p}>
    <circle cx="12" cy="8.5" r="3.7" />
    <path d="M4.8 20c.6-3.6 3.6-5.6 7.2-5.6s6.6 2 7.2 5.6" />
  </Base>
);

export const LogOut = (p: P) => (
  <Base {...p}>
    <path d="M15 4.5h3A1.5 1.5 0 0 1 19.5 6v12a1.5 1.5 0 0 1-1.5 1.5h-3" />
    <path d="M10 8.5 6.5 12l3.5 3.5M6.5 12H15" />
  </Base>
);

export const Check = (p: P) => (
  <Base {...p}>
    <path d="m4.5 12.5 5 5 10-11" />
  </Base>
);

export const AlertCircle = (p: P) => (
  <Base {...p}>
    <circle cx="12" cy="12" r="8.5" />
    <path d="M12 8v4.5M12 16h.01" />
  </Base>
);

export const Filter = (p: P) => (
  <Base {...p}>
    <path d="M3.5 6h17M6.5 12h11M10 18h4" />
  </Base>
);

/** Official Google "G" mark, drawn to Google's brand guidelines. Kept in
 *  brand colours on purpose: the sign-in guidelines require the unaltered mark. */
export const GoogleMark = ({ size = 16 }: { size?: number }) => (
  <svg width={size} height={size} viewBox="0 0 48 48" aria-hidden="true" focusable="false">
    <path
      fill="#4285F4"
      d="M45.12 24.5c0-1.56-.14-3.06-.4-4.5H24v8.51h11.84c-.51 2.75-2.06 5.08-4.39 6.64v5.52h7.11c4.16-3.83 6.56-9.47 6.56-16.17z"
    />
    <path
      fill="#34A853"
      d="M24 46c5.94 0 10.92-1.97 14.56-5.33l-7.11-5.52c-1.97 1.32-4.49 2.1-7.45 2.1-5.73 0-10.58-3.87-12.31-9.07H4.34v5.7C7.96 41.07 15.4 46 24 46z"
    />
    <path
      fill="#FBBC05"
      d="M11.69 28.18c-.44-1.32-.69-2.73-.69-4.18s.25-2.86.69-4.18v-5.7H4.34A21.99 21.99 0 0 0 2 24c0 3.55.85 6.91 2.34 9.88l7.35-5.7z"
    />
    <path
      fill="#EA4335"
      d="M24 10.75c3.23 0 6.13 1.11 8.41 3.29l6.31-6.31C34.91 4.18 29.93 2 24 2 15.4 2 7.96 6.93 4.34 14.12l7.35 5.7c1.73-5.2 6.58-9.07 12.31-9.07z"
    />
  </svg>
);

export const OpenSource = (p: P) => (
  <Base {...p}>
    <path d="m8.5 7.5-4.8 4.5 4.8 4.5" />
    <path d="m15.5 7.5 4.8 4.5-4.8 4.5" />
    <path d="m13.5 5.5-3 13" />
  </Base>
);

export const Settings = (p: P) => (
  <Base {...p}>
    <circle cx="12" cy="12" r="3" />
    <path d="M12 3v2.2M12 18.8V21M4.2 7.5l1.9 1.1M17.9 15.4l1.9 1.1M19.8 7.5l-1.9 1.1M6.1 15.4l-1.9 1.1" />
  </Base>
);

export const Server = (p: P) => (
  <Base {...p}>
    <rect x="3" y="4" width="18" height="6.5" rx="2" />
    <rect x="3" y="13.5" width="18" height="6.5" rx="2" />
    <path d="M7 7.25h.01M7 16.75h.01" />
  </Base>
);

const CATEGORY_ICONS: Record<string, (p: P) => React.JSX.Element> = {
  "message-square": MessageSquare,
  code: Code,
  image: ImageIcon,
  video: Video,
  "audio-lines": AudioLines,
  zap: Zap,
  "pen-line": PenLine,
  search: Search,
  workflow: Workflow,
  megaphone: Megaphone,
  layout: Layout,
  "graduation-cap": GraduationCap,
  server: Server,
  sparkles: Sparkles,
};

export function CategoryIcon({ name, size = 17 }: { name: string; size?: number }) {
  const Icon = CATEGORY_ICONS[name] ?? Sparkles;
  return <Icon size={size} />;
}
