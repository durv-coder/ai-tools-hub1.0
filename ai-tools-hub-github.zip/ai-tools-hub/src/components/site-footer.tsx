import Link from "next/link";
import { BrandLockup } from "@/components/brand";

const COLUMNS: { title: string; links: { href: string; label: string }[] }[] = [
  {
    title: "Browse",
    links: [
      { href: "/tools", label: "All tools" },
      { href: "/tools?trending=1", label: "Trending" },
      { href: "/tools?pricing=free", label: "Free tools" },
      { href: "/tools?pricing=paid", label: "Premium tools" },
      { href: "/compare", label: "Compare tools" },
    ],
  },
  {
    title: "Categories",
    links: [
      { href: "/categories", label: "All categories" },
      { href: "/tools?category=ai-chatbots", label: "AI Chatbots" },
      { href: "/tools?category=ai-coding", label: "AI Coding" },
      { href: "/tools?category=ai-image", label: "AI Image" },
    ],
  },
  {
    title: "Company",
    links: [
      { href: "/about", label: "About" },
      { href: "/login", label: "Sign in" },
      { href: "/signup", label: "Create account" },
      { href: "/privacy", label: "Privacy" },
    ],
  },
];

export function SiteFooter() {
  const year = new Date().getFullYear();

  return (
    <footer className="site-footer">
      <div className="container">
        <div className="footer-grid">
          <div className="footer-col">
            <Link href="/" className="brand" style={{ marginBottom: 14 }}>
              <BrandLockup />
            </Link>
            <p style={{ fontSize: 13.5, color: "var(--ink-3)", maxWidth: "34ch" }}>
              A curated directory of AI tools, with pricing, ratings and categories
              kept honest and up to date.
            </p>
          </div>

          {COLUMNS.map((column) => (
            <div className="footer-col" key={column.title}>
              <h2 className="footer-heading">{column.title}</h2>
              <ul>
                {column.links.map((link) => (
                  <li key={link.href + link.label}>
                    <Link href={link.href}>{link.label}</Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="footer-bottom">
          <span>© {year} AI Tools Hub. All rights reserved.</span>
          <span>Built with Next.js and Supabase.</span>
        </div>
      </div>
    </footer>
  );
}
