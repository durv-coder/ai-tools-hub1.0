"use client";

import { useEffect, useId, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { Search, X } from "@/components/icons";
import type { Suggestion } from "@/lib/queries";

type Props = {
  initialValue?: string;
  autoFocus?: boolean;
  /** when provided, results update in place instead of navigating */
  onChange?: (value: string) => void;
  size?: "md" | "lg";
};

export function SearchBox({ initialValue = "", autoFocus = false, onChange, size = "lg" }: Props) {
  const router = useRouter();
  const listId = useId();
  const [value, setValue] = useState(initialValue);
  const [items, setItems] = useState<Suggestion[]>([]);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState(-1);
  const [loading, setLoading] = useState(false);
  const boxRef = useRef<HTMLDivElement>(null);
  const debounce = useRef<ReturnType<typeof setTimeout> | null>(null);

  // fetch suggestions, debounced; aborts stale requests
  useEffect(() => {
    if (onChange) return; // inline mode doesn't need a dropdown

    const term = value.trim();
    if (term.length < 2) {
      setItems([]);
      setOpen(false);
      return;
    }

    setLoading(true);
    const controller = new AbortController();

    if (debounce.current) clearTimeout(debounce.current);
    debounce.current = setTimeout(async () => {
      try {
        const res = await fetch(`/api/suggestions?q=${encodeURIComponent(term)}`, {
          signal: controller.signal,
        });
        if (!res.ok) throw new Error("bad response");
        const data = (await res.json()) as Suggestion[];
        setItems(Array.isArray(data) ? data : []);
        setOpen(true);
        setActive(-1);
      } catch {
        /* aborted or transient — keep the previous list */
      } finally {
        setLoading(false);
      }
    }, 180);

    return () => {
      controller.abort();
      if (debounce.current) clearTimeout(debounce.current);
    };
  }, [value, onChange]);

  // close on outside click
  useEffect(() => {
    function onDown(e: MouseEvent) {
      if (!boxRef.current?.contains(e.target as Node)) setOpen(false);
    }
    document.addEventListener("mousedown", onDown);
    return () => document.removeEventListener("mousedown", onDown);
  }, []);

  // "/" focuses search, like most directories
  const inputRef = useRef<HTMLInputElement>(null);
  useEffect(() => {
    function onKey(e: KeyboardEvent) {
      const target = e.target as HTMLElement | null;
      const typing =
        target &&
        (target.tagName === "INPUT" ||
          target.tagName === "TEXTAREA" ||
          target.isContentEditable);
      if (e.key === "/" && !typing) {
        e.preventDefault();
        inputRef.current?.focus();
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, []);

  function submit(term: string) {
    setOpen(false);
    const q = term.trim();
    if (onChange) {
      onChange(q);
      return;
    }
    router.push(q ? `/tools?q=${encodeURIComponent(q)}` : "/tools");
  }

  function handleKeyDown(e: React.KeyboardEvent<HTMLInputElement>) {
    if (e.key === "ArrowDown" && items.length > 0) {
      e.preventDefault();
      setOpen(true);
      setActive((i) => (i + 1) % items.length);
    } else if (e.key === "ArrowUp" && items.length > 0) {
      e.preventDefault();
      setActive((i) => (i <= 0 ? items.length - 1 : i - 1));
    } else if (e.key === "Enter") {
      e.preventDefault();
      if (open && active >= 0 && items[active]) {
        setOpen(false);
        router.push(`/tools/${items[active].slug}`);
      } else {
        submit(value);
      }
    } else if (e.key === "Escape") {
      setOpen(false);
      setActive(-1);
    }
  }

  const pad = size === "lg" ? "10px 0" : "8px 0";

  return (
    <div className="search-shell" ref={boxRef}>
      <div className="search-field">
        <Search size={17} className="search-field__icon" />
        <input
          ref={inputRef}
          type="search"
          role="combobox"
          aria-expanded={open}
          aria-controls={listId}
          aria-autocomplete="list"
          aria-label="Search AI tools by name, category or use case"
          placeholder="Search AI tools…"
          autoComplete="off"
          autoFocus={autoFocus}
          value={value}
          style={{ padding: pad }}
          onChange={(e) => {
            setValue(e.target.value);
            onChange?.(e.target.value);
          }}
          onKeyDown={handleKeyDown}
          onFocus={() => items.length > 0 && setOpen(true)}
        />
        {value ? (
          <button
            type="button"
            className="icon-btn"
            style={{ width: 30, height: 30, border: 0, background: "transparent" }}
            onClick={() => {
              setValue("");
              onChange?.("");
              setItems([]);
              setOpen(false);
              inputRef.current?.focus();
            }}
            aria-label="Clear search"
          >
            <X size={15} />
          </button>
        ) : (
          <kbd className="search-field__kbd" aria-hidden="true">
            /
          </kbd>
        )}
        <button type="button" className="btn btn--sm" onClick={() => submit(value)}>
          Search
        </button>
      </div>

      {open && (
        <div className="suggestions" id={listId} role="listbox" aria-label="Suggestions">
          {loading && items.length === 0 ? (
            <div className="suggestions__empty">Searching…</div>
          ) : items.length === 0 ? (
            <div className="suggestions__empty">
              No tools match “{value.trim()}”. Press Enter to search everything.
            </div>
          ) : (
            items.map((item, i) => (
              <button
                key={item.slug}
                type="button"
                role="option"
                aria-selected={i === active}
                data-active={i === active}
                className="suggestion"
                onMouseEnter={() => setActive(i)}
                onClick={() => {
                  setOpen(false);
                  router.push(`/tools/${item.slug}`);
                }}
              >
                <Search size={14} style={{ color: "var(--ink-4)", flexShrink: 0 }} />
                <span style={{ minWidth: 0 }}>
                  <span className="suggestion__name" style={{ display: "block" }}>
                    {item.name}
                  </span>
                  <span className="suggestion__tag" style={{ display: "block" }}>
                    {item.tagline}
                  </span>
                </span>
              </button>
            ))
          )}
        </div>
      )}
    </div>
  );
}
