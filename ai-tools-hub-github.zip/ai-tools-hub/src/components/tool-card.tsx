import Link from "next/link";
import { Eye, Star, OpenSource } from "@/components/icons";
import { FavoriteButton } from "@/components/favorite-button";
import { PRICING_LABEL, formatCount, initials, type Tool } from "@/lib/types";

export function ToolCard({ tool }: { tool: Tool }) {
  const categoryLabel = tool.category_slugs[0]
    ? tool.category_slugs[0].replace(/-/g, " ").replace(/^ai /, "AI ")
    : "AI tool";

  return (
    <article className="card">
      <div className="card__top">
        <div className="tool-logo" aria-hidden="true" style={{ background: "var(--surface-2)" }}>
          {tool.logo_url ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              src={tool.logo_url}
              alt=""
              width={42}
              height={42}
              loading="lazy"
              decoding="async"
              style={{ width: "100%", height: "100%", objectFit: "cover" }}
            />
          ) : (
            initials(tool.name)
          )}
        </div>

        <div className="card__heading">
          <h3 className="card__title">
            <Link href={`/tools/${tool.slug}`}>{tool.name}</Link>
          </h3>
          <span className="card__category" style={{ textTransform: "capitalize" }}>
            {categoryLabel}
          </span>
        </div>

        <FavoriteButton toolId={tool.id} toolName={tool.name} />
      </div>

      <p className="card__desc">{tool.tagline}</p>

      <div className="card__meta">
        <span className="card__badges">
          <span className="price" data-model={tool.pricing_model}>
            {PRICING_LABEL[tool.pricing_model]}
            {tool.pricing_model !== "free" && tool.starting_price ? ` · ${tool.starting_price}` : ""}
          </span>
          {tool.is_open_source && (
            <span className="oss-badge" title={`Open source${tool.license ? ` · ${tool.license}` : ""}`}>
              <OpenSource size={11} />
              <span className="sr-only">Open source</span>
            </span>
          )}
        </span>

        <span className="card__stats">
          {tool.rating_count > 0 && (
            <span className="meta-item" aria-label={`Rated ${tool.rating} out of 5`}>
              <Star size={13} />
              <span>{tool.rating.toFixed(1)}</span>
            </span>
          )}
          <span className="meta-item" aria-label={`${tool.view_count} views`}>
            <Eye size={13} />
            <span>{formatCount(tool.view_count)}</span>
          </span>
        </span>
      </div>
    </article>
  );
}

export function ToolCardSkeleton() {
  return (
    <div className="skeleton-card" aria-hidden="true">
      <div style={{ display: "flex", gap: 12 }}>
        <div className="skeleton" style={{ width: 42, height: 42, borderRadius: 11 }} />
        <div style={{ flex: 1, display: "grid", gap: 7 }}>
          <div className="skeleton" style={{ height: 13, width: "55%" }} />
          <div className="skeleton" style={{ height: 10, width: "35%" }} />
        </div>
      </div>
      <div className="skeleton" style={{ height: 11, width: "100%" }} />
      <div className="skeleton" style={{ height: 11, width: "82%" }} />
      <div className="skeleton" style={{ height: 11, width: "40%", marginTop: 6 }} />
    </div>
  );
}
