"use client";

import { LogOut } from "@/components/icons";

export function SignOutButton() {
  return (
    <form action="/api/signout" method="post">
      <button type="submit" className="btn btn--ghost btn--sm">
        <LogOut size={14} /> Sign out
      </button>
    </form>
  );
}
