"use client";

import { useRouter, useSearchParams } from "next/navigation";
import { useCallback, useState, useTransition } from "react";
import { X, Sliders, ChevronDown, OpenSource } from "@/components/icons";
import type { Category } from "@/lib/types";
import { SORT_OPTIONS, PRICING_LABEL, type PricingModel } from "@/lib/types";

type Props = {
  categories: Category[];
  counts: Record<string, number>;
  totalTools: number;
};

const PRICING_CHOICES: (PricingModel | "all")[] = ["all", "free", "freemium", "paid"];

export function DirectoryFilters({ categories, counts, totalTools }: Props) {
  const router = useRouter();
  const params = useSearchParams();
  const [pending, startTransition] = useTransition();
  // Collapsed by default on small screens so results are not pushed off-screen.
  const [mobileOpen, setMobileOpen] = useState(false);

  const activeCategories = params.getAll("category");
  const activePricing = (params.get("pricing") ?? "all") as PricingModel | "all";
  const activeSort = params.get("sort") ?? "popular";
  const search = params.get("q") ?? "";
  const openSourceOnly = params.get("openSource") === "1";

  const push = useCallback(
    (mutate: (next: URLSearchParams) => void) => {
      const next = new URLSearchParams(params.toString());
      mutate(next);
      next.delete("page"); // any filter change resets pagination
      startTransition(() => {
        router.push(`/tools${next.toString() ? `?${next}` : ""}`, { scroll: false });
      });
    },
    [params, router],
  );

  function toggleCategory(slug: string) {
    push((next) => {
      const current = next.getAll("category");
      next.delete("category");
      const updated = current.includes(slug)
        ? current.filter((s) => s !== slug)
        : [...current, slug];
      updated.forEach((s) => next.append("category", s));
    });
  }

  function setPricing(value: PricingModel | "all") {
    push((next) => {
      if (value === "all") next.delete("pricing");
      else next.set("pricing", value);
    });
  }

  function setOpenSource(value: boolean) {
    push((next) => {
      if (value) next.set("openSource", "1");
      else next.delete("openSource");
    });
  }

  function clearAll() {
    startTransition(() => router.push("/tools", { scroll: false }));
  }

  const hasFilters =
    activeCategories.length > 0 ||
    activePricing !== "all" ||
    activeSort !== "popular" ||
    openSourceOnly ||
    Boolean(search);

  return (
    <>
      <button
        type="button"
        className="filters-toggle btn btn--ghost"
        onClick={() => setMobileOpen((v) => !v)}
        aria-expanded={mobileOpen}
        aria-controls="filter-panel"
      >
        <Sliders size={15} />
        Filters
        {activeCategories.length + (activePricing !== "all" ? 1 : 0) > 0 && (
          <span className="filters-toggle__count">
            {activeCategories.length + (activePricing !== "all" ? 1 : 0)}
          </span>
        )}
        <ChevronDown
          size={14}
          style={{ marginLeft: "auto", transform: mobileOpen ? "rotate(180deg)" : "none", transition: "transform 200ms" }}
        />
      </button>

      <aside
        className="filters"
        id="filter-panel"
        data-open={mobileOpen}
        aria-label="Filter tools"
        aria-busy={pending}
      >
        <div className="filter-group">
          <h3>
            <Sliders size={12} style={{ display: "inline", marginRight: 6, verticalAlign: -1 }} />
            Category
          </h3>
          <div className="filter-list filter-list--categories">
            <button
              type="button"
              className="filter-option"
              aria-pressed={activeCategories.length === 0}
              onClick={() =>
                push((next) => {
                  next.delete("category");
                })
              }
            >
              <span>All categories</span>
              <span className="filter-option__count">{totalTools}</span>
            </button>

            {categories.map((category) => {
              const count = counts[category.slug] ?? 0;
              const pressed = activeCategories.includes(category.slug);
              return (
                <button
                  key={category.id}
                  type="button"
                  className="filter-option"
                  aria-pressed={pressed}
                  onClick={() => toggleCategory(category.slug)}
                >
                  <span>{category.name}</span>
                  <span className="filter-option__count">{count}</span>
                </button>
              );
            })}
          </div>
        </div>

        <div className="filter-group">
          <h3>Pricing</h3>
          <div className="filter-list">
            {PRICING_CHOICES.map((choice) => (
              <button
                key={choice}
                type="button"
                className="filter-option"
                aria-pressed={activePricing === choice}
                onClick={() => setPricing(choice)}
              >
                <span>{choice === "all" ? "All pricing" : PRICING_LABEL[choice]}</span>
              </button>
            ))}
          </div>
        </div>

        <div className="filter-group">
          <h3>Licence</h3>
          <div className="filter-list">
            <button
              type="button"
              className="filter-option"
              aria-pressed={openSourceOnly}
              onClick={() => setOpenSource(!openSourceOnly)}
            >
              <span>Open source only</span>
              <span className="filter-option__count">
                <OpenSource size={12} />
              </span>
            </button>
          </div>
        </div>

        {hasFilters && (
          <button type="button" className="btn btn--ghost btn--sm" onClick={clearAll}>
            <X size={14} /> Clear all filters
          </button>
        )}
      </aside>
    </>
  );
}

/** Sort control + result count, rendered above the grid. */
export function DirectoryToolbar({
  total,
  showing,
  categories,
}: {
  total: number;
  showing: number;
  categories: Category[];
}) {
  const router = useRouter();
  const params = useSearchParams();
  const [, startTransition] = useTransition();

  const activeSort = params.get("sort") ?? "popular";
  const activeCategories = params.getAll("category");
  const activePricing = params.get("pricing");
  const search = params.get("q");

  function setSort(value: string) {
    const next = new URLSearchParams(params.toString());
    if (value === "popular") next.delete("sort");
    else next.set("sort", value);
    next.delete("page");
    startTransition(() => router.push(`/tools?${next}`, { scroll: false }));
  }

  function removeParam(key: string, value?: string) {
    const next = new URLSearchParams(params.toString());
    if (value && key === "category") {
      const remaining = next.getAll("category").filter((v) => v !== value);
      next.delete("category");
      remaining.forEach((v) => next.append("category", v));
    } else {
      next.delete(key);
    }
    next.delete("page");
    startTransition(() => router.push(`/tools?${next}`, { scroll: false }));
  }

  const categoryName = (slug: string) =>
    categories.find((c) => c.slug === slug)?.name ?? slug;

  const chips: { key: string; value?: string; label: string }[] = [
    ...(search ? [{ key: "q", label: `“${search}”` }] : []),
    ...activeCategories.map((slug) => ({
      key: "category",
      value: slug,
      label: categoryName(slug),
    })),
    ...(params.get("openSource") === "1"
      ? [{ key: "openSource", label: "Open source" }]
      : []),
    ...(activePricing
      ? [
          {
            key: "pricing",
            label: PRICING_LABEL[activePricing as PricingModel] ?? activePricing,
          },
        ]
      : []),
  ];

  return (
    <div>
      {chips.length > 0 && (
        <div className="active-filters">
          {chips.map((chip) => (
            <span className="filter-tag" key={chip.key + (chip.value ?? "")}>
              {chip.label}
              <button
                type="button"
                onClick={() => removeParam(chip.key, chip.value)}
                aria-label={`Remove ${chip.label} filter`}
              >
                <X size={11} />
              </button>
            </span>
          ))}
        </div>
      )}

      <div className="toolbar">
        <p className="toolbar__count">
          {total === 0
            ? "No tools found"
            : `Showing ${showing} of ${total} ${total === 1 ? "tool" : "tools"}`}
        </p>

        <label className="row" style={{ gap: 8, fontSize: 13, color: "var(--ink-3)" }}>
          <span>Sort</span>
          <select
            className="select"
            value={activeSort}
            onChange={(e) => setSort(e.target.value)}
            aria-label="Sort tools by"
          >
            {SORT_OPTIONS.map((option) => (
              <option key={option.key} value={option.key}>
                {option.label}
              </option>
            ))}
          </select>
        </label>
      </div>
    </div>
  );
}
