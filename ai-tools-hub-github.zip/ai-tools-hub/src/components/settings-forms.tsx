"use client";

import { useActionState, useState } from "react";
import { useFormStatus } from "react-dom";
import { AlertCircle, Check } from "@/components/icons";
import type { ActionState } from "@/app/actions/auth";
import { deleteAccount, updatePassword, updatePreferences, updateProfile } from "@/app/actions/auth";

function Submit({ label }: { label: string }) {
  const { pending } = useFormStatus();
  return (
    <button type="submit" className="btn" disabled={pending}>
      {pending ? "Saving…" : label}
    </button>
  );
}

function Feedback({ state }: { state: ActionState }) {
  if (!state?.error && !state?.success) return null;
  return (
    <div className="alert" data-tone={state.error ? "error" : "success"} role="status">
      {state.error ? (
        <AlertCircle size={15} style={{ flexShrink: 0, marginTop: 2 }} />
      ) : (
        <Check size={15} style={{ flexShrink: 0, marginTop: 2 }} />
      )}
      <span>{state.error ?? state.success}</span>
    </div>
  );
}

export function ProfileForm({
  fullName,
  username,
  bio,
  email,
}: {
  fullName: string;
  username: string;
  bio: string;
  email: string;
}) {
  const [state, action] = useActionState<ActionState, FormData>(updateProfile, null);

  return (
    <form className="auth-form" action={action} noValidate>
      <Feedback state={state} />

      <div className="field">
        <label htmlFor="account-email">Email</label>
        <input
          id="account-email"
          type="email"
          className="input"
          value={email}
          readOnly
          disabled
          aria-describedby="email-hint"
        />
        <p className="field-hint" id="email-hint">
          Email changes are handled through account recovery for security.
        </p>
      </div>

      <div className="field">
        <label htmlFor="full-name">Display name</label>
        <input
          id="full-name"
          name="fullName"
          type="text"
          className="input"
          defaultValue={fullName}
          maxLength={80}
          placeholder="Your name"
        />
      </div>

      <div className="field">
        <label htmlFor="username">Username</label>
        <input
          id="username"
          name="username"
          type="text"
          className="input"
          defaultValue={username}
          maxLength={30}
          pattern="[a-zA-Z0-9_]{3,30}"
          placeholder="letters_numbers_only"
          aria-describedby="username-hint"
        />
        <p className="field-hint" id="username-hint">
          3–30 characters. Letters, numbers and underscores.
        </p>
      </div>

      <div className="field">
        <label htmlFor="bio">Short bio</label>
        <textarea
          id="bio"
          name="bio"
          className="input"
          defaultValue={bio}
          maxLength={500}
          rows={3}
          placeholder="A sentence about what you build."
          style={{ borderRadius: "var(--r-md)", resize: "vertical" }}
        />
      </div>

      <div>
        <Submit label="Save profile" />
      </div>
    </form>
  );
}

export function PasswordForm() {
  const [state, action] = useActionState<ActionState, FormData>(updatePassword, null);

  return (
    <form className="auth-form" action={action} noValidate>
      <Feedback state={state} />

      <div className="field">
        <label htmlFor="settings-password">New password</label>
        <input
          id="settings-password"
          name="password"
          type="password"
          className="input"
          autoComplete="new-password"
          required
          minLength={8}
        />
      </div>

      <div className="field">
        <label htmlFor="settings-confirm">Confirm new password</label>
        <input
          id="settings-confirm"
          name="confirm"
          type="password"
          className="input"
          autoComplete="new-password"
          required
          minLength={8}
        />
      </div>

      <div>
        <Submit label="Update password" />
      </div>
    </form>
  );
}

export function PreferencesForm({
  defaultSort,
  emailDigest,
}: {
  defaultSort: string;
  emailDigest: boolean;
}) {
  const [state, action] = useActionState<ActionState, FormData>(updatePreferences, null);

  return (
    <form className="auth-form" action={action} noValidate>
      <Feedback state={state} />

      <div className="field">
        <label htmlFor="default-sort">Default sort order</label>
        <select
          id="default-sort"
          name="defaultSort"
          className="select"
          defaultValue={defaultSort}
          style={{ width: "100%" }}
        >
          <option value="popular">Most popular</option>
          <option value="rating">Highest rated</option>
          <option value="newest">Newest</option>
          <option value="alpha">A–Z</option>
        </select>
      </div>

      <label className="row" style={{ gap: 9, fontSize: 13.5, cursor: "pointer" }}>
        <input
          type="checkbox"
          name="emailDigest"
          defaultChecked={emailDigest}
          style={{ width: 16, height: 16, accentColor: "var(--ink)" }}
        />
        <span>Send me the weekly digest email</span>
      </label>

      <div>
        <Submit label="Save preferences" />
      </div>
    </form>
  );
}

/**
 * Account deletion. Deliberately two-step: the field must contain DELETE in
 * capitals, and the button stays disabled until it does. Deletion is
 * irreversible, so an accidental tap must not be enough.
 */
function ConfirmDeleteButton({ enabled }: { enabled: boolean }) {
  // useFormStatus only reports inside a child of the <form>, so the button is
  // its own component rather than inline in DeleteAccountForm.
  const { pending } = useFormStatus();
  return (
    <button
      type="submit"
      className="btn btn--ghost btn--sm"
      disabled={!enabled || pending}
      style={{
        color: "var(--danger)",
        borderColor: "var(--line-strong)",
        alignSelf: "flex-start",
      }}
    >
      {pending ? "Deleting…" : "Permanently delete my account"}
    </button>
  );
}

export function DeleteAccountForm() {
  const [state, action] = useActionState<ActionState, FormData>(deleteAccount, null);
  const [typed, setTyped] = useState("");

  return (
    <form action={action} className="stack" style={{ gap: 12 }}>
      <label htmlFor="confirm-delete" className="field__label">
        Type <strong>DELETE</strong> to confirm
      </label>
      <input
        id="confirm-delete"
        name="confirm"
        className="input"
        autoComplete="off"
        spellCheck={false}
        value={typed}
        onChange={(e) => setTyped(e.target.value)}
        aria-describedby="confirm-delete-hint"
      />
      <p id="confirm-delete-hint" className="muted" style={{ fontSize: 12.5 }}>
        Your profile, saved tools, reviews and viewing history are removed permanently.
      </p>

      {state?.error && (
        <p className="alert alert--error" role="alert">
          <AlertCircle size={15} /> {state.error}
        </p>
      )}

      <ConfirmDeleteButton enabled={typed === "DELETE"} />
    </form>
  );
}
