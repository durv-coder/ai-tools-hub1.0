"use client";

import { useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";

type Entry = { slug: string; name: string };

/**
 * Adds and removes tools from the comparison.
 *
 * State lives in the URL (`?tools=a&tools=b`) rather than in React, so a
 * comparison can be bookmarked, shared or reloaded without losing anything.
 * The page itself stays a Server Component and does the database reads.
 */
export function ComparePicker({
  all,
  selected,
  max,
}: {
  all: Entry[];
  selected: Entry[];
  max: number;
}) {
  const router = useRouter();
  const [query, setQuery] = useState("");
  const inputRef = useRef<HTMLInputElement>(null);

  const chosen = useMemo(() => new Set(selected.map((s) => s.slug)), [selected]);

  const matches = useMemo(() => {
    const term = query.trim().toLowerCase();
    if (!term) return [];
    return all
      .filter((t) => !chosen.has(t.slug))
      .filter((t) => t.name.toLowerCase().includes(term) || t.slug.includes(term))
      .slice(0, 6);
  }, [all, chosen, query]);

  const atLimit = selected.length >= max;

  function commit(next: string[]) {
    const sp = new URLSearchParams();
    next.forEach((slug) => sp.append("tools", slug));
    router.push(`/compare${next.length ? `?${sp.toString()}` : ""}`, { scroll: false });
  }

  function add(slug: string) {
    const current = selected.map((s) => s.slug);
    if (current.includes(slug) || atLimit) return;
    commit([...current, slug]);
    setQuery("");
    inputRef.current?.focus();
  }

  function remove(slug: string) {
    commit(selected.map((s) => s.slug).filter((s) => s !== slug));
  }

  return (
    <div className="compare-picker">
      <div className="compare-chosen">
        {selected.map((tool) => (
          <span key={tool.slug} className="compare-pill">
            {tool.name}
            <button
              type="button"
              onClick={() => remove(tool.slug)}
              aria-label={`Remove ${tool.name} from the comparison`}
              className="compare-pill__x"
            >
              ×
            </button>
          </span>
        ))}
        {selected.length === 0 && (
          <span className="muted" style={{ fontSize: 13.5 }}>
            No tools selected yet.
          </span>
        )}
      </div>

      {atLimit ? (
        <p className="muted" style={{ fontSize: 13 }}>
          That&apos;s {max} — remove one to add another.
        </p>
      ) : (
        <div className="compare-search">
          <label htmlFor="compare-input" className="sr-only">
            Search for a tool to compare
          </label>
          <input
            id="compare-input"
            ref={inputRef}
            type="search"
            className="input"
            placeholder="Add a tool by name…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && matches.length > 0) {
                e.preventDefault();
                add(matches[0].slug);
              }
            }}
            autoComplete="off"
          />

          {matches.length > 0 && (
            <ul className="compare-suggest" role="listbox" aria-label="Matching tools">
              {matches.map((m) => (
                <li key={m.slug}>
                  <button type="button" onClick={() => add(m.slug)} role="option" aria-selected={false}>
                    {m.name}
                  </button>
                </li>
              ))}
            </ul>
          )}

          {query.trim() && matches.length === 0 && (
            <p className="muted" style={{ fontSize: 12.5, marginTop: 6 }}>
              No tool matches “{query.trim()}”.{" "}
              {chosen.size > 0 && "It may already be in the comparison."}
            </p>
          )}
        </div>
      )}

      {selected.length > 0 && (
        <Link href="/compare" className="compare-clear">
          Clear all
        </Link>
      )}
    </div>
  );
}
