"use client";

import { useEffect, useRef, useState } from "react";
import { Monitor, Moon, Sun, X } from "@/components/icons";
import { MODE_LABEL, PALETTES, useTheme } from "@/lib/use-theme";

/**
 * Public appearance panel, opened from the header.
 *
 * Deliberately not behind the login wall: picking a colour scheme is a display
 * preference, not an account feature, so a signed-out visitor must be able to
 * reach it. The settings page renders the same controls for people who are
 * signed in and looking for them there.
 */
export function ThemePanel() {
  const { mode, palette, image, dim, mounted, setMode, setPalette, setImage, setDim } = useTheme();
  const [open, setOpen] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [urlDraft, setUrlDraft] = useState("");
  const panelRef = useRef<HTMLDivElement>(null);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const fileInput = useRef<HTMLInputElement>(null);

  // Escape to close, and restore focus to the trigger so keyboard users are
  // not dropped back at the top of the document.
  useEffect(() => {
    if (!open) return;
    function onKeyDown(event: KeyboardEvent) {
      if (event.key === "Escape") {
        setOpen(false);
        triggerRef.current?.focus();
      }
    }
    function onPointerDown(event: PointerEvent) {
      if (
        panelRef.current &&
        !panelRef.current.contains(event.target as Node) &&
        !triggerRef.current?.contains(event.target as Node)
      ) {
        setOpen(false);
      }
    }
    document.addEventListener("keydown", onKeyDown);
    document.addEventListener("pointerdown", onPointerDown);
    return () => {
      document.removeEventListener("keydown", onKeyDown);
      document.removeEventListener("pointerdown", onPointerDown);
    };
  }, [open]);

  function handleFile(file: File | undefined) {
    setError(null);
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      setError("That file is not an image.");
      return;
    }
    if (file.size > 1.5 * 1024 * 1024) {
      setError(`That image is ${(file.size / 1024 / 1024).toFixed(1)} MB. Use one under 1.5 MB.`);
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const outcome = setImage(String(reader.result ?? ""));
      if (!outcome.ok) setError(outcome.error ?? "Could not use that image.");
    };
    reader.onerror = () => setError("Could not read that file.");
    reader.readAsDataURL(file);
  }

  const icon = mode === "system" ? <Monitor size={16} /> : mode === "dark" ? <Sun size={16} /> : <Moon size={16} />;

  return (
    <div className="theme-panel-wrap">
      <button
        ref={triggerRef}
        type="button"
        className="icon-btn"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        aria-controls="theme-panel"
        aria-label="Change appearance"
        title="Change appearance"
      >
        {mounted ? icon : <Moon size={16} />}
      </button>

      {open && (
        <div
          className="theme-panel"
          id="theme-panel"
          ref={panelRef}
          role="dialog"
          aria-label="Appearance"
        >
          <div className="theme-panel__head">
            <strong>Appearance</strong>
            <button
              type="button"
              className="icon-btn icon-btn--sm"
              onClick={() => {
                setOpen(false);
                triggerRef.current?.focus();
              }}
              aria-label="Close appearance panel"
            >
              <X size={14} />
            </button>
          </div>

          <div className="seg seg--full" role="radiogroup" aria-label="Theme mode">
            {(["light", "dark", "system"] as const).map((option) => (
              <button
                key={option}
                type="button"
                role="radio"
                aria-checked={mounted ? mode === option : false}
                className="seg__item"
                onClick={() => setMode(option)}
              >
                {option === "light" && <Sun size={14} />}
                {option === "dark" && <Moon size={14} />}
                {option === "system" && <Monitor size={14} />}
                {MODE_LABEL[option]}
              </button>
            ))}
          </div>

          <div className="palette-grid" role="radiogroup" aria-label="Palette">
            {PALETTES.map((option) => (
              <button
                key={option.id}
                type="button"
                role="radio"
                aria-checked={mounted ? palette === option.id : false}
                className="palette-card palette-card--compact"
                onClick={() => setPalette(option.id)}
                title={option.hint}
              >
                <span className="palette-card__swatch" data-swatch={option.id} aria-hidden="true">
                  <span />
                  <span />
                  <span />
                </span>
                <span className="palette-card__text">
                  <strong>{option.label}</strong>
                </span>
              </button>
            ))}
          </div>

          {palette === "image" && (
            <div className="theme-panel__image">
              <div className="bg-image-controls">
                <input
                  ref={fileInput}
                  type="file"
                  accept="image/png,image/jpeg,image/webp,image/gif,image/avif"
                  className="sr-only"
                  id="theme-panel-file"
                  onChange={(event) => handleFile(event.target.files?.[0])}
                />
                <button type="button" className="btn btn--ghost btn--sm" onClick={() => fileInput.current?.click()}>
                  Upload image
                </button>
                {image && (
                  <button type="button" className="btn btn--ghost btn--sm bg-image-clear" onClick={() => setImage(null)}>
                    Remove
                  </button>
                )}
              </div>

              <div className="bg-image-url">
                <input
                  type="url"
                  className="input"
                  placeholder="Paste an https:// image URL"
                  value={urlDraft}
                  onChange={(event) => setUrlDraft(event.target.value)}
                  onKeyDown={(event) => {
                    if (event.key === "Enter") {
                      event.preventDefault();
                      const outcome = setImage(urlDraft);
                      if (!outcome.ok) setError(outcome.error ?? "Could not use that image.");
                      else setError(null);
                    }
                  }}
                  aria-label="Background image URL"
                />
              </div>

              {image && (
                <label className="theme-panel__dim" htmlFor="theme-panel-dim">
                  <span>
                    Dimming <output htmlFor="theme-panel-dim">{dim}%</output>
                  </span>
                  <input
                    id="theme-panel-dim"
                    type="range"
                    min={0}
                    max={90}
                    step={5}
                    value={dim}
                    onChange={(event) => setDim(Number(event.target.value))}
                  />
                </label>
              )}

              {error && (
                <p className="theme-panel__error" role="alert">
                  {error}
                </p>
              )}
            </div>
          )}

          <p className="theme-panel__foot">Saved on this device.</p>
        </div>
      )}
    </div>
  );
}
