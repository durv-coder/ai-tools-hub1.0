"use client";

import Link from "next/link";
import { useActionState } from "react";
import { useFormStatus } from "react-dom";
import { AlertCircle, Check, GoogleMark } from "@/components/icons";
import type { ActionState } from "@/app/actions/auth";

type Action = (state: ActionState, formData: FormData) => Promise<ActionState>;

function SubmitButton({ label, pendingLabel }: { label: string; pendingLabel: string }) {
  const { pending } = useFormStatus();
  return (
    <button type="submit" className="btn btn--block btn--lg" disabled={pending}>
      {pending ? pendingLabel : label}
    </button>
  );
}

function Feedback({ state }: { state: ActionState }) {
  if (!state?.error && !state?.success) return null;

  if (state.error) {
    return (
      <div className="alert" data-tone="error" role="alert">
        <AlertCircle size={15} style={{ flexShrink: 0, marginTop: 2 }} />
        <span>{state.error}</span>
      </div>
    );
  }

  return (
    <div className="alert" data-tone="success" role="status">
      <Check size={15} style={{ flexShrink: 0, marginTop: 2 }} />
      <span>{state.success}</span>
    </div>
  );
}

/**
 * Google sign-in. Rendered only when the provider is configured on the Supabase
 * project (see `isGoogleEnabled`), so it is never a button that leads nowhere.
 * The action redirects to Google; if it returns at all, something went wrong.
 */
function GoogleSubmitButton({ label }: { label: string }) {
  // Must live inside the <form>: useFormStatus reads the nearest parent form.
  const { pending } = useFormStatus();
  return (
    <button type="submit" className="btn btn--ghost btn--block btn--lg oauth__btn" disabled={pending}>
      <GoogleMark size={17} />
      {pending ? "Redirecting to Google…" : label}
    </button>
  );
}

export function GoogleSignIn({ next, label }: { next: string; label: string }) {
  const [state, action] = useActionState<ActionState, FormData>(
    async (prev, formData) => {
      const { signInWithGoogle } = await import("@/app/actions/auth");
      return signInWithGoogle(prev, formData);
    },
    null,
  );

  return (
    <div className="oauth">
      <form action={action}>
        <input type="hidden" name="next" value={next} />
        <GoogleSubmitButton label={label} />
      </form>
      {state?.error && (
        <div className="alert" data-tone="error" role="alert">
          <AlertCircle size={15} style={{ flexShrink: 0, marginTop: 2 }} />
          <span>{state.error}</span>
        </div>
      )}
      <div className="auth-divider" role="separator" aria-label="or">
        <span>or</span>
      </div>
    </div>
  );
}

export function LoginForm({ next }: { next: string }) {
  const [state, action] = useActionState<ActionState, FormData>(
    async (prev, formData) => {
      const { signIn } = await import("@/app/actions/auth");
      return signIn(prev, formData);
    },
    null,
  );

  return (
    <form className="auth-form" action={action} noValidate>
      <Feedback state={state} />
      <input type="hidden" name="next" value={next} />

      <div className="field">
        <label htmlFor="login-email">Email</label>
        <input
          id="login-email"
          name="email"
          type="email"
          className="input"
          autoComplete="email"
          required
          placeholder="you@company.com"
        />
      </div>

      <div className="field">
        <div className="row-between">
          <label htmlFor="login-password">Password</label>
          <Link
            href="/reset-password"
            style={{ fontSize: 12.5, color: "var(--ink-3)", textDecoration: "underline", textUnderlineOffset: 3 }}
          >
            Forgot password?
          </Link>
        </div>
        <input
          id="login-password"
          name="password"
          type="password"
          className="input"
          autoComplete="current-password"
          required
          placeholder="••••••••"
        />
      </div>

      <SubmitButton label="Sign in" pendingLabel="Signing in…" />
    </form>
  );
}

export function SignupForm() {
  const [state, action] = useActionState<ActionState, FormData>(
    async (prev, formData) => {
      const { signUp } = await import("@/app/actions/auth");
      return signUp(prev, formData);
    },
    null,
  );

  return (
    <form className="auth-form" action={action} noValidate>
      <Feedback state={state} />

      <div className="field">
        <label htmlFor="signup-name">Name (optional)</label>
        <input
          id="signup-name"
          name="fullName"
          type="text"
          className="input"
          autoComplete="name"
          maxLength={80}
          placeholder="Your name"
        />
      </div>

      <div className="field">
        <label htmlFor="signup-email">Email</label>
        <input
          id="signup-email"
          name="email"
          type="email"
          className="input"
          autoComplete="email"
          required
          placeholder="you@company.com"
        />
      </div>

      <div className="field">
        <label htmlFor="signup-password">Password</label>
        <input
          id="signup-password"
          name="password"
          type="password"
          className="input"
          autoComplete="new-password"
          required
          minLength={8}
          placeholder="At least 8 characters"
          aria-describedby="signup-password-hint"
        />
        <p className="field-hint" id="signup-password-hint">
          Minimum 8 characters. Longer is better.
        </p>
      </div>

      <SubmitButton label="Create account" pendingLabel="Creating account…" />
    </form>
  );
}

export function ResetRequestForm() {
  const [state, action] = useActionState<ActionState, FormData>(
    async (prev, formData) => {
      const { requestPasswordReset } = await import("@/app/actions/auth");
      return requestPasswordReset(prev, formData);
    },
    null,
  );

  return (
    <form className="auth-form" action={action} noValidate>
      <Feedback state={state} />

      <div className="field">
        <label htmlFor="reset-email">Email</label>
        <input
          id="reset-email"
          name="email"
          type="email"
          className="input"
          autoComplete="email"
          required
          placeholder="you@company.com"
        />
      </div>

      <SubmitButton label="Send reset link" pendingLabel="Sending…" />
    </form>
  );
}

export function UpdatePasswordForm() {
  const [state, action] = useActionState<ActionState, FormData>(
    async (prev, formData) => {
      const { updatePassword } = await import("@/app/actions/auth");
      return updatePassword(prev, formData);
    },
    null,
  );

  return (
    <form className="auth-form" action={action} noValidate>
      <Feedback state={state} />

      <div className="field">
        <label htmlFor="new-password">New password</label>
        <input
          id="new-password"
          name="password"
          type="password"
          className="input"
          autoComplete="new-password"
          required
          minLength={8}
        />
      </div>

      <div className="field">
        <label htmlFor="confirm-password">Confirm new password</label>
        <input
          id="confirm-password"
          name="confirm"
          type="password"
          className="input"
          autoComplete="new-password"
          required
          minLength={8}
        />
      </div>

      <SubmitButton label="Update password" pendingLabel="Updating…" />
    </form>
  );
}
