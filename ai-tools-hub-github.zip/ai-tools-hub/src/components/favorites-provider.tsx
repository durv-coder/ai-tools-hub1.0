"use client";

import { createContext, useCallback, useContext, useMemo, useState } from "react";
import type { FavoriteState } from "@/lib/favorites";

type FavoriteContextValue = {
  signedIn: boolean;
  savedIds: Set<string>;
  /** Optimistically updates local state; the caller handles the server write. */
  setSaved: (toolId: string, saved: boolean) => void;
};

const FavoriteContext = createContext<FavoriteContextValue | null>(null);

/**
 * Holds the viewer's favourites for the whole page so individual cards never
 * fetch. Mounted in the public layout, seeded from a single server-side read.
 */
export function FavoritesProvider({
  initial,
  children,
}: {
  initial: FavoriteState;
  children: React.ReactNode;
}) {
  const [ids, setIds] = useState<string[]>(initial.ids);

  const setSaved = useCallback((toolId: string, saved: boolean) => {
    setIds((current) => {
      const has = current.includes(toolId);
      if (saved && !has) return [...current, toolId];
      if (!saved && has) return current.filter((id) => id !== toolId);
      return current;
    });
  }, []);

  const value = useMemo<FavoriteContextValue>(
    () => ({ signedIn: initial.signedIn, savedIds: new Set(ids), setSaved }),
    [initial.signedIn, ids, setSaved],
  );

  return <FavoriteContext.Provider value={value}>{children}</FavoriteContext.Provider>;
}

/** Falls back to a read-only, signed-out view if used outside the provider. */
export function useFavorites(): FavoriteContextValue {
  return (
    useContext(FavoriteContext) ?? {
      signedIn: false,
      savedIds: new Set<string>(),
      setSaved: () => {},
    }
  );
}
