"use client";

import { useActionState, useState } from "react";
import { useFormStatus } from "react-dom";
import Link from "next/link";
import type { AdminTool } from "@/lib/admin/queries";
import type { AdminState } from "@/app/actions/admin";
import { AlertCircle, Check } from "@/components/icons";

type Category = { id: number; name: string; slug: string };

const PRICING = [
  { value: "free", label: "Free" },
  { value: "freemium", label: "Freemium" },
  { value: "paid", label: "Paid" },
];

function Submit({ label }: { label: string }) {
  const { pending } = useFormStatus();
  return (
    <button type="submit" className="btn" disabled={pending}>
      {pending ? "Saving…" : label}
    </button>
  );
}

function SaveButton() {
  const { pending } = useFormStatus();
  return (
    <button type="submit" className="btn" disabled={pending}>
      {pending ? "Saving…" : "Save changes"}
    </button>
  );
}

export function ToolForm({
  action,
  tool,
  categories,
  submitLabel,
}: {
  action: (state: AdminState, formData: FormData) => Promise<AdminState>;
  tool?: AdminTool;
  categories: Category[];
  submitLabel: string;
}) {
  const [state, formAction] = useActionState<AdminState, FormData>(action, null);
  const [slug, setSlug] = useState(tool?.slug ?? "");

  return (
    <form action={formAction} className="stack" style={{ gap: 20 }}>
      {tool && <input type="hidden" name="id" value={tool.id} />}

      {state?.error && (
        <p className="alert alert--error" role="alert">
          <AlertCircle size={15} /> {state.error}
        </p>
      )}
      {state?.success && (
        <p className="alert alert--success" role="status">
          <Check size={15} /> {state.success}
        </p>
      )}

      <section className="card admin-form">
        <h2 className="admin-form__title">Basics</h2>
        <div className="admin-form__grid">
          <label className="field">
            <span className="field__label">Name</span>
            <input
              name="name"
              className="input"
              defaultValue={tool?.name ?? ""}
              required
              maxLength={60}
            />
          </label>

          <label className="field">
            <span className="field__label">
              Slug <span className="muted">(URL)</span>
            </span>
            <input
              name="slug"
              className="input"
              value={slug}
              onChange={(e) => setSlug(e.target.value)}
              placeholder="auto-generated from the name"
              pattern="[a-z0-9]+(-[a-z0-9]+)*"
              title="Lowercase letters, numbers and single hyphens"
            />
            <span className="field__hint muted">
              /tools/{slug || "…"} — changing this breaks existing links.
            </span>
          </label>

          <label className="field admin-form__wide">
            <span className="field__label">Tagline</span>
            <input
              name="tagline"
              className="input"
              defaultValue={tool?.tagline ?? ""}
              required
              maxLength={120}
              placeholder="One line that says what it does"
            />
          </label>

          <label className="field admin-form__wide">
            <span className="field__label">
              Description <span className="muted">(what it is for, and who it suits)</span>
            </span>
            <textarea
              name="description"
              className="input input--area"
              rows={5}
              defaultValue={tool?.description ?? ""}
              maxLength={4000}
            />
          </label>
        </div>
      </section>

      <section className="card admin-form">
        <h2 className="admin-form__title">Links and pricing</h2>
        <div className="admin-form__grid">
          <label className="field">
            <span className="field__label">Website URL</span>
            <input
              name="website_url"
              className="input"
              type="url"
              defaultValue={tool?.website_url ?? ""}
              placeholder="https://example.com"
              required
            />
          </label>

          <label className="field">
            <span className="field__label">
              Logo path or URL <span className="muted">(optional)</span>
            </span>
            <input
              name="logo_url"
              className="input"
              defaultValue={tool?.logo_url ?? ""}
              placeholder="/logos/my-tool.png"
            />
            <span className="field__hint muted">
              Runs <code>python3 scripts/fetch_logos.py</code> to fill this automatically.
            </span>
          </label>

          <label className="field">
            <span className="field__label">Pricing model</span>
            <select name="pricing_model" className="input" defaultValue={tool?.pricing_model ?? "freemium"}>
              {PRICING.map((p) => (
                <option key={p.value} value={p.value}>{p.label}</option>
              ))}
            </select>
          </label>

          <label className="field">
            <span className="field__label">
              Starting price <span className="muted">(optional)</span>
            </span>
            <input
              name="starting_price"
              className="input"
              defaultValue={tool?.starting_price ?? ""}
              placeholder="$20/mo"
              maxLength={40}
            />
          </label>

          <label className="field">
            <span className="field__label">Status</span>
            <select name="status" className="input" defaultValue={tool?.status ?? "published"}>
              <option value="published">published — visible on the site</option>
              <option value="draft">draft — hidden</option>
              <option value="archived">archived — hidden, kept for records</option>
            </select>
          </label>

          <label className="field">
            <span className="field__label">
              Tags <span className="muted">(comma separated, max 12)</span>
            </span>
            <input
              name="tags"
              className="input"
              defaultValue={(tool?.tags ?? []).join(", ")}
              placeholder="local, self-hosted, privacy"
            />
          </label>
        </div>
      </section>

      <section className="card admin-form">
        <h2 className="admin-form__title">Open source</h2>
        <p className="muted" style={{ fontSize: 13, marginBottom: 14 }}>
          Only tick this if the licence is OSI-approved — it controls the open-source filter
          and the licence badge.
        </p>
        <div className="admin-form__grid">
          <label className="field admin-form__wide admin-check">
            <input
              type="checkbox"
              name="is_open_source"
              defaultChecked={tool?.is_open_source ?? false}
            />
            <span>This tool is open source</span>
          </label>

          <label className="field">
            <span className="field__label">Repository URL</span>
            <input
              name="repo_url"
              className="input"
              defaultValue={tool?.repo_url ?? ""}
              placeholder="https://github.com/owner/repo"
            />
          </label>

          <label className="field">
            <span className="field__label">SPDX licence</span>
            <input
              name="license"
              className="input"
              defaultValue={tool?.license ?? ""}
              placeholder="MIT"
              maxLength={40}
            />
          </label>
        </div>
      </section>

      <section className="card admin-form">
        <h2 className="admin-form__title">Placement</h2>
        <div className="admin-form__grid">
          <label className="field admin-check">
            <input type="checkbox" name="is_featured" defaultChecked={tool?.is_featured ?? false} />
            <span>Featured (Editor&apos;s picks rail)</span>
          </label>
          <label className="field admin-check">
            <input type="checkbox" name="is_trending" defaultChecked={tool?.is_trending ?? false} />
            <span>Trending (Trending now rail)</span>
          </label>

          <fieldset className="field admin-form__wide admin-checks">
            <legend className="field__label">Categories</legend>
            <div className="admin-checks__grid">
              {categories.map((c) => (
                <label key={c.id} className="admin-check">
                  <input
                    type="checkbox"
                    name="category_ids"
                    value={c.id}
                    defaultChecked={(tool?.category_ids ?? []).includes(c.id)}
                  />
                  <span>{c.name}</span>
                </label>
              ))}
            </div>
          </fieldset>
        </div>
      </section>

      <div className="admin-form__actions">
        <Link href="/admin/tools" className="btn btn--ghost">Cancel</Link>
        <Submit label={submitLabel} />
      </div>
    </form>
  );
}

/** Separate form: deletion must not share a submit button with saving. */
export function DeleteToolForm({
  action,
  id,
  name,
}: {
  action: (formData: FormData) => Promise<void>;
  id: string;
  name: string;
}) {
  const [confirm, setConfirm] = useState("");

  return (
    <section className="card admin-form admin-danger">
      <h2 className="admin-form__title">Delete this tool</h2>
      <p className="muted" style={{ fontSize: 13.5, marginBottom: 14, lineHeight: 1.6 }}>
        Removes <strong>{name}</strong>, its reviews, favourites and category links. This
        cannot be undone. To hide it temporarily, set the status to archived instead.
      </p>
      <form action={action} className="stack" style={{ gap: 10 }}>
        <input type="hidden" name="id" value={id} />
        <label className="field">
          <span className="field__label">Type DELETE to confirm</span>
          <input
            name="confirm"
            className="input"
            value={confirm}
            onChange={(e) => setConfirm(e.target.value)}
            autoComplete="off"
          />
        </label>
        <DeleteButton enabled={confirm === "DELETE"} />
      </form>
    </section>
  );
}

function DeleteButton({ enabled }: { enabled: boolean }) {
  // useFormStatus only reports inside a child of the <form>.
  const { pending } = useFormStatus();
  return (
    <button
      type="submit"
      className="btn btn--ghost"
      disabled={!enabled || pending}
      style={{ color: "var(--danger)", borderColor: "var(--line-strong)", alignSelf: "flex-start" }}
    >
      {pending ? "Deleting…" : "Permanently delete"}
    </button>
  );
}
