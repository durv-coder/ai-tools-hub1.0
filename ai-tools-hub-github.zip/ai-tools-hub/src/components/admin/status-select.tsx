"use client";

import { useRef } from "react";

/**
 * Status dropdown that submits as soon as a value is chosen.
 *
 * A plain <select> next to a "Set" button means two clicks for every change,
 * which is tedious when triaging a long list. The server action is passed in
 * from the server component, so the mutation still runs server-side and is
 * re-authorised there; this component only decides when to submit.
 */
export function StatusSelect({
  action,
  id,
  name,
  value,
  label,
}: {
  action: (formData: FormData) => void | Promise<void>;
  id: string;
  name: string;
  value: string;
  label: string;
}) {
  const formRef = useRef<HTMLFormElement>(null);

  return (
    <form action={action} ref={formRef} className="admin-inline">
      <input type="hidden" name="id" value={id} />
      <select
        name={name}
        defaultValue={value}
        className="input input--tiny"
        aria-label={label}
        onChange={() => formRef.current?.requestSubmit()}
      >
        <option value="published">published</option>
        <option value="draft">draft</option>
        <option value="archived">archived</option>
      </select>
    </form>
  );
}
