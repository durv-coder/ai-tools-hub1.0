"use client";

import { useActionState, useEffect, useState } from "react";
import { useFormStatus } from "react-dom";
import Link from "next/link";
import type { AdminState } from "@/app/actions/admin";
import { AlertCircle, Check } from "@/components/icons";

type Category = { id: number; name: string; slug: string; count: number };

function Submit({ label }: { label: string }) {
  const { pending } = useFormStatus();
  return (
    <button type="submit" className="btn btn--sm" disabled={pending}>
      {pending ? "Saving…" : label}
    </button>
  );
}

function Feedback({ state }: { state: AdminState }) {
  if (!state?.error && !state?.success) return null;
  return (
    <p
      className={state.error ? "alert alert--error" : "alert alert--success"}
      role={state.error ? "alert" : "status"}
    >
      {state.error ? <AlertCircle size={15} /> : <Check size={15} />}
      {state.error ?? state.success}
    </p>
  );
}

export function CategoryForms({
  categories,
  createAction,
  updateAction,
  deleteAction,
}: {
  categories: Category[];
  createAction: (s: AdminState, f: FormData) => Promise<AdminState>;
  updateAction: (s: AdminState, f: FormData) => Promise<AdminState>;
  deleteAction: (f: FormData) => Promise<void>;
}) {
  const [createState, createFn] = useActionState<AdminState, FormData>(createAction, null);
  const [editing, setEditing] = useState<string | null>(null);

  return (
    <div className="stack" style={{ gap: 20 }}>
      <section className="card admin-form">
        <h2 className="admin-form__title">Add a category</h2>
        <form action={createFn} className="stack" style={{ gap: 14 }}>
          <Feedback state={createState} />
          <div className="admin-form__grid">
            <label className="field">
              <span className="field__label">Name</span>
              <input name="name" className="input" required maxLength={60} />
            </label>
            <label className="field">
              <span className="field__label">
                Slug <span className="muted">(optional — derived from the name)</span>
              </span>
              <input
                name="slug"
                className="input"
                placeholder="ai-productivity"
                pattern="[a-z0-9]+(-[a-z0-9]+)*"
              />
            </label>
            <label className="field">
              <span className="field__label">Icon name</span>
              <input name="icon" className="input" defaultValue="sparkles" maxLength={40} />
            </label>
            <label className="field">
              <span className="field__label">Sort order</span>
              <input name="sort_order" className="input" type="number" defaultValue={15} />
            </label>
            <label className="field admin-form__wide">
              <span className="field__label">Description</span>
              <input name="description" className="input" maxLength={160} />
            </label>
          </div>
          <Submit label="Add category" />
        </form>
      </section>

      <section className="card admin-table-wrap">
        <table className="admin-table">
          <thead>
            <tr>
              <th scope="col">Category</th>
              <th scope="col">Slug</th>
              <th scope="col" className="num">Published tools</th>
              <th scope="col"><span className="sr-only">Actions</span></th>
            </tr>
          </thead>
          <tbody>
            {categories.map((c) => (
              <tr key={c.id}>
                <td>
                  {editing === c.slug ? (
                    <EditRow
                      category={c}
                      action={updateAction}
                      onDone={() => setEditing(null)}
                    />
                  ) : (
                    <span style={{ fontWeight: 550 }}>{c.name}</span>
                  )}
                </td>
                <td className="muted"><code>{c.slug}</code></td>
                <td className="num">
                  <Link href={`/tools?category=${c.slug}`}>{c.count}</Link>
                </td>
                <td>
                  {editing === c.slug ? null : (
                    <div className="admin-inline">
                      <button
                        type="button"
                        className="btn btn--ghost btn--tiny"
                        onClick={() => setEditing(c.slug)}
                      >
                        Rename
                      </button>
                      <DeleteCategory action={deleteAction} name={c.name} id={c.id} count={c.count} />
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>
    </div>
  );
}

function EditRow({
  category,
  action,
  onDone,
}: {
  category: Category;
  action: (s: AdminState, f: FormData) => Promise<AdminState>;
  onDone: () => void;
}) {
  const [state, formAction] = useActionState<AdminState, FormData>(action, null);

  // Close the editor once the save lands, so the row does not stay stuck in
  // edit mode showing a stale value in an uncontrolled input.
  useEffect(() => {
    if (state?.success) onDone();
  }, [state?.success, onDone]);

  return (
    <form action={formAction} className="admin-inline" style={{ gap: 8 }}>
      <input type="hidden" name="id" value={category.id} />
      <input
        name="name"
        className="input input--tiny"
        defaultValue={category.name}
        aria-label={`New name for ${category.name}`}
        required
      />
      <button type="submit" className="btn btn--tiny">Save</button>
      <button type="button" className="btn btn--ghost btn--tiny" onClick={onDone}>Cancel</button>
      {state?.error && <span className="alert alert--error" style={{ fontSize: 12 }}>{state.error}</span>}
    </form>
  );
}

function DeleteCategory({
  action,
  name,
  id,
  count,
}: {
  action: (f: FormData) => Promise<void>;
  name: string;
  id: number;
  count: number;
}) {
  const [confirming, setConfirming] = useState(false);

  if (count > 0) {
    // Refusing up front is clearer than letting the server bounce it back.
    return (
      <button
        type="button"
        className="btn btn--ghost btn--tiny"
        disabled
        title={`Move the ${count} tool${count === 1 ? "" : "s"} in this category first`}
        style={{ opacity: 0.5 }}
      >
        In use
      </button>
    );
  }

  if (!confirming) {
    return (
      <button
        type="button"
        className="btn btn--ghost btn--tiny"
        onClick={() => setConfirming(true)}
      >
        Delete
      </button>
    );
  }

  return (
    <form action={action} className="admin-inline">
      <input type="hidden" name="id" value={id} />
      <input type="hidden" name="confirm" value="DELETE" />
      <span className="muted" style={{ fontSize: 12 }}>Delete {name}?</span>
      <button type="submit" className="btn btn--tiny" style={{ color: "var(--danger)" }}>Yes</button>
      <button type="button" className="btn btn--ghost btn--tiny" onClick={() => setConfirming(false)}>
        No
      </button>
    </form>
  );
}
