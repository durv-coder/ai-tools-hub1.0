import "server-only";
import { cookies } from "next/headers";
import { createServerClient } from "@supabase/ssr";

/**
 * Auth-aware Supabase client for Server Components, Server Actions and Route
 * Handlers. Reads and writes the session cookie so the server always knows who
 * the user is without shipping tokens to the browser.
 */
export async function createAuthClient() {
  const cookieStore = await cookies();

  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

  if (!url || !key) {
    throw new Error("Supabase environment variables are missing.");
  }

  return createServerClient(url, key, {
    cookies: {
      getAll() {
        return cookieStore.getAll();
      },
      setAll(cookiesToSet) {
        try {
          cookiesToSet.forEach(({ name, value, options }) => {
            cookieStore.set(name, value, options);
          });
        } catch {
          // Called from a Server Component render, where cookies are read-only.
          // Middleware refreshes the session, so this is safe to ignore.
        }
      },
    },
  });
}

/** Returns the signed-in user, or null. Never throws to the caller. */
export async function getCurrentUser() {
  try {
    const supabase = await createAuthClient();
    const {
      data: { user },
    } = await supabase.auth.getUser();
    return user;
  } catch {
    return null;
  }
}

/** Returns the user's profile row (including role), or null. */
export async function getCurrentProfile() {
  const user = await getCurrentUser();
  if (!user) return null;

  try {
    const supabase = await createAuthClient();
    const { data } = await supabase
      .from("profiles")
      .select("id, email, full_name, username, avatar_url, bio, role, created_at")
      .eq("id", user.id)
      .maybeSingle();

    return data ?? null;
  } catch {
    return null;
  }
}
