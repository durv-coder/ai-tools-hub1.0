import { createClient, type SupabaseClient } from "@supabase/supabase-js";

/** Server-side Supabase client. Uses the publishable (anon) key, so every
 *  query is still constrained by RLS — this client has no privileged access. */
let cached: SupabaseClient | null = null;

export function getSupabase(): SupabaseClient {
  if (cached) return cached;

  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;

  if (!url || !key) {
    throw new Error(
      "Supabase environment variables are missing. Copy .env.example to .env.local and fill it in.",
    );
  }

  cached = createClient(url, key, {
    auth: { persistSession: false, autoRefreshToken: false },
    global: { headers: { "x-application-name": "ai-tools-hub" } },
  });

  return cached;
}
