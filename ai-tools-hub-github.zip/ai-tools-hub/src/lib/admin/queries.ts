import "server-only";
import { createAuthClient } from "@/lib/supabase/auth-server";
import { requireAdmin } from "@/lib/auth/admin";
import type { PricingModel } from "@/lib/types";

/**
 * Admin-only reads.
 *
 * Kept apart from `queries.ts` on purpose: every public query filters
 * `status = 'published'`, and lifting that filter inside them would risk
 * leaking drafts onto the public site. These functions call `requireAdmin()`
 * first, so a mistake higher up cannot expose unpublished rows.
 */

export type AdminTool = {
  id: string;
  slug: string;
  name: string;
  tagline: string;
  description: string | null;
  website_url: string;
  logo_url: string | null;
  pricing_model: PricingModel;
  starting_price: string | null;
  tags: string[];
  is_featured: boolean;
  is_trending: boolean;
  is_open_source: boolean;
  repo_url: string | null;
  license: string | null;
  status: "published" | "draft" | "archived";
  rating: number;
  rating_count: number;
  view_count: number;
  favorite_count: number;
  added_at: string;
  category_ids: number[];
};

const ADMIN_TOOL_COLUMNS = `
  id, slug, name, tagline, description, website_url, logo_url,
  pricing_model, starting_price, tags, is_featured, is_trending,
  is_open_source, repo_url, license, status, rating, rating_count,
  view_count, favorite_count, added_at,
  tool_categories ( category_id )
`;

type RawAdminTool = Omit<AdminTool, "category_ids"> & {
  tool_categories: { category_id: number }[] | null;
};

function normaliseTool(row: RawAdminTool): AdminTool {
  const { tool_categories, ...rest } = row;
  return {
    ...rest,
    rating: Number(rest.rating ?? 0),
    tags: rest.tags ?? [],
    category_ids: (tool_categories ?? []).map((tc) => tc.category_id),
  };
}

export type AdminToolFilters = {
  search?: string;
  status?: "all" | "published" | "draft" | "archived";
  page?: number;
  perPage?: number;
};

export type AdminToolPage = {
  tools: AdminTool[];
  total: number;
  page: number;
  perPage: number;
  totalPages: number;
};

export async function getAdminTools(filters: AdminToolFilters = {}): Promise<AdminToolPage> {
  await requireAdmin();
  // Session-bound client, not the anonymous one: admin select policies key off
  // auth.uid(), so a cookie-less client is treated as `anon` and reads nothing.
  const supabase = await createAuthClient();

  const perPage = Math.min(50, Math.max(1, filters.perPage ?? 20));
  const page = Math.max(1, filters.page ?? 1);
  const from = (page - 1) * perPage;

  const build = () => {
    let q = supabase.from("tools").select(ADMIN_TOOL_COLUMNS, { count: "exact" });
    if (filters.status && filters.status !== "all") q = q.eq("status", filters.status);
    const term = (filters.search ?? "").trim().slice(0, 80);
    if (term) {
      // Escape PostgREST filter delimiters so a comma cannot inject a filter.
      const safe = term.replace(/[\\%_(),."']/g, "");
      if (safe) q = q.or(`name.ilike.%${safe}%,slug.ilike.%${safe}%`);
    }
    return q.order("added_at", { ascending: false }).order("name", { ascending: true });
  };

  let { data, error, count } = await build().range(from, from + perPage - 1);

  // A page past the end is a stale link, not an error: PostgREST answers 416.
  if (error?.code === "PGRST103" || (!error && (data ?? []).length === 0 && page > 1)) {
    const totalNow = count ?? 0;
    const lastPage = totalNow > 0 ? Math.max(1, Math.ceil(totalNow / perPage)) : 1;
    ({ data, error, count } = await build().range(
      (lastPage - 1) * perPage,
      (lastPage - 1) * perPage + perPage - 1,
    ));
  }

  if (error) throw new Error(`Could not load tools: ${error.message}`);

  const total = count ?? 0;
  return {
    tools: ((data ?? []) as unknown as RawAdminTool[]).map(normaliseTool),
    total,
    page,
    perPage,
    totalPages: total === 0 ? 0 : Math.ceil(total / perPage),
  };
}

export async function getAdminTool(id: string): Promise<AdminTool | null> {
  await requireAdmin();
  const supabase = await createAuthClient();
  const { data, error } = await supabase
    .from("tools")
    .select(ADMIN_TOOL_COLUMNS)
    .eq("id", id)
    .maybeSingle();

  if (error) throw new Error(`Could not load tool: ${error.message}`);
  return data ? normaliseTool(data as unknown as RawAdminTool) : null;
}

export type AdminStats = {
  tools: { total: number; published: number; draft: number; archived: number };
  categories: number;
  users: number;
  reviews: number;
  favorites: number;
  subscribers: { total: number; active: number };
  topViewed: { slug: string; name: string; view_count: number }[];
  perCategory: { id: number; name: string; slug: string; count: number }[];
};

export async function getAdminStats(): Promise<AdminStats> {
  await requireAdmin();
  // Must carry the caller's session: `favorites` and `profiles` only expose
  // rows to admins via policies that call is_admin(), which reads auth.uid().
  const supabase = await createAuthClient();

  const countOnly = { count: "exact" as const, head: true };

  const [
    total,
    published,
    draft,
    archived,
    categories,
    users,
    reviews,
    favorites,
    subs,
    subsActive,
    topViewed,
    categoryRows,
  ] = await Promise.all([
    supabase.from("tools").select("*", countOnly),
    supabase.from("tools").select("*", countOnly).eq("status", "published"),
    supabase.from("tools").select("*", countOnly).eq("status", "draft"),
    supabase.from("tools").select("*", countOnly).eq("status", "archived"),
    supabase.from("categories").select("*", countOnly),
    supabase.from("profiles").select("*", countOnly),
    supabase.from("reviews").select("*", countOnly),
    supabase.from("favorites").select("*", countOnly),
    supabase.from("newsletter_subscribers").select("*", countOnly),
    supabase.from("newsletter_subscribers").select("*", countOnly).is("unsubscribed_at", null),
    supabase
      .from("tools")
      .select("slug, name, view_count")
      .eq("status", "published")
      .order("view_count", { ascending: false })
      .limit(5),
    supabase.from("categories").select("id, name, slug").order("sort_order"),
  ]);

  // Name the failing query: an empty PostgREST message is useless when
  // debugging, and this runs on every admin page load.
  const named: [string, { error: { message: string; code?: string } | null }][] = [
    ["tools.total", total], ["tools.published", published], ["tools.draft", draft],
    ["tools.archived", archived], ["categories", categories], ["profiles", users],
    ["reviews", reviews], ["favorites", favorites],
    ["subscribers", subs], ["subscribers.active", subsActive],
    ["tools.topViewed", topViewed], ["categories.list", categoryRows],
  ];
  const failure = named.find(([, r]) => r.error);
  if (failure) {
    const [name, r] = failure;
    throw new Error(
      `Could not load stats (${name}): ${r.error?.message || r.error?.code || "unknown error"}`,
    );
  }

  // One query for every link row, then tally in memory. Avoids N+1 round trips
  // and keeps the count consistent with what the directory filter shows.
  const { data: links, error: linkError } = await supabase
    .from("tool_categories")
    .select("category_id, tools ( status )");
  if (linkError) throw new Error(`Could not load category counts: ${linkError.message}`);

  const byCategoryId = new Map<number, number>();
  for (const link of (links ?? []) as unknown as {
    category_id: number;
    tools: { status: string } | null;
  }[]) {
    if (link.tools?.status !== "published") continue;
    byCategoryId.set(link.category_id, (byCategoryId.get(link.category_id) ?? 0) + 1);
  }

  const list = (categoryRows.data ?? []) as { id: number; name: string; slug: string }[];

  return {
    tools: {
      total: total.count ?? 0,
      published: published.count ?? 0,
      draft: draft.count ?? 0,
      archived: archived.count ?? 0,
    },
    categories: categories.count ?? 0,
    users: users.count ?? 0,
    reviews: reviews.count ?? 0,
    favorites: favorites.count ?? 0,
    subscribers: { total: subs.count ?? 0, active: subsActive.count ?? 0 },
    topViewed: (topViewed.data ?? []) as AdminStats["topViewed"],
    perCategory: list.map((c) => ({
      id: c.id,
      name: c.name,
      slug: c.slug,
      count: byCategoryId.get(c.id) ?? 0,
    })),
  };
}

export type NewsletterSubscriber = {
  id: number;
  email: string;
  created_at: string;
  unsubscribed_at: string | null;
  source: string;
};

export async function getSubscribers(limit = 200): Promise<NewsletterSubscriber[]> {
  await requireAdmin();
  const supabase = await createAuthClient();
  const { data, error } = await supabase
    .from("newsletter_subscribers")
    .select("id, email, created_at, unsubscribed_at, source")
    .order("created_at", { ascending: false })
    .limit(limit);

  if (error) throw new Error(`Could not load subscribers: ${error.message}`);
  return (data ?? []) as NewsletterSubscriber[];
}
