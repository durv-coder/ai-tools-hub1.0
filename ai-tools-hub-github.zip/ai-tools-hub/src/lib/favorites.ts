import "server-only";
import { getCurrentUser, createAuthClient } from "@/lib/supabase/auth-server";

export type FavoriteState = {
  /** null = signed out. The button needs to tell "no account" from "no favourites". */
  signedIn: boolean;
  ids: string[];
};

/**
 * Reads the viewer's saved tool ids once, on the server, for the whole page.
 *
 * This used to be a server action that *every* favourite button called from
 * `useEffect` on mount, so a directory page with 36 cards fired 36 overlapping
 * POST requests on load. That flooded the dev server and the preview proxy
 * (surfacing as intermittent 502s), and it also guessed the signed-in state
 * from `ids.length === 0`, which misread a signed-in user with no favourites as
 * signed out. Both are fixed by doing one read here and passing the result down.
 */
export async function getFavoriteState(): Promise<FavoriteState> {
  const user = await getCurrentUser();
  if (!user) return { signedIn: false, ids: [] };

  try {
    const supabase = await createAuthClient();
    const { data } = await supabase.from("favorites").select("tool_id").eq("user_id", user.id);

    const ids = (data ?? [])
      .map((row) => (row as { tool_id: string | null }).tool_id)
      .filter((id): id is string => Boolean(id));

    return { signedIn: true, ids };
  } catch {
    // A failed read must not break the page; treat as signed in with nothing
    // saved rather than silently switching the user to local storage.
    return { signedIn: true, ids: [] };
  }
}

// ---------------------------------------------------------------------------
// Reviews
// ---------------------------------------------------------------------------

export type Review = {
  id: string;
  rating: number;
  title: string | null;
  body: string | null;
  created_at: string;
  author: string;
  isOwn: boolean;
};

/**
 * Public reviews for a tool, newest first, plus the viewer's own review so the
 * form can be pre-filled instead of silently overwriting a previous rating.
 */
export async function getReviews(
  toolId: string,
): Promise<{ reviews: Review[]; own: Review | null; signedIn: boolean }> {
  const supabase = await createAuthClient();
  const user = await getCurrentUser();

  // Reads the `review_feed` view rather than joining profiles directly:
  // profiles RLS only exposes a user's own row, so an embedded join returned
  // nothing for anyone else's review. The view exposes display names only.
  const { data, error } = await supabase
    .from("review_feed")
    .select("id, rating, title, body, created_at, user_id, author")
    .eq("tool_id", toolId)
    .order("created_at", { ascending: false })
    .limit(50);

  if (error || !data) return { reviews: [], own: null, signedIn: Boolean(user) };

  const mapped: Review[] = data.map((row) => {
    const record = row as unknown as {
      id: string;
      rating: number;
      title: string | null;
      body: string | null;
      created_at: string;
      user_id: string;
      author: string | null;
    };

    // The view already falls back to "A member"; never surface an email.
    const author = record.author?.trim() || "A member";

    return {
      id: record.id,
      rating: record.rating,
      title: record.title,
      body: record.body,
      created_at: record.created_at,
      author,
      isOwn: Boolean(user && record.user_id === user.id),
    };
  });

  return {
    reviews: mapped,
    own: mapped.find((r) => r.isOwn) ?? null,
    signedIn: Boolean(user),
  };
}
