"use client";

import { useCallback, useEffect, useState } from "react";

export const MODES = ["light", "dark", "system"] as const;
export type ThemeMode = (typeof MODES)[number];

export const PALETTES = [
  { id: "warm", label: "Warm", hint: "Bone and warm grey" },
  { id: "slate", label: "Slate", hint: "Cool, technical" },
  { id: "paper", label: "Paper", hint: "Pure black and white" },
  { id: "sand", label: "Sand", hint: "Deep parchment" },
  { id: "image", label: "Image", hint: "Your own photo" },
] as const;
export type PaletteId = (typeof PALETTES)[number]["id"];

export const MODE_LABEL: Record<ThemeMode, string> = {
  light: "Light",
  dark: "Dark",
  system: "System",
};

const MODE_KEY = "ath-theme";
const PALETTE_KEY = "ath-palette";
const IMAGE_KEY = "ath-bg-image";
const DIM_KEY = "ath-bg-dim";

/** Applied to <html> as custom properties so CSS can use the image without a
 *  style recalculation of every element. */
export function applyImage(url: string | null, dim: number) {
  const root = document.documentElement;
  if (url) {
    root.style.setProperty("--bg-image", `url("${url}")`);
  } else {
    root.style.removeProperty("--bg-image");
  }
  root.style.setProperty("--bg-image-dim", String(dim));
}

/** Only https and data images are accepted. Anything else — javascript:, file:,
 *  remote http, svg with script — is rejected before it reaches CSS. */
export function isSafeImageUrl(value: string): boolean {
  const trimmed = value.trim();
  if (/^data:image\/(png|jpe?g|webp|gif|avif);base64,/i.test(trimmed)) return true;
  try {
    const url = new URL(trimmed);
    return url.protocol === "https:";
  } catch {
    return false;
  }
}

function systemPrefersDark(): boolean {
  return typeof window !== "undefined" && window.matchMedia("(prefers-color-scheme: dark)").matches;
}

/** The theme actually painted, resolving "system" against the OS setting. */
function resolve(mode: ThemeMode): "light" | "dark" {
  if (mode === "system") return systemPrefersDark() ? "dark" : "light";
  return mode;
}

function readStored(): { mode: ThemeMode; palette: PaletteId; image: string | null; dim: number } {
  let mode: ThemeMode = "system";
  let palette: PaletteId = "warm";
  let image: string | null = null;
  let dim = 60;
  try {
    const storedMode = localStorage.getItem(MODE_KEY) as ThemeMode | null;
    const storedPalette = localStorage.getItem(PALETTE_KEY) as PaletteId | null;
    if (storedMode && MODES.includes(storedMode)) mode = storedMode;
    if (storedPalette && PALETTES.some((p) => p.id === storedPalette)) palette = storedPalette;

    const storedImage = localStorage.getItem(IMAGE_KEY);
    if (storedImage && isSafeImageUrl(storedImage)) image = storedImage;

    // Number(null) is 0, which would silently mean "no dimming at all".
    const rawDim = localStorage.getItem(DIM_KEY);
    if (rawDim !== null && rawDim.trim() !== "") {
      const storedDim = Number(rawDim);
      if (Number.isFinite(storedDim) && storedDim >= 0 && storedDim <= 90) dim = storedDim;
    }
  } catch {
    /* storage blocked — fall back to defaults */
  }
  return { mode, palette, image, dim };
}

function apply(mode: ThemeMode, palette: PaletteId, image: string | null, dim: number) {
  const root = document.documentElement;
  root.setAttribute("data-theme", resolve(mode));
  root.setAttribute("data-palette", palette);
  root.setAttribute("data-theme-mode", mode);
  applyImage(image, dim);
}

/**
 * Reads and writes the theme. Shared by the header toggle and the settings
 * panel so both stay in sync, and so `system` is a real, live mode rather than
 * a value that gets stored and then ignored.
 */
export function useTheme() {
  const [mode, setModeState] = useState<ThemeMode>("system");
  const [palette, setPaletteState] = useState<PaletteId>("warm");
  const [image, setImageState] = useState<string | null>(null);
  const [dim, setDimState] = useState(60);
  const [mounted, setMounted] = useState(false);
  const [resolved, setResolved] = useState<"light" | "dark">("light");

  useEffect(() => {
    const stored = readStored();
    setModeState(stored.mode);
    setPaletteState(stored.palette);
    setImageState(stored.image);
    setDimState(stored.dim);
    setResolved(resolve(stored.mode));
    setMounted(true);
  }, []);

  // Follow the OS while the user is on "system".
  useEffect(() => {
    if (mode !== "system") return;
    const query = window.matchMedia("(prefers-color-scheme: dark)");
    const onChange = () => {
      const next = query.matches ? "dark" : "light";
      setResolved(next);
      document.documentElement.setAttribute("data-theme", next);
    };
    query.addEventListener("change", onChange);
    return () => query.removeEventListener("change", onChange);
  }, [mode]);

  const setMode = useCallback((next: ThemeMode) => {
    const stored = readStored();
    setModeState(next);
    setResolved(resolve(next));
    apply(next, stored.palette, stored.image, stored.dim);
    try {
      localStorage.setItem(MODE_KEY, next);
    } catch {
      /* ignore */
    }
  }, []);

  const setPalette = useCallback((next: PaletteId) => {
    const stored = readStored();
    setPaletteState(next);
    apply(stored.mode, next, next === "image" ? stored.image : stored.image, stored.dim);
    try {
      localStorage.setItem(PALETTE_KEY, next);
    } catch {
      /* ignore */
    }
  }, []);

  /** Sets (or clears, with null) the background image and switches to the image
   *  palette. Storage quota is the real constraint: a photo can exceed the
   *  ~5 MB localStorage limit, so failure is reported rather than swallowed. */
  const setImage = useCallback((url: string | null, nextDim?: number): { ok: boolean; error?: string } => {
    const value = url?.trim() ? url.trim() : null;

    if (value && !isSafeImageUrl(value)) {
      return { ok: false, error: "That image link was rejected. Use an https:// URL or upload a file." };
    }

    const dimValue = typeof nextDim === "number" ? nextDim : readStored().dim;

    try {
      if (value) localStorage.setItem(IMAGE_KEY, value);
      else localStorage.removeItem(IMAGE_KEY);
      localStorage.setItem(DIM_KEY, String(dimValue));
    } catch {
      return {
        ok: false,
        error: "That image is too large to store on this device. Try a smaller file or use an image URL.",
      };
    }

    setImageState(value);
    setDimState(dimValue);
    setPaletteState("image");
    localStorage.setItem(PALETTE_KEY, "image");
    apply(readStored().mode, "image", value, dimValue);
    return { ok: true };
  }, []);

  const setDim = useCallback((next: number) => {
    const stored = readStored();
    const clamped = Math.max(0, Math.min(90, Math.round(next)));
    setDimState(clamped);
    apply(stored.mode, stored.palette, stored.image, clamped);
    try {
      localStorage.setItem(DIM_KEY, String(clamped));
    } catch {
      /* ignore */
    }
  }, []);

  /** Header button: light → dark → system → light. */
  const cycleMode = useCallback(() => {
    const order: ThemeMode[] = ["light", "dark", "system"];
    setMode(order[(order.indexOf(mode) + 1) % order.length]);
  }, [mode, setMode]);

  return {
    mode,
    palette,
    image,
    dim,
    resolved,
    mounted,
    setMode,
    setPalette,
    setImage,
    setDim,
    cycleMode,
  };
}
