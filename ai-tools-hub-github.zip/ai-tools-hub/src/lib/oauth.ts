import "server-only";

type AuthSettings = {
  external?: Record<string, boolean>;
};

/**
 * Asks Supabase whether the Google provider is actually configured for this
 * project, by reading its public `/auth/v1/settings` endpoint.
 *
 * This exists so the "Continue with Google" button can be gated on the truth
 * rather than on a hard-coded flag. If the provider is not enabled, Supabase
 * still returns a redirect URL from `signInWithOAuth` and sends the browser to
 * an "Unsupported provider" error page — so rendering the button unconditionally
 * would be a dead end for the user.
 *
 * Fails closed: any network or parse problem means "not available", because a
 * missing button is a better outcome than a broken one.
 *
 * Result is cached for 5 minutes; enabling the provider in the Supabase
 * dashboard makes the button appear without a redeploy.
 */
export async function isGoogleEnabled(): Promise<boolean> {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !key) return false;

  try {
    const response = await fetch(`${url}/auth/v1/settings`, {
      headers: { apikey: key },
      next: { revalidate: 300, tags: ["auth-settings"] },
    });

    if (!response.ok) return false;

    const settings = (await response.json()) as AuthSettings;
    return settings.external?.google === true;
  } catch {
    return false;
  }
}
