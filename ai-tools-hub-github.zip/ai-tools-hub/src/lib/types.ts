export type PricingModel = "free" | "freemium" | "paid";

export type Category = {
  id: number;
  name: string;
  slug: string;
  description: string | null;
  icon: string;
  sort_order: number;
};

export type Tool = {
  id: string;
  slug: string;
  name: string;
  tagline: string;
  description: string | null;
  website_url: string;
  logo_url: string | null;
  pricing_model: PricingModel;
  starting_price: string | null;
  tags: string[];
  is_featured: boolean;
  is_trending: boolean;
  rating: number;
  rating_count: number;
  favorite_count: number;
  view_count: number;
  added_at: string;
  is_open_source: boolean;
  repo_url: string | null;
  license: string | null;
  category_slugs: string[];
};

export type SortKey = "popular" | "rating" | "newest" | "alpha";

export type ToolQuery = {
  search?: string;
  categories?: string[];
  pricing?: PricingModel | "all";
  openSource?: boolean;
  trending?: boolean;
  sort?: SortKey;
  page?: number;
  perPage?: number;
};

export type ToolPage = {
  tools: Tool[];
  total: number;
  page: number;
  perPage: number;
  totalPages: number;
};

export const SORT_OPTIONS: { key: SortKey; label: string }[] = [
  { key: "popular", label: "Most popular" },
  { key: "rating", label: "Highest rated" },
  { key: "newest", label: "Newest" },
  { key: "alpha", label: "A–Z" },
];

export const PRICING_LABEL: Record<PricingModel, string> = {
  free: "Free",
  freemium: "Free plan",
  paid: "Paid",
};

export function formatCount(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(1).replace(/\.0$/, "")}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(1).replace(/\.0$/, "")}k`;
  return String(n);
}

export function initials(name: string): string {
  return name
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((w) => w[0]?.toUpperCase() ?? "")
    .join("");
}
