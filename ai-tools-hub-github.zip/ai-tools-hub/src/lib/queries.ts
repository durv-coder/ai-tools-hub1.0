import "server-only";
import { getSupabase } from "@/lib/supabase/server";
import type { Category, PricingModel, SortKey, Tool, ToolPage, ToolQuery } from "@/lib/types";

/** Columns selected everywhere so the Tool type stays consistent. */
const TOOL_COLUMNS = `
  id, slug, name, tagline, description, website_url, logo_url,
  pricing_model, starting_price, tags, is_featured, is_trending,
  rating, rating_count, favorite_count, view_count, added_at,
  is_open_source, repo_url, license,
  tool_categories ( categories ( slug ) )
`;

type RawTool = Omit<Tool, "category_slugs"> & {
  tool_categories: { categories: { slug: string } | null }[] | null;
};

function normalise(row: RawTool): Tool {
  const { tool_categories, ...rest } = row;
  return {
    ...rest,
    rating: Number(rest.rating ?? 0),
    category_slugs: (tool_categories ?? [])
      .map((tc) => tc.categories?.slug)
      .filter((s): s is string => Boolean(s)),
  };
}

/** Escape user input before it goes into a PostgREST filter or ilike pattern. */
function safeTerm(input: string): string {
  return input.replace(/[%,()\\]/g, " ").replace(/\s+/g, " ").trim().slice(0, 80);
}

export async function getCategories(): Promise<Category[]> {
  const { data, error } = await getSupabase()
    .from("categories")
    .select("id, name, slug, description, icon, sort_order")
    .order("sort_order", { ascending: true });

  if (error) throw new Error(`Could not load categories: ${error.message}`);
  return (data ?? []) as Category[];
}

/** Category slugs are resolved to ids in a second query so the client never
 *  has to trust a slug that came from the URL. */
async function resolveCategoryIds(slugs: string[]): Promise<number[]> {
  if (slugs.length === 0) return [];
  const { data, error } = await getSupabase()
    .from("categories")
    .select("id")
    .in("slug", slugs);

  if (error) throw new Error(`Could not resolve categories: ${error.message}`);
  return (data ?? []).map((c) => c.id as number);
}

async function toolIdsInCategories(ids: number[]): Promise<string[]> {
  if (ids.length === 0) return [];
  const { data, error } = await getSupabase()
    .from("tool_categories")
    .select("tool_id")
    .in("category_id", ids);

  if (error) throw new Error(`Could not filter by category: ${error.message}`);
  return [...new Set((data ?? []).map((r) => r.tool_id as string))];
}

/**
 * Applies every non-pagination filter and returns a fresh builder.
 *
 * A function rather than a stored builder because `.range()` beyond the last
 * row makes PostgREST answer 416 ("Requested range not satisfiable") instead
 * of an empty page — so a stale `?page=99` link or a shrinking result set
 * turned into a visible error. Clamping needs a count and a second, identical
 * query, which means the filters have to be re-appliable.
 */
async function resolveFilterIds(query: ToolQuery): Promise<string[] | null> {
  if (!query.categories || query.categories.length === 0) return null;
  const ids = await resolveCategoryIds(query.categories);
  const matching = await toolIdsInCategories(ids.length > 0 ? ids : [-1]);
  // An empty list must filter everything out; passing [] to `in()` would drop
  // the filter and return the whole table.
  return matching.length > 0 ? matching : ["00000000-0000-0000-0000-000000000000"];
}

/**
 * Builds the filtered query. Deliberately synchronous: the Supabase builder is
 * a thenable, so returning it from an `async` function would resolve it into a
 * response instead of a query. Async work happens in `resolveFilterIds` first.
 */
function buildQuery(query: ToolQuery, ids: string[] | null) {
  let request = getSupabase()
    .from("tools")
    .select(TOOL_COLUMNS, { count: "exact" })
    .eq("status", "published");

  const term = query.search ? safeTerm(query.search) : "";
  if (term) {
    request = request.or(
      `name.ilike.%${term}%,tagline.ilike.%${term}%,description.ilike.%${term}%`,
    );
  }

  if (query.pricing && query.pricing !== "all") {
    // In the UI, "free" means the tool has a usable free tier — which in the
    // data is `free` or `freemium`. Matching only `free` would hide almost
    // every genuinely free-to-start tool.
    if (query.pricing === "free") {
      request = request.in("pricing_model", ["free", "freemium"]);
    } else {
      request = request.eq("pricing_model", query.pricing as PricingModel);
    }
  }

  if (query.openSource) {
    request = request.eq("is_open_source", true);
  }

  if (query.trending) {
    request = request.eq("is_trending", true);
  }

  if (ids) {
    request = request.in("id", ids);
  }

  switch (query.sort as SortKey | undefined) {
    case "rating":
      return request
        .order("rating", { ascending: false })
        .order("rating_count", { ascending: false })
        .order("name", { ascending: true });
    case "newest":
      return request
        .order("added_at", { ascending: false })
        .order("name", { ascending: true });
    case "alpha":
      return request.order("name", { ascending: true });
    default:
      return request
        .order("view_count", { ascending: false })
        .order("rating", { ascending: false })
        .order("name", { ascending: true });
  }
}

export async function searchTools(query: ToolQuery): Promise<ToolPage> {
  const perPage = Math.min(48, Math.max(1, query.perPage ?? 12));
  const requested = Math.max(1, query.page ?? 1);
  const ids = await resolveFilterIds(query);

  /** One page of results plus the exact total, in a single round trip. */
  async function fetchPage(page: number) {
    const from = (page - 1) * perPage;
    return buildQuery(query, ids).range(from, from + perPage - 1);
  }

  let page = requested;
  let { data, error, count } = await fetchPage(page);

  // Two distinct failures look alike here and need different handling:
  //   * a stale link (page 99 of 9) -> PostgREST replies 416, or an empty set.
  //     Clamp to the last page rather than showing an error.
  //   * a genuinely empty result -> show the empty state.
  // The count arrives with the error response, so the clamp needs no extra
  // request in the common path.
  const stale = error?.code === "PGRST103" || ((!data || data.length === 0) && page > 1);

  if (stale) {
    const totalNow = count ?? 0;
    const lastPage = totalNow > 0 ? Math.max(1, Math.ceil(totalNow / perPage)) : 1;
    if (lastPage !== page) {
      page = lastPage;
      const retry = await fetchPage(page);
      if (retry.error) throw new Error(`Could not load tools: ${retry.error.message}`);
      data = retry.data;
      count = retry.count;
      error = null;
    } else {
      data = [];
      error = null;
    }
  }

  if (error) throw new Error(`Could not load tools: ${error.message}`);

  const total = count ?? 0;
  const totalPages = total === 0 ? 0 : Math.ceil(total / perPage);

  return {
    tools: ((data ?? []) as unknown as RawTool[]).map(normalise),
    total,
    page: total === 0 ? 1 : page,
    perPage,
    totalPages,
  };
}

export async function getToolBySlug(slug: string): Promise<Tool | null> {
  const { data, error } = await getSupabase()
    .from("tools")
    .select(TOOL_COLUMNS)
    .eq("slug", slug)
    .eq("status", "published")
    .maybeSingle();

  if (error) throw new Error(`Could not load tool: ${error.message}`);
  if (!data) return null;
  return normalise(data as unknown as RawTool);
}

/**
 * Fetches many tools by slug in a single query, for the comparison view.
 *
 * One `.in()` rather than a loop of `getToolBySlug`, so comparing four tools
 * costs one round trip instead of four. Order is not preserved by PostgREST, so
 * the caller re-orders against its own list.
 */
export async function getToolsBySlugs(slugs: string[]): Promise<Tool[]> {
  const clean = [...new Set(slugs.filter((s) => /^[a-z0-9-]{1,60}$/.test(s)))].slice(0, 4);
  if (clean.length === 0) return [];

  const { data, error } = await getSupabase()
    .from("tools")
    .select(TOOL_COLUMNS)
    .eq("status", "published")
    .in("slug", clean);

  if (error) throw new Error(`Could not load tools: ${error.message}`);
  return (data as unknown as RawTool[]).map(normalise);
}

/** Lightweight slug+name list, used to populate the compare pickers. */
export async function getToolIndex(): Promise<{ slug: string; name: string }[]> {
  const { data, error } = await getSupabase()
    .from("tools")
    .select("slug, name")
    .eq("status", "published")
    .order("name", { ascending: true });

  if (error) throw new Error(`Could not load the tool list: ${error.message}`);
  return (data ?? []) as { slug: string; name: string }[];
}

/** Rails for the homepage. Each is a small, indexed query. */
export async function getFeaturedTools(limit = 6): Promise<Tool[]> {
  const { data, error } = await getSupabase()
    .from("tools")
    .select(TOOL_COLUMNS)
    .eq("status", "published")
    .eq("is_featured", true)
    .order("rating", { ascending: false })
    .order("view_count", { ascending: false })
    .order("name", { ascending: true })
    .limit(limit);

  if (error) throw new Error(`Could not load featured tools: ${error.message}`);
  return (data as unknown as RawTool[]).map(normalise);
}

export async function getTrendingTools(limit = 8): Promise<Tool[]> {
  const { data, error } = await getSupabase()
    .from("tools")
    .select(TOOL_COLUMNS)
    .eq("status", "published")
    .eq("is_trending", true)
    // View counts only reflect real recorded visits, so they tie at zero for a
    // young site. Fall back to name so the rail is stable rather than arbitrary.
    .order("view_count", { ascending: false })
    .order("name", { ascending: true })
    .limit(limit);

  if (error) throw new Error(`Could not load trending tools: ${error.message}`);
  return (data as unknown as RawTool[]).map(normalise);
}

export async function getRecentTools(limit = 6): Promise<Tool[]> {
  const { data, error } = await getSupabase()
    .from("tools")
    .select(TOOL_COLUMNS)
    .eq("status", "published")
    .order("added_at", { ascending: false })
    .limit(limit);

  if (error) throw new Error(`Could not load recent tools: ${error.message}`);
  return (data as unknown as RawTool[]).map(normalise);
}

export async function getFreeTools(limit = 8): Promise<Tool[]> {
  const { data, error } = await getSupabase()
    .from("tools")
    .select(TOOL_COLUMNS)
    .eq("status", "published")
    .in("pricing_model", ["free", "freemium"])
    .order("rating", { ascending: false })
    .order("view_count", { ascending: false })
    .order("name", { ascending: true })
    .limit(limit);

  if (error) throw new Error(`Could not load free tools: ${error.message}`);
  return (data as unknown as RawTool[]).map(normalise);
}

export async function getOpenSourceTools(limit = 8): Promise<Tool[]> {
  const { data, error } = await getSupabase()
    .from("tools")
    .select(TOOL_COLUMNS)
    .eq("status", "published")
    .eq("is_open_source", true)
    .order("view_count", { ascending: false })
    .limit(limit);

  if (error) throw new Error(`Could not load open-source tools: ${error.message}`);
  return (data as unknown as RawTool[]).map(normalise);
}

export async function getPremiumTools(limit = 8): Promise<Tool[]> {
  const { data, error } = await getSupabase()
    .from("tools")
    .select(TOOL_COLUMNS)
    .eq("status", "published")
    .eq("pricing_model", "paid")
    .order("rating", { ascending: false })
    .order("view_count", { ascending: false })
    .order("name", { ascending: true })
    .limit(limit);

  if (error) throw new Error(`Could not load premium tools: ${error.message}`);
  return (data as unknown as RawTool[]).map(normalise);
}

/** Related tools: share a category, exclude the current tool. */
export async function getRelatedTools(tool: Tool, limit = 3): Promise<Tool[]> {
  const ids = await resolveCategoryIds(tool.category_slugs);
  if (ids.length === 0) {
    return (await getTrendingTools(limit)).filter((t) => t.id !== tool.id).slice(0, limit);
  }

  const { data, error } = await getSupabase()
    .from("tools")
    .select(TOOL_COLUMNS)
    .eq("status", "published")
    .neq("id", tool.id)
    .in(
      "id",
      (await toolIdsInCategories(ids)).slice(0, 200),
    )
    .order("rating", { ascending: false })
    .order("view_count", { ascending: false })
    .order("name", { ascending: true })
    .limit(limit);

  if (error) throw new Error(`Could not load related tools: ${error.message}`);
  return (data as unknown as RawTool[]).map(normalise);
}

/** Platform statistics, derived from real rows. */
export async function getPlatformStats(): Promise<{
  tools: number;
  categories: number;
  freeTools: number;
  reviews: number;
  openSource: number;
}> {
  const supabase = getSupabase();
  const [tools, categories, free, reviews] = await Promise.all([
    supabase.from("tools").select("*", { count: "exact", head: true }).eq("status", "published"),
    supabase.from("categories").select("*", { count: "exact", head: true }),
    supabase
      .from("tools")
      .select("*", { count: "exact", head: true })
      .eq("status", "published")
      .in("pricing_model", ["free", "freemium"]),
    supabase.from("reviews").select("*", { count: "exact", head: true }),
  ]);

  const open = await supabase
    .from("tools")
    .select("*", { count: "exact", head: true })
    .eq("status", "published")
    .eq("is_open_source", true);

  return {
    tools: tools.count ?? 0,
    categories: categories.count ?? 0,
    freeTools: free.count ?? 0,
    reviews: reviews.count ?? 0,
    openSource: open.count ?? 0,
  };
}

/** Category counts for the directory sidebar / category grid. */
export async function getCategoryCounts(): Promise<Record<string, number>> {
  const { data, error } = await getSupabase()
    .from("tool_categories")
    .select("categories ( slug ), tools!inner ( status )")
    .eq("tools.status", "published");

  if (error) return {};

  const counts: Record<string, number> = {};
  for (const row of (data ?? []) as unknown as {
    categories: { slug: string } | null;
  }[]) {
    const slug = row.categories?.slug;
    if (slug) counts[slug] = (counts[slug] ?? 0) + 1;
  }
  return counts;
}

export type Suggestion = { slug: string; name: string; tagline: string };

export async function getSuggestions(term: string, limit = 6): Promise<Suggestion[]> {
  const clean = safeTerm(term);
  if (clean.length < 2) return [];

  const { data, error } = await getSupabase()
    .from("tools")
    .select("slug, name, tagline")
    .eq("status", "published")
    .or(`name.ilike.%${clean}%,tagline.ilike.%${clean}%`)
    .order("view_count", { ascending: false })
    .limit(limit);

  if (error) return [];
  return (data ?? []) as Suggestion[];
}
