import "server-only";
import { getCurrentProfile } from "@/lib/supabase/auth-server";

/**
 * The single gate for everything admin.
 *
 * Role lives in `profiles.role`, and RLS already restricts writes to admins via
 * `is_admin()`. These checks exist so a non-admin gets a clean redirect instead
 * of an empty page or a database error — they are a UX layer, not the security
 * boundary. The boundary is RLS plus the `profiles` trigger that blocks role
 * changes from non-admins.
 */
export async function getAdminProfile() {
  const profile = await getCurrentProfile();
  if (!profile) return null;
  return profile.role === "admin" ? profile : null;
}

export async function isAdmin(): Promise<boolean> {
  return (await getAdminProfile()) !== null;
}

/** Throws for use inside server actions, where there is no page to redirect. */
export async function requireAdmin() {
  const profile = await getAdminProfile();
  if (!profile) throw new Error("Not authorised.");
  return profile;
}
